#include "t_score_graphics_view.h"

TScoreGraphicsView::TScoreGraphicsView(QWidget *parent):
    QGraphicsView(parent)
{
    setMouseTracking(true);
}
