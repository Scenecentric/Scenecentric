#include "t_behaviour_dialog.h"
#include "ui_t_behaviour_dialog.h"

#include <QMenu>

TBehaviourDialog::TBehaviourDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TBehaviourDialog)
{
    ui->setupUi(this);

    QMenu *cmdMenu = new QMenu();
    QAction *act1 = new QAction("go to frame");
    QAction *act2 = new QAction("goToNetPage");
    QAction *act3 = new QAction("go to the frame");
    QAction *act4 = new QAction("if sprite..intersects..Then...end if");
    connect(act1, &QAction::triggered, this, [=]() {
        ui->plainTextEdit->insertPlainText("go to frame ");
    });
    connect(act2, &QAction::triggered, this, [=]() {
        ui->plainTextEdit->insertPlainText("goToNetPage ");
    });
    connect(act3, &QAction::triggered, this, [=]() {
        ui->plainTextEdit->insertPlainText("go to the frame");
    });
    connect(act4, &QAction::triggered, this, [=]() {
        ui->plainTextEdit->insertPlainText("if sprite  intersects  Then\n \nend if");
        ui->plainTextEdit->moveCursor(QTextCursor::Up);
    });
    cmdMenu->addAction(act1);
    cmdMenu->addAction(act2);
    cmdMenu->addAction(act3);
    cmdMenu->addAction(act4);
    ui->btnComands->setMenu(cmdMenu);
    ui->btnComands->setPopupMode(QToolButton::InstantPopup);
}

TBehaviourDialog *TBehaviourDialog::_instance = nullptr;
TBehaviourDialog *TBehaviourDialog::instance(QWidget *parent)
{
    if (_instance == nullptr) {
        _instance = new TBehaviourDialog(parent);
    }
    return _instance;
}

int TBehaviourDialog::show(const QString &script, int line, int col)
{
    ui->plainTextEdit->clear();
    ui->plainTextEdit->insertPlainText(script);
    if (line >= 0){
        ui->plainTextEdit->moveCursor(QTextCursor::Start);
        int lineNb = 0;
        while (lineNb < line) {
            ui->plainTextEdit->moveCursor(QTextCursor::Down);
            lineNb++;
        }
        ui->plainTextEdit->moveCursor(QTextCursor::StartOfLine);
        int colNb = 0;
        while (colNb < col) {
            ui->plainTextEdit->moveCursor(QTextCursor::NextCharacter);
            colNb++;
        }
    }
    int res = _instance->exec();
    return res;
}

QString TBehaviourDialog::script() const
{
    return ui->plainTextEdit->toPlainText();
}

TBehaviourDialog::~TBehaviourDialog()
{
    delete ui;
}

void TBehaviourDialog::on_btnAdd_clicked()
{
    ui->plainTextEdit->moveCursor(QTextCursor::End);

    const QString &eventName = ui->cbxEvents->currentText();
    QString eventScript = QString("on %0\n\nend").arg(eventName);
    ui->plainTextEdit->insertPlainText(eventScript);
    ui->plainTextEdit->moveCursor(QTextCursor::Up);
}

void TBehaviourDialog::on_buttonBox_accepted()
{
    _instance->close();
}

void TBehaviourDialog::on_buttonBox_rejected()
{
    _instance->close();
}
