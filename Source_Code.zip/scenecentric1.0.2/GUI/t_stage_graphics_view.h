/****************************************************************************
**
** This is the view for the stageScene. In this class ability to selecting objects
**  or adding items are handled.
**
****************************************************************************/

#if !defined(_SECTIONVIEW_H)
#define _SECTIONVIEW_H

#include <QGraphicsView>
#include <QEvent>
#include <QRubberBand>

#include "Logic/Timeline/t_timeline_rect_item.h"

class TStageGraphicsView : public QGraphicsView
{
    Q_OBJECT
public:
    TStageGraphicsView();
    void init();
    void mousePressEvent(QMouseEvent*);
    void mouseMoveEvent(QMouseEvent*);
    void mouseReleaseEvent(QMouseEvent*);

signals:

private:
    int ec, rc, ic, lc, tc;
    QPointF _firstPoint;  // position which mouse press when an item will be drawn
    QPoint _rb_firstPoint;  // rubber band position which mouse press when an item will be drawn
    QRubberBand* _rubberBand;

};

#endif  //_SECTIONVIEW_H
