#ifndef T_BEHAVIOUR_DIALOG_H
#define T_BEHAVIOUR_DIALOG_H

#include <QDialog>

namespace Ui {
class TBehaviourDialog;
}

class TBehaviourDialog : public QDialog
{
    Q_OBJECT

public:
    static TBehaviourDialog *instance(QWidget *parent);
    int show(const QString &script, int line = -1, int col = -1);
    QString script() const;
    ~TBehaviourDialog();

private slots:
    void on_btnAdd_clicked();
    void on_buttonBox_accepted();
    void on_buttonBox_rejected();

private:
    static TBehaviourDialog *_instance;
    explicit TBehaviourDialog(QWidget *parent = 0);
    Ui::TBehaviourDialog *ui;
};

#endif // T_BEHAVIOUR_DIALOG_H
