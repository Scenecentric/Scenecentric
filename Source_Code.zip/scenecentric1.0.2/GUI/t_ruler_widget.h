/****************************************************************************
**
** Rule widget is used to display ruler for stageView object.
**
****************************************************************************/

#if !defined(_RULERWIDGET_H)
#define _RULERWIDGET_H

#include <QWidget>

#include <QGridLayout>
#include <QSlider>

class MainWindow;

namespace Ui {
class PlotWidget;
}

class RulerWidget : public QWidget
{
    Q_OBJECT
public:
    RulerWidget(Qt::Orientation orient, QWidget* parent = 0);
    ~RulerWidget();

    void setRulerMaximumWidth (int width);
    int  rulerMaximumWidth();
    void setRulerMaximum      (int max);
    int  rulerMaximum ();
    void setRulerMinimumWidth (int width);
    int  rulerMinimumWidth();
    void setRulerValue        (int val);
    void setRulerMaximumHeight (int height);
    void setRulerMinimumHeight (int height);
    void setScrollSpacerSize(int w, int h);
    void rulerUpdate();
    QSize rulerSizeHint();

private:
    Ui::PlotWidget *ui;
    QGridLayout* _layout;
    QSpacerItem* _leftSpacer;
    QSpacerItem* _rightSpacer;
    QSpacerItem* _scrollSpacer;
    QSlider* _slider;
    int _height;
    int _width;

};

#endif  //_RULERWIDGET_H
