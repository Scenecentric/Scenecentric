#include "t_plot_widget.h"
#include "ui_plotwidget.h"
//#include <QPainter>
#include "Logic/t_image_item.h"
#include "Logic/t_text_item.h"
#include "Logic/t_ellipse_item.h"
#include "Logic/t_rect_item.h"
#include "Logic/t_line_item.h"
#include "global.h"
#include <qevent.h>

#include <QMessageBox>
#include "mainwindow.h"
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QDebug>

PlotWidget::PlotWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PlotWidget)
{
    ui->setupUi(this);

    _logManager = new LogManager();

    MainWindow* mainW = MainWindow::getInstance();

    _setDefaultSizes();

    connect(_logManager, SIGNAL(currentLogChanged(Log*)), this, SLOT(updateScenes(Log*)));
    connect(_logManager, SIGNAL(currentLogChanged(Log*)), mainW, SLOT(on_currentLogChanged(Log*)));

    _stageView = new TStageGraphicsView();

    _topSpacer = new QSpacerItem(40, _viewMargin, QSizePolicy::Fixed, QSizePolicy::Expanding);
    _bottomSpacer = new QSpacerItem(40, _viewMargin, QSizePolicy::Fixed, QSizePolicy::Expanding);

    _setPlotSizes();

    _stageView->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

    _stageView->setAlignment(Qt::AlignLeft | Qt::AlignTop);

    _layout = new QGridLayout;
    _layout->addItem(_topSpacer,0 ,0);
    _layout->addWidget(_stageView, 1, 0);
    _layout->addItem(_bottomSpacer,2 ,0);

    _layout->setSpacing(0);
    _layout->setMargin(0);

    setLayout(_layout);

    logManager()->setCurrentLog(Log::sampleLog());
}

PlotWidget::~PlotWidget()
{
    delete ui;
}

void PlotWidget::_setDefaultSizes()
{
    _viewWidth = 500;
    _centerViewHeight = 400;
    _defaultViewSpacerHeight = 5;
    _viewMargin = 10;
}
qreal PlotWidget::scale() const
{
    return _scale;
}

void PlotWidget::updateScene(QList<QGraphicsItem *> items)
{
    QGraphicsScene *scene = _logManager->currentLog()->plotSectionScene();
    const QList<QGraphicsItem*> &currItems = scene->items();
    foreach (QGraphicsItem *item, currItems) {
        if (items.contains(item) == false)
            scene->removeItem(item);
    }
    foreach (QGraphicsItem *item, items) {
        if (scene->items().contains(item) == false)
            scene->addItem(item);
    }
}

void PlotWidget::ensureItemsFitInside()
{
    if (_stageView->scene()){
        foreach (QGraphicsItem *item, _stageView->scene()->items()) {
            if (!_stageView->scene()->sceneRect().contains(item->sceneBoundingRect())){
                item->moveBy(-1, -1);
                item->moveBy(1, 1);
            }
        }
    }
}


void PlotWidget::_setPlotSizes()
{
    _stageView->setMinimumSize(_viewWidth * _scale + (1.0+ 2.0 * _scale) * 2.0 , _centerViewHeight * _scale + (1.0+ 2.0 * _scale) * 2.0 );
    _stageView->setMaximumSize(_viewWidth * _scale + (1.0+ 2.0 * _scale) * 2.0 , _centerViewHeight * _scale + (1.0+ 2.0 * _scale) * 2.0 );

    if (_stageView->scene())
        _stageView->scene()->setSceneRect(0, 0, _viewWidth, _centerViewHeight);

    _height =  _stageView->height() + _viewMargin + 2.0 * _defaultViewSpacerHeight * _scale + _viewMargin;
    _width = _stageView->width() + _viewMargin * 2.0;
    setMinimumHeight(_height);
    setMinimumWidth(_width);
}

void PlotWidget::_setSceneSizes(Log *log)
{
    log->plotSectionScene()->setSceneRect(0,0,_viewWidth,_centerViewHeight);
    _stageView->setSceneRect(-2,-2,_viewWidth,_centerViewHeight);
}

LogManager *PlotWidget::logManager() const
{
    return _logManager;
}

void PlotWidget::setLogManager(LogManager *logManager)
{
    _logManager = logManager;
}

TStageGraphicsView *PlotWidget::plotSectionView() const
{
    return _stageView;
}

void PlotWidget::setPlotSectionView(TStageGraphicsView *plotSectionView)
{
    _stageView = plotSectionView;
}

void PlotWidget::addItem(QGraphicsScene *scene, QGraphicsItem *item)
{
    if(!scene || !item)
        return;

    scene->addItem(item);
    emit itemAdded(item);
}

void PlotWidget::updateScenes(Log *log)
{
    _stageView->setScene(log->plotSectionScene());
    _setSceneSizes(log);
    MainWindow* mainW = MainWindow::getInstance();
    connect(log->plotSectionScene(), &QGraphicsScene::selectionChanged,
            [=] ()mutable
    {
        auto selectedItems = log->plotSectionScene()->selectedItems();
        if (selectedItems.count() > 0)
            mainW->scene_selectionChanged(selectedItems[0]);
        else
            mainW->scene_selectionChanged(nullptr);
    });

    connect(this, SIGNAL(treeViewItemChanged()), mainW, SLOT(onLogChanged()));
}

void PlotWidget::zoom(qreal scale)
{
    _scale = scale;

    _setPlotSizes();

    QMatrix matrix;
    matrix.scale(_scale, _scale);

    plotSectionView()->setMatrix(matrix);
}

void PlotWidget::wheelEvent(QWheelEvent *e)
{
    MainWindow* mainWindow = MainWindow::getInstance();
    if (e->modifiers() & Qt::ControlModifier) {
        if (e->delta() > 0)
            mainWindow->zoomSlider->setValue(mainWindow->zoomSlider->value() + 9);
        else
            mainWindow->zoomSlider->setValue(mainWindow->zoomSlider->value() - 9);

        e->accept();
    }
    else
        QWidget::wheelEvent(e);
}

QPoint PlotWidget::stageViewPos()
{
    return _stageView->pos();
}

int PlotWidget::defaultViewSpacerHeight() const
{
    return _defaultViewSpacerHeight;
}

void PlotWidget::setDefaultViewSpacerHeight(int defaultViewSpacerHeight)
{
    _defaultViewSpacerHeight = defaultViewSpacerHeight;
}

int PlotWidget::viewMargin() const
{
    return _viewMargin;
}

void PlotWidget::setViewMargin(int viewMargin)
{
    _viewMargin = viewMargin;
}

int PlotWidget::centerViewHeight() const
{
    return _centerViewHeight;
}

void PlotWidget::setCenterViewHeight(int centerViewHeight)
{
    bool decreasing = (centerViewHeight < _centerViewHeight);

    _centerViewHeight = centerViewHeight;

    _setPlotSizes();

    if (decreasing){
        ensureItemsFitInside();
    }
}

int PlotWidget::viewWidth() const
{
    return _viewWidth;
}

void PlotWidget::setViewWidth(int viewWidth)
{
    bool decreasing = (viewWidth < _viewWidth);

    _viewWidth = viewWidth;

    _setPlotSizes();

    if (decreasing){
        ensureItemsFitInside();
    }

}

