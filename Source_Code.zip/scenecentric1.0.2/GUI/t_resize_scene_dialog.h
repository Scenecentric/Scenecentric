#ifndef T_RESIZE_SCENE_DIALOG_H
#define T_RESIZE_SCENE_DIALOG_H

#include <QDialog>

namespace Ui {
class TResizeSceneDialog;
}

class TResizeScenePrivate;

class TResizeSceneDialog : public QDialog
{
    Q_OBJECT

public:
    explicit TResizeSceneDialog(QWidget *parent = 0);
    ~TResizeSceneDialog();
    void setSize(const QSize &size);
    QSize size() const;

private slots:
    void on_spbxWidth_valueChanged(int arg1);
    void on_spbxHeight_valueChanged(int arg1);

private:
    Ui::TResizeSceneDialog *ui;
    TResizeScenePrivate *m_p;

    void updateUI(const QSize &size);
    void updateAspectRatio();
};

#endif // T_RESIZE_SCENE_DIALOG_H
