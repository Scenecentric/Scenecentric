#include <QMessageBox>
#include <QFile>
#include <QDataStream>
#include <QGraphicsItem>
#include <QStandardItemModel>
#include <QtMath>
#include <QScrollBar>
#include <QDebug>
#include <QFileDialog>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "t_plot_widget.h"
#include "t_ruler_widget.h"
#include "t_resize_scene_dialog.h"
#include "Logic/t_rect_item.h"
#include "Logic/t_line_item.h"
#include "Logic/t_text_item.h"
#include "Logic/t_image_item.h"
#include "Logic/t_ellipse_item.h"

MainWindow* MainWindow::instance;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    instance = this;
    _savedPath = QString();
    setWindowTitle("Scenecentric - Untitled");
    _hasChanged = false;

    plotWidget = new PlotWidget(this);
    ui->scrollArea->setWidget(plotWidget);

    _currentTool = Item::None;

    _variantEditor = new QtTreePropertyBrowser();
    _variantFactory = new QtVariantEditorFactory();

    ui->propertiesWindow->setWidget(_variantEditor);

    ui->actionBring_Forward->setEnabled(false);
    ui->actionBring_to_Front->setEnabled(false);
    ui->actionSend_Backward->setEnabled(false);
    ui->actionSend_to_Back->setEnabled(false);

    ui->actionReset_Zoom->setEnabled(false);

    zoomSlider = new QSlider(this);
    zoomSlider->setOrientation(Qt::Horizontal);
    zoomSlider->setMinimum(-360);
    zoomSlider->setMaximum(360);
    zoomSlider->setValue(0);
    zoomSlider->setMaximumWidth(200);
    zoomSlider->setSingleStep(5);
    connect(zoomSlider, SIGNAL(valueChanged(int)), this, SLOT(updateZoom()));
    zoomPercent = new QLabel(this);
    zoomPercent->setText("999%");
    zoomPercent->setMinimumSize(zoomPercent->sizeHint());
    zoomPercent->setText("100%");
    zoomPercent->setAlignment(Qt::AlignCenter);
    ui->mainToolBar->insertWidget(ui->actionZoomOut, zoomPercent);

    // resize by actions
    ////widthSize = new QLabel(this);
    ////widthSize->setText("9999px");
    ////widthSize->setMinimumSize(widthSize->sizeHint());
    ////widthSize->setAlignment(Qt::AlignCenter);
    ////ui->mainToolBar->insertWidget(ui->actionIncreaseWidth, widthSize);
    ////updateWidthLabel();

    ////heightSize = new QLabel(this);
    ////heightSize->setText("9999px");
    ////heightSize->setMinimumSize(heightSize->sizeHint());
    ////heightSize->setAlignment(Qt::AlignCenter);
    ////ui->mainToolBar->insertWidget(ui->actionIncreaseHeight, heightSize);
    ////updateHeightLabel();

    connect(ui->mainToolBar, SIGNAL(orientationChanged(Qt::Orientation)), this, SLOT(mainToolbarOrientationChanged(Qt::Orientation)));

//    hRuler = new RulerWidget(Qt::Horizontal, this);
////    ui->horizontalRulerScrollArea->setWidget(hRuler);
//    hRuler->setMinimumHeight(hRuler->rulerSizeHint().height());
////    ui->horizontalRulerScrollArea->setMinimumHeight(hRuler->rulerSizeHint().height());
////    ui->horizontalRulerScrollArea->setMaximumHeight(hRuler->rulerSizeHint().height());
//    hRuler->setMinimumWidth(plotWidget->viewWidth() + (2 + 1) * 2 + plotWidget->viewMargin() * 2 + ui->scrollArea->verticalScrollBar()->sizeHint().width()); // 2 for margin in view. 1 for view border. 2 for number of edges
//    hRuler->setRulerMaximumWidth(plotWidget->viewWidth() + (2 + 1) * 2);
//    hRuler->setRulerMinimumWidth(plotWidget->viewWidth() + (2 + 1) * 2);
//    hRuler->setRulerMaximum(plotWidget->viewWidth());
//    hRuler->setScrollSpacerSize(ui->scrollArea->verticalScrollBar()->sizeHint().width(), 5);

    // NOTE: ruler size
//    vRuler = new RulerWidget(Qt::Vertical, this);
////    ui->verticalRulerScrollArea->setWidget(vRuler);
//    vRuler->setMinimumWidth(vRuler->rulerSizeHint().width());
////    ui->verticalRulerScrollArea->setMinimumWidth(vRuler->rulerSizeHint().width());
////    ui->verticalRulerScrollArea->setMaximumWidth(vRuler->rulerSizeHint().width());
//    vRuler->setMinimumHeight(plotWidget->centerViewHeight() + 2 * 3
//                             + plotWidget->defaultViewSpacerHeight() * 2 + plotWidget->viewMargin() * 2
//                             + ui->scrollArea->horizontalScrollBar()->sizeHint().height());
//    vRuler->setRulerMaximumHeight(plotWidget->centerViewHeight() + 2 * 3 + plotWidget->defaultViewSpacerHeight() * 2);
//    vRuler->setRulerMinimumHeight(plotWidget->centerViewHeight() + 2 * 3 + plotWidget->defaultViewSpacerHeight() * 2);
//    vRuler->setRulerMaximum(plotWidget->centerViewHeight() + 2 * 2 + plotWidget->defaultViewSpacerHeight() * 2);
//    vRuler->setScrollSpacerSize(5, ui->scrollArea->horizontalScrollBar()->sizeHint().height());

//    ui->scrollArea->setHorizontalScrollBar(ui->horizontalRulerScrollArea->horizontalScrollBar());
//    ui->horizontalRulerScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//    ui->scrollArea->setVerticalScrollBar(ui->verticalRulerScrollArea->verticalScrollBar());
//    ui->verticalRulerScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

//    ui->verticalRulerScrollArea->setFrameShape(QFrame::NoFrame);
//    ui->horizontalRulerScrollArea->setFrameShape(QFrame::NoFrame);
    ui->scrollArea->setFrameShape(QFrame::NoFrame);

//    ui->actionRuler_On_Off->setChecked(true);

    ui->itemBrowser->setMaximumWidth(400);
    ui->propertiesWindow->setMaximumWidth(400);

    ui->itemBrowser->setMinimumWidth(160);
    ui->propertiesWindow->setMinimumWidth(160);

    _currentItem = nullptr;

#if defined(DESKTOP)
    QToolBar *tbStage = new QToolBar();
    ui->hlStage->addWidget(tbStage);
    tbStage->addAction(ui->actionImage);
    tbStage->addAction(ui->actionEllipse);
    tbStage->addAction(ui->actionLine);
    tbStage->addAction(ui->actionText);
    tbStage->addAction(ui->actionRect);
    tbStage->addSeparator();
    tbStage->addAction(ui->actionBring_Forward);
    tbStage->addAction(ui->actionBring_to_Front);
    tbStage->addAction(ui->actionSend_Backward);
    tbStage->addAction(ui->actionSend_to_Back);
    tbStage->addSeparator();
    tbStage->addAction(ui->actionResize);
    // resize by actions
    ////    tbStage->addAction(ui->actionDecreaseWidth);
    ////    tbStage->addAction(ui->actionIncreaseWidth);
    ////    tbStage->addAction(ui->actionDecreaseHeight);
    ////    tbStage->addAction(ui->actionIncreaseHeight);
    tbStage->addSeparator();
    tbStage->addAction(ui->actionZoomOut);
    tbStage->addAction(ui->actionZoomIn);
    tbStage->insertWidget(ui->actionZoomIn, zoomSlider);
    tbStage->addAction(ui->actionReset_Zoom);
//    tbStage->addSeparator();
//    tbStage->addAction(ui->actionRuler_On_Off);
#endif

    // item menu/action
    _deleteAction = new QAction(QIcon("://Images//FlatLight//delete.png"), tr("&Delete"), this);
    _deleteAction->setShortcut(tr("Delete"));
    _deleteAction->setStatusTip(tr("Delete timeline"));
    connect(_deleteAction, SIGNAL(triggered()), this, SLOT(deleteItem()));

    _itemMenu = new QMenu("Item");
    _itemMenu->addAction(_deleteAction);
    _itemMenu->addSeparator();
    _itemMenu->addAction(ui->actionScript);

    QWidget *spacerWidget1 = new QWidget(this);
    spacerWidget1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    spacerWidget1->setVisible(true);
    QWidget *spacerWidget2 = new QWidget(this);
    spacerWidget2->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    spacerWidget2->setVisible(true);
#if defined(DESKTOP)
    QToolBar *tbPlayPause = new QToolBar();
    ui->hlPlayButton->addWidget(tbPlayPause);
    tbPlayPause->addWidget(spacerWidget1);
    tbPlayPause->addAction(ui->actionRewind);
    tbPlayPause->addSeparator();
    tbPlayPause->addAction(ui->actionStop);
    tbPlayPause->addAction(ui->actionPlay);
    tbPlayPause->addAction(ui->actionPause);
    tbPlayPause->addSeparator();
    tbPlayPause->addAction(ui->actionBackward);
    tbPlayPause->addAction(ui->actionForward);
    tbPlayPause->addSeparator();
    tbPlayPause->addAction(ui->actionLoop);
    tbPlayPause->addWidget(spacerWidget2);
#endif

    _gridScene = new TGridScene(_itemMenu);
    ui->gvScore->setScene(_gridScene);
    ui->gvScore->setSceneRect(0, 0, 10000, 10000);
    ui->dwScore->setGeometry(300, 150, 500, 600);
#if defined(DESKTOP)
    ui->dwStage->setGeometry(305 + ui->dwScore->width(), 150, ui->dwStage->width(), 600);
#endif

    _timer.setInterval(static_cast<int>(1000.0 / 24.0));  // 24 fps for now!
    connect(plotWidget, SIGNAL(itemAdded(QGraphicsItem*)),
            _gridScene, SLOT(itemAdded(QGraphicsItem*)));
    connect(_gridScene, SIGNAL(frameItems(QList<QGraphicsItem*>)),
            plotWidget, SLOT(updateScene(QList<QGraphicsItem*>)));
    connect(&_timer, SIGNAL(timeout()), this, SLOT(playAnimation()));
    connect(_gridScene, &TGridScene::itemsChanged, this, [=]() {
        _hasChanged = true;
        ui->actionScript->setEnabled(_gridScene->selectedItems().count() > 0);

        if (_gridScene->selectedItems().count() == 0) {
            ui->actionInsert_Key_Frame->setEnabled(false);
        } else {
            ui->actionInsert_Key_Frame->setEnabled(true);
        }
    });

    TStageScene *stageScene = plotWidget->logManager()->currentLog()->plotSectionScene();
    connect(stageScene, &TStageScene::scenePressed, this, [=]() {
        _hasChanged = true;
    });
    connect(_gridScene, SIGNAL(behaviorWidgetReq(TTimelineBehaviour*)),
            this, SLOT(onBehaviorWidgetReqFromScriptLayer(TTimelineBehaviour*)));
    connect(_gridScene, SIGNAL(allFramesAreDeactivated()), stageScene,
            SLOT(deactivateAnimatingPath()));

#if defined(PLAYER)
//    ui->dwStage->setGeometry(305 + ui->dwScore->width(), 150, ui->dwStage->width(), 600);
    ui->itemBrowser->setVisible(false);
    ui->dwScore->setVisible(false);
    ui->mainToolBar->setVisible(false);
    ui->propertiesWindow->setVisible(false);
    zoomSlider->setVisible(false);
    setCentralWidget(ui->dwStage);

    ui->dwStage->setTitleBarWidget(new QWidget());
    ui->dwStage->setWindowTitle("");

    load("animator.sctc");

    ui->actionRewind->trigger();
    ui->actionLoop->setChecked(true);
    ui->actionPlay->trigger();
#endif
}

MainWindow::~MainWindow()
{
    delete ui;
    instance = nullptr;
}

void MainWindow::closeEvent(QCloseEvent *)
{

#if defined(DESKTOP)
    if (_hasChanged) {
        QMessageBox msgBox;
        msgBox.setText("The document has been modified.");
        msgBox.setInformativeText("Do you want to save your changes?");
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Save);
        int ret = msgBox.exec();
        switch (ret) {
        case QMessageBox::Save:
            on_actionSave_triggered();
            break;
        case QMessageBox::Discard:
            // Don't Save was clicked
            break;
        case QMessageBox::Cancel:
            return;
            break;
        default:
            // should never be reached
            break;
        }
    }
#endif
}

void MainWindow::on_actionNew_triggered()
{
    if (_hasChanged) {
        QMessageBox msgBox;
        msgBox.setText("The document has been modified.");
        msgBox.setInformativeText("Do you want to save your changes?");
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        msgBox.setDefaultButton(QMessageBox::Save);
        int ret = msgBox.exec();
        switch (ret) {
        case QMessageBox::Save:
            on_actionSave_triggered();
            break;
        case QMessageBox::Discard:
            // Don't Save was clicked
            break;
        case QMessageBox::Cancel:
            return;
            break;
        default:
            // should never be reached
            break;
        }
    }
    //    plotWidget->logManager()->newLog();
    _gridScene->clearGrid();
    plotWidget->logManager()->newLog();


    plotWidget->_setDefaultSizes();
    plotWidget->_setPlotSizes();
    plotWidget->_setSceneSizes(plotWidget->logManager()->currentLog());

    if (zoomSlider->value())
        zoomSlider->setValue(0);
    else
        emit zoomSlider->valueChanged(0);

    ui->actionReset_Zoom->setEnabled(false);
    plotWidget->plotSectionView()->init();
    setWindowTitle("Scenecentric - Untitled");
    _hasChanged = false;
    _savedPath = QString();
}

void MainWindow::save(const QString &filePath)
{
    QFile file(filePath);

    if (!file.open(QIODevice::ReadWrite)){
        QMessageBox::information(this,tr("unable to open file"),file.errorString());
        return;
    } else {
        _savedPath = filePath;
        QDataStream out(&file);
        out << *_gridScene;
        file.close();
        setWindowTitle("Scenecentric - " + _savedPath);
        statusBar()->showMessage(QString("%0 saved successfully!").arg(_savedPath));
        _hasChanged = false;
    }
}

void MainWindow::load(const QString &filePath)
{
    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly)){
        QMessageBox::information(this,tr("unable to open file"),file.errorString());
        return;
    } else {
        // if any project is open we should ask the user that do you want to save the project
        QDataStream in(&file);
        in >> *_gridScene;
        file.close();
        _savedPath = filePath;
        setWindowTitle("Scenecentric - " + _savedPath);
        statusBar()->showMessage(QString("%0 loaded successfully!").arg(_savedPath));
        _hasChanged = false;
    }
}

void MainWindow::on_actionOpen_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Project"),
                                                    QString(),
                                                    tr("Scenecentric (*.sctc)"));
    plotWidget->_setPlotSizes();
    if (zoomSlider->value())
        zoomSlider->setValue(0);
    else
        emit zoomSlider->valueChanged(0);
    ui->actionReset_Zoom->setEnabled(false);
    plotWidget->plotSectionView()->init();

    if (!fileName.isEmpty()) {
        load(fileName);
    }
}

void MainWindow::on_actionSave_triggered()
{
    if (_savedPath.isEmpty()) {
        QString str = QFileDialog::getSaveFileName(this, tr("Save Project"),
                                                   QString(), tr("Scenecentric (*.sctc)"));
        save(str);
    } else {
        save(_savedPath);
    }
}

void MainWindow::on_actionAddItem_triggered()
{	
}

Item::ItemType MainWindow::currentTool() const
{
    return _currentTool;
}

void MainWindow::setCurrentTool(const Item::ItemType &currentTool)
{
    _currentTool = currentTool;
}

void MainWindow::on_actionEllipse_toggled(bool arg1)
{
    if (arg1)
    {
        ui->actionLine->setChecked(false);
        ui->actionText->setChecked(false);
        ui->actionRect->setChecked(false);
        ui->actionImage->setChecked(false);
        _currentTool = Item::Ellipse;
    }
    else
    {
        _currentTool = Item::None;
    }
}

void MainWindow::on_actionLine_toggled(bool arg1)
{
    if (arg1)
    {
        ui->actionText->setChecked(false);
        ui->actionEllipse->setChecked(false);
        ui->actionRect->setChecked(false);
        ui->actionImage->setChecked(false);
        _currentTool = Item::Line;
    }
    else
    {
        _currentTool = Item::None;
    }
}

void MainWindow::on_actionText_toggled(bool arg1)
{
    if (arg1)
    {
        ui->actionLine->setChecked(false);
        ui->actionEllipse->setChecked(false);
        ui->actionRect->setChecked(false);
        ui->actionImage->setChecked(false);
        _currentTool = Item::Text;
    }
    else
    {
        _currentTool = Item::None;
    }
}

void MainWindow::on_actionRect_toggled(bool arg1)
{
    if (arg1)
    {
        ui->actionLine->setChecked(false);
        ui->actionEllipse->setChecked(false);
        ui->actionText->setChecked(false);
        ui->actionImage->setChecked(false);
        _currentTool = Item::Rect;
    }
    else
    {
        _currentTool = Item::None;
    }
}

void MainWindow::on_actionImage_toggled(bool arg1)
{
    if (arg1)
    {
        ui->actionLine->setChecked(false);
        ui->actionEllipse->setChecked(false);
        ui->actionText->setChecked(false);
        ui->actionRect->setChecked(false);
        _currentTool = Item::Image;
    }
    else
    {
        _currentTool = Item::None;
    }
}

void MainWindow::scene_selectionChanged(QGraphicsItem *selectedItem)
{
    if (_gridScene->beforeSetFrame())
        return;
    _gridScene->onItemsSelectionChanged(selectedItem);
    if (selectedItem == nullptr)
    {
        _currentItem = selectedItem;
        _variantEditor->clear();
        ui->propertiesWindow->setWindowTitle("Select an object");
        ui->actionBring_Forward->setEnabled(false);
        ui->actionBring_to_Front->setEnabled(false);
        ui->actionSend_Backward->setEnabled(false);
        ui->actionSend_to_Back->setEnabled(false);
        emit plotWidget->treeViewItemChanged();
        return;
    }
    ui->actionBring_Forward->setEnabled(true);
    ui->actionBring_to_Front->setEnabled(true);
    ui->actionSend_Backward->setEnabled(true);
    ui->actionSend_to_Back->setEnabled(true);

    _currentItem = selectedItem;

    ui->actionLine->setChecked(false);
    ui->actionEllipse->setChecked(false);
    ui->actionRect->setChecked(false);
    ui->actionImage->setChecked(false);
    ui->actionText->setChecked(false);
    _currentTool = Item::None;

    int sss = selectedItem->type();
    ui->propertiesWindow->setWindowTitle(
                QString("Changed - Selected Item: %0").arg(sss));

    switch (selectedItem->type())
    {
    case Item::Text:
    {
        TextItem *textItem = dynamic_cast<TextItem*>(selectedItem);
        _variantEditor->setFactoryForManager(textItem->propertyManager(),_variantFactory);
        _variantEditor->clear();
        _variantEditor->addProperty(textItem->properties());
        _variantEditor->setPropertiesWithoutValueMarked(true);
        _variantEditor->setRootIsDecorated(false);
        for (int counter = 0; counter < textItem->properties()->subProperties().length(); counter++)
        {
            _variantEditor->setExpanded(_variantEditor->items(textItem->properties()->subProperties()[counter])[0],false);
        }
    }
        break;
    case Item::Rect:
    {
        RectItem *rectItem = dynamic_cast<RectItem*>(selectedItem);
        _variantEditor->setFactoryForManager(rectItem->propertyManager(),_variantFactory);
        _variantEditor->clear();
        _variantEditor->addProperty(rectItem->properties());
        _variantEditor->setPropertiesWithoutValueMarked(true);
        _variantEditor->setRootIsDecorated(false);
        for (int counter = 0; counter < rectItem->properties()->subProperties().length(); counter++)
        {
            _variantEditor->setExpanded(_variantEditor->items(rectItem->properties()->subProperties()[counter])[0],false);
        }
    }
        break;
    case Item::Line:
    {
        LineItem *lineItem = dynamic_cast<LineItem*>(selectedItem);
        _variantEditor->setFactoryForManager(lineItem->propertyManager(),_variantFactory);
        _variantEditor->clear();
        _variantEditor->addProperty(lineItem->properties());
        _variantEditor->setPropertiesWithoutValueMarked(true);
        _variantEditor->setRootIsDecorated(false);
        for (int counter = 0; counter < lineItem->properties()->subProperties().length(); counter++)
        {
            _variantEditor->setExpanded(_variantEditor->items(lineItem->properties()->subProperties()[counter])[0],false);
        }
    }
        break;
    case Item::Image:
    {
        ImageItem *imageItem = dynamic_cast<ImageItem*>(selectedItem);
        _variantEditor->setFactoryForManager(imageItem->propertyManager(),_variantFactory);
        _variantEditor->clear();
        _variantEditor->addProperty(imageItem->properties());
        _variantEditor->setPropertiesWithoutValueMarked(true);
        _variantEditor->setRootIsDecorated(false);
        for (int counter = 0; counter < imageItem->properties()->subProperties().length(); counter++)
        {
            _variantEditor->setExpanded(_variantEditor->items(imageItem->properties()->subProperties()[counter])[0],false);
        }
    }
        break;
    case Item::Ellipse:
    {
        EllipseItem *ellipseItem = dynamic_cast<EllipseItem*>(selectedItem);
        _variantEditor->setFactoryForManager(ellipseItem->propertyManager(),_variantFactory);
        _variantEditor->clear();
        _variantEditor->addProperty(ellipseItem->properties());
        _variantEditor->setPropertiesWithoutValueMarked(true);
        _variantEditor->setRootIsDecorated(false);
        for (int counter = 0; counter < ellipseItem->properties()->subProperties().length(); counter++)
        {
            _variantEditor->setExpanded(_variantEditor->items(ellipseItem->properties()->subProperties()[counter])[0],false);
        }
    }
        break;
    default:
        break;
    }
    emit plotWidget->treeViewItemChanged();
    ui->treeView->setFocus();
}

void MainWindow::fixRulerWidgetSize()
{
//    if (this->isVisible())
//    {
//        if (ui->scrollArea->size().height() > plotWidget->minimumHeight())
//        {
//            hRuler->setScrollSpacerSize(0 , 5);
//            hRuler->setMinimumWidth(plotWidget->minimumWidth());
//        }
//        else
//        {
//            hRuler->setScrollSpacerSize( ui->scrollArea->verticalScrollBar()->sizeHint().width(), 5);
//            hRuler->setMinimumWidth(plotWidget->minimumWidth() + ui->scrollArea->verticalScrollBar()->sizeHint().width());
//        }

//        if (ui->scrollArea->size().width() > plotWidget->minimumWidth())
//        {
//            vRuler->setScrollSpacerSize(5 , 0);
//            vRuler->setMinimumHeight(plotWidget->minimumHeight());
//        }
//        else
//        {
//            vRuler->setScrollSpacerSize(5, ui->scrollArea->horizontalScrollBar()->sizeHint().height());
//            vRuler->setMinimumHeight(plotWidget->minimumHeight() + ui->scrollArea->horizontalScrollBar()->sizeHint().height());
//        }

//    }
}

void MainWindow::on_currentLogChanged(Log* lg)
{
    QStandardItemModel *model = new QStandardItemModel;

    QStandardItem *item = new QStandardItem("Scenecentric");
    item->setData(qVariantFromValue((void*)nullptr), Qt::UserRole);
    model->setItem(0, 0, item);

    QStandardItem* childP = new QStandardItem("Items");
    childP->setData(qVariantFromValue((void*)nullptr), Qt::UserRole);
    item->appendRow(childP);

    foreach(QGraphicsItem* ip, lg->plotSectionScene()->items())
    {
        QStandardItem* newChild = nullptr;
        attachTreeNodeToGraphicsItem(newChild, ip, childP);
    }

    ui->treeView->setModel(model);

    ui->treeView->expandAll();
    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

void MainWindow::attachTreeNodeToGraphicsItem(QStandardItem* treeItem, QGraphicsItem* gItem, QStandardItem* parentItem)
{
    switch (gItem->type())
    {
    case Item::Ellipse:
    {
        EllipseItem* ei = static_cast<EllipseItem*>(gItem);
        treeItem = new QStandardItem("Ellipse" + ei->objectName());
        parentItem->appendRow(treeItem);
        treeItem->setData(qVariantFromValue((void*)gItem), Qt::UserRole);
    } break;
    case Item::Text:
    {
        TextItem* ti = static_cast<TextItem*>(gItem);
        treeItem = new QStandardItem("Text" + ti->objectName());
        parentItem->appendRow(treeItem);
        treeItem->setData(qVariantFromValue((void*)gItem), Qt::UserRole);
    } break;
    case Item::Line:
    {
        LineItem* li = static_cast<LineItem*>(gItem);
        treeItem = new QStandardItem("Line" + li->objectName());
        parentItem->appendRow(treeItem);
        treeItem->setData(qVariantFromValue((void*)gItem), Qt::UserRole);
    } break;
    case Item::Image:
    {
        ImageItem* ii = static_cast<ImageItem*>(gItem);
        treeItem = new QStandardItem("Image" + ii->objectName());
        parentItem->appendRow(treeItem);
        treeItem->setData(qVariantFromValue((void*)gItem), Qt::UserRole);
    } break;
    case Item::Rect:
    {
        RectItem* ri = static_cast<RectItem*>(gItem);
        treeItem = new QStandardItem("Rectangle" + ri->objectName());
        parentItem->appendRow(treeItem);
        treeItem->setData(qVariantFromValue((void*)gItem), Qt::UserRole);
    } break;
    }
}

void MainWindow::on_treeView_doubleClicked(const QModelIndex &index)
{
    QGraphicsItem* item = static_cast<QGraphicsItem*>(index.data(Qt::UserRole).value<void*>());
    if (item != nullptr) {
        int x = item->type();
        QMessageBox::information(0, "", QString("%0").arg(x));
    }
}

void MainWindow::onLogChanged()
{
    on_currentLogChanged(plotWidget->logManager()->currentLog());
    setTreeViewItemSelected();
}

void MainWindow::on_actionBring_Forward_triggered()
{
    int currentItemID = 0;
    int topItemID = -1;
    QList<QGraphicsItem *> _currentSceneItems = _currentItem->scene()->items();

    if (_currentSceneItems.count()>0) {
        for (int i=0 ; i<_currentSceneItems.size() ; i++) {
            if (_currentSceneItems[i]==_currentItem)
                currentItemID = i;
            if (_currentSceneItems[i]->zValue()==_currentItem->zValue()+1)
                topItemID = i;
        }
        if (topItemID != -1) {
            _currentSceneItems[topItemID]->setZValue(_currentSceneItems[currentItemID]->zValue());
            _currentSceneItems[currentItemID]->setZValue(_currentSceneItems[currentItemID]->zValue()+1);
            emit plotWidget->treeViewItemChanged();
            return;
        }
    }
}

void MainWindow::on_actionBring_to_Front_triggered()
{
    QList<QGraphicsItem *> _currentSceneItems = _currentItem->scene()->items();
    int currentItemID = 0;
    int *topItemsID = new int[_currentSceneItems.size()];
    int topItemsIDCounter = 0;
    int frontItemID = -1;

    if (_currentSceneItems.count()>0) {
        for (int i=0 ; i<_currentSceneItems.size() ; i++) {
            if (_currentSceneItems[i]==_currentItem)
                currentItemID = i;
            if (_currentSceneItems[i]->zValue()>_currentItem->zValue()) {
                if (frontItemID != -1) {
                    if (_currentSceneItems[i]->zValue()>_currentSceneItems[frontItemID]->zValue())
                        frontItemID = i;
                } else {
                    frontItemID = i;
                }
                topItemsID[topItemsIDCounter] = i;
                topItemsIDCounter++;
            }
        }

        if (frontItemID != -1) {
            _currentSceneItems[currentItemID]->setZValue(_currentSceneItems[frontItemID]->zValue());
            for (int i = 0 ; i < topItemsIDCounter ;i++) {
                _currentSceneItems[topItemsID[i]]->setZValue(_currentSceneItems[topItemsID[i]]->zValue()-1);
            }
            emit plotWidget->treeViewItemChanged();
        }
    }
}

void MainWindow::on_actionSend_to_Back_triggered()
{
    QList<QGraphicsItem *> _currentSceneItems = _currentItem->scene()->items();
    int currentItemID = 0;
    int *bottomItemsID = new int[_currentSceneItems.size()];
    int bottomItemsIDCounter = 0;
    int backItemID = -1;
    if (_currentSceneItems.count() > 0) {
        for (int i=0 ; i<_currentSceneItems.size() ; i++) {
            if (_currentSceneItems[i]==_currentItem)
                currentItemID = i;
            if (_currentSceneItems[i]->zValue()<_currentItem->zValue()) {
                if (backItemID!=-1) {
                    if (_currentSceneItems[i]->zValue()<_currentSceneItems[backItemID]->zValue())
                        backItemID = i;
                } else {
                    backItemID = i;
                }
                bottomItemsID[bottomItemsIDCounter] = i;
                bottomItemsIDCounter++;
            }
        }

        if (backItemID != -1) {
            _currentSceneItems[currentItemID]->setZValue(_currentSceneItems[backItemID]->zValue());
            for (int i=0 ; i < bottomItemsIDCounter ; i++) {
                _currentSceneItems[bottomItemsID[i]]->setZValue(_currentSceneItems[bottomItemsID[i]]->zValue()+1);
            }
            emit plotWidget->treeViewItemChanged();
        }
    }
}

void MainWindow::on_actionSend_Backward_triggered()
{
    int currentItemID = 0;
    int downItemID = -1;
    QList<QGraphicsItem *> _currentSceneItems = _currentItem->scene()->items();

    if (_currentSceneItems.count() > 0) {
        for (int i=0 ; i<_currentSceneItems.size() ; i++) {
            if (_currentSceneItems[i]==_currentItem)
                currentItemID = i;
            if (_currentSceneItems[i]->zValue()==_currentItem->zValue()-1)
                downItemID = i;
        }

        if (downItemID!=-1) {
            _currentSceneItems[downItemID]->setZValue(_currentSceneItems[currentItemID]->zValue());
            _currentSceneItems[currentItemID]->setZValue(_currentSceneItems[currentItemID]->zValue()-1);
            emit plotWidget->treeViewItemChanged();
            return;
        }
    }
}

void MainWindow::on_actionZoomIn_triggered()
{
    if (zoomSlider->value() >= 0)
        zoomSlider->setValue( floor(qreal(zoomSlider->value()) / 9.0) * 9.0 + 9.0);
    else
    {
        zoomSlider->setValue( floor(qreal(zoomSlider->value()) / 40.0) * 40.0 + 40.0);
    }
}

void MainWindow::on_actionZoomOut_triggered()
{
    if (zoomSlider->value() > 0)
        zoomSlider->setValue(ceil(qreal(zoomSlider->value()) / 9) * 9 - 9);
    else
    {
        zoomSlider->setValue(ceil(qreal(zoomSlider->value()) / 40) * 40 - 40);
    }
}

void MainWindow::on_actionReset_Zoom_triggered()
{
    zoomSlider->setValue(0);
    ui->actionReset_Zoom->setEnabled(false);
}

void MainWindow::updateZoom()
{
    if (zoomSlider->value())
        ui->actionReset_Zoom->setEnabled(true);
    else
        ui->actionReset_Zoom->setEnabled(false);
    qreal scale = 1.0;
    if (zoomSlider->value() < 0)
        scale = 1.0 + qreal(zoomSlider->value()) / 400.0;
    else
        scale = 1.0 + qreal(zoomSlider->value()) / 90.0;

    //fix scrollbar location
//    int vertScrlVal = ui->scrollArea->verticalScrollBar()->value();
//    int vertScrlHeight = plotWidget->minimumHeight();

//    int horizScrlVal = ui->scrollArea->horizontalScrollBar()->value();
//    int horizScrlWidth = plotWidget->minimumWidth();

//    int vPageStep = ui->scrollArea->verticalScrollBar()->pageStep();
//    int hPageStep = ui->scrollArea->horizontalScrollBar()->pageStep();

    plotWidget->zoom(scale);
    zoomPercent->setText(QString("%0").arg(qRound(100 * scale) )+tr("%"));

//    int newVertScrlHeight = plotWidget->minimumHeight();
//    int newHorizScrlWidth = plotWidget->minimumWidth();

//    ui->scrollArea->verticalScrollBar()->setValue((vertScrlVal + vPageStep / 2) * newVertScrlHeight / vertScrlHeight - vPageStep / 2);
//    ui->scrollArea->horizontalScrollBar()->setValue((horizScrlVal + hPageStep / 2) * newHorizScrlWidth / horizScrlWidth - hPageStep / 2);

    //NOTE: ruler size
//    vRuler->setRulerMinimumHeight(newVertScrlHeight - plotWidget->viewMargin() * 2);
//    vRuler->setMinimumHeight(newVertScrlHeight + ui->scrollArea->horizontalScrollBar()->sizeHint().height());   //no need because of fix function in below
//    vRuler->setRulerMaximumHeight(newVertScrlHeight - plotWidget->viewMargin() * 2);
//    vRuler->setRulerMaximum(newVertScrlHeight - plotWidget->viewMargin() * 2 - 2 * (1 + 2 * scale));  // replace like 5 line below

//    hRuler->setRulerMinimumWidth(newHorizScrlWidth - plotWidget->viewMargin() * 2);
//    hRuler->setMinimumWidth(newHorizScrlWidth + ui->scrollArea->verticalScrollBar()->sizeHint().width()); //no need because of fix function in below
//    hRuler->setRulerMaximumWidth(newHorizScrlWidth - plotWidget->viewMargin() * 2);
//    hRuler->setRulerMaximum(newHorizScrlWidth - plotWidget->viewMargin() * 2 - 2 * (1 + 2 * scale));//plotWidget->headerView()->scene()->sceneRect().width() * scale);
//    fixRulerWidgetSize();
}

void MainWindow::mainToolbarOrientationChanged(Qt::Orientation orient)
{
    zoomSlider->setOrientation(orient);
    zoomSlider->setInvertedAppearance(true);
    zoomSlider->setMaximumWidth(30); // NOTE: Allign Center
    zoomSlider->setMinimumHeight(100);
    if (orient == Qt::Horizontal) {
        zoomSlider->setInvertedAppearance(false);
        zoomSlider->setMaximumWidth(200);
        zoomSlider->setMinimumHeight(20);
    }
}

void MainWindow::resizeEvent(QResizeEvent * event)
{
    fixRulerWidgetSize();
//    hRuler->rulerUpdate();  //NOTE: find replacement and scrollarea resize
//    vRuler->rulerUpdate();
    QMainWindow::resizeEvent(event);
}

void MainWindow::on_actionSetViews_triggered()
{
}

void MainWindow::on_actionRuler_On_Off_toggled(bool arg1)
{
//    ui->horizontalRulerScrollArea->setVisible(arg1);
//    ui->verticalRulerScrollArea->setVisible(arg1);
}

void MainWindow::on_treeView_clicked(const QModelIndex &index)
{
    QGraphicsItem* item = static_cast<QGraphicsItem*>(index.data(Qt::UserRole).value<void*>());

    if (item != nullptr)
    {
        plotWidget->plotSectionView()->scene()->clearSelection();
        _currentItem = item;
        item->setSelected(true);
        if (!item->isVisible())
            scene_selectionChanged(item);
    }
}

QGraphicsItem *MainWindow::currentItem() const
{
    return _currentItem;
}

void MainWindow::setCurrentItem(QGraphicsItem *currentItem)
{
    _currentItem = currentItem;
}


void MainWindow::setTreeViewItemSelected()
{
    if (_currentItem != nullptr) {
        int itemsCount = _currentItem->scene()->items().length();
        int rowNumber;

        if (_currentItem->scene() == plotWidget->plotSectionView()->scene())  {
            rowNumber = 0;
        }

        QModelIndex parentIndex = ui->treeView->model()->index(rowNumber,0,ui->treeView->model()->index(0,0));

        for (int counter = 0; counter < itemsCount; counter++) {
            QModelIndex currentIndex = ui->treeView->model()->index(counter, 0, parentIndex);
            if (ui->treeView->model()->data(currentIndex, Qt::UserRole) == qVariantFromValue((void*)_currentItem))
                ui->treeView->setCurrentIndex(currentIndex);
        }
    } else {
        ui->treeView->setCurrentIndex(ui->treeView->model()->index(-1,-1));
    }
}

void MainWindow::on_treeView_activated(const QModelIndex &index)
{
    QGraphicsItem* item = static_cast<QGraphicsItem*>(index.data(Qt::UserRole).value<void*>());

    if (item != nullptr)
    {
        plotWidget->plotSectionView()->scene()->clearSelection();
        _currentItem = item;
        item->setSelected(true);
        if (!item->isVisible())
            scene_selectionChanged(item);
    }
}

void MainWindow::playAnimation()
{
    if (_gridScene->isLastFrame() && !ui->actionLoop->isChecked()) {

        _gridScene->setIsPlaying(false);
        _gridScene->setFrame(_gridScene->currFrame());
        _timer.stop();
        ui->actionPlay->setEnabled(true);
        return;
    } else if (_gridScene->isLastFrame() && ui->actionLoop->isChecked()) {
        _gridScene->rewind();
    } else {
        ui->actionPlay->setEnabled(false);
    }
    _gridScene->forwardFrame();
}
MainWindow *MainWindow::getInstance()
{
    return instance;
}

void MainWindow::on_actionPlay_triggered()
{
    emit plotWidget->logManager()->currentLog()->plotSectionScene()->scenePressed();
    _gridScene->deselectAll();
    ui->actionPlay->setEnabled(false);
    ui->actionPause->setEnabled(true);
    ui->actionStop->setEnabled(true);
    ui->actionBackward->setEnabled(false);
    ui->actionForward->setEnabled(false);

    _gridScene->setIsPlaying(true);

    _timer.start();
}

void MainWindow::on_actionPause_triggered()
{
    ui->actionPlay->setEnabled(true);
    ui->actionPause->setEnabled(false);
    ui->actionStop->setEnabled(true);
    ui->actionBackward->setEnabled(true);
    ui->actionForward->setEnabled(true);
    _timer.stop();
}

void MainWindow::on_actionStop_triggered()
{
    ui->actionPlay->setEnabled(true);
    ui->actionPause->setEnabled(false);
    ui->actionStop->setEnabled(false);
    ui->actionBackward->setEnabled(true);
    ui->actionForward->setEnabled(true);
    _gridScene->setIsPlaying(false);
    _gridScene->setFrame(_gridScene->currFrame());
    _timer.stop();
}

void MainWindow::on_actionBackward_triggered()
{
    _gridScene->backwardFrame();
}

void MainWindow::on_actionForward_triggered()
{
    _gridScene->forwardFrame();
}

void MainWindow::on_actionSaveAs_triggered()
{
    QString str = QFileDialog::getSaveFileName(this, tr("Save Project"),
                                               QString(), tr("Scenecentric (*.sctc)"));
    save(str);
}

void MainWindow::deleteItem()
{
    _gridScene->deleteFromGrid();
}

void MainWindow::on_actionRewind_triggered()
{
    _gridScene->rewind();
}

void MainWindow::on_actionScript_triggered()
{
    QList<QGraphicsItem*> selectedItems = _gridScene->selectedItems();
    if (selectedItems.count() == 0)
        return;

    TTimeLineRectItem *timelineRect = dynamic_cast<TTimeLineRectItem*>(selectedItems.first());
    TTimelineBehaviour *behaviour = timelineRect->timelineData()->behaviour();
    int res =  TBehaviourDialog::instance(this)->show(behaviour->script());
    if (res == QDialog::Accepted) {
        behaviour->setScript(TBehaviourDialog::instance(this)->script());
    }
}

void MainWindow::onBehaviorWidgetReqFromScriptLayer(TTimelineBehaviour *behavior)
{
    if (behavior->script().isEmpty()) {
        behavior->setScript("on exitFrame\n\nend");
    }
    int res =  TBehaviourDialog::instance(this)->show(behavior->script(), 1, 0);
    if (res == QDialog::Accepted) {
        _gridScene->updateBehavior(behavior, TBehaviourDialog::instance(this)->script());
    } else {
        _gridScene->updateBehavior(behavior, behavior->script());
    }
}

void MainWindow::on_actionInsert_Key_Frame_triggered()
{
    QList<QGraphicsItem*> selectedItems = _gridScene->selectedItems();
    if (selectedItems.count() == 0)
        return;

    TTimeLineRectItem *timelineRect = dynamic_cast<TTimeLineRectItem*>(selectedItems.first());
    const quint16 &relFrameNb = quint16(_gridScene->currFrame() - timelineRect->column() + 1);
    if (timelineRect->keyFrame(relFrameNb) != nullptr)
        return;

    TKeyFrame *nkFrame = timelineRect->insertKeyFrame(relFrameNb);
    nkFrame->setPos(timelineRect->timelineData()->shapeItem()->pos());
}

void MainWindow::on_actionResize_triggered()
{
    TResizeSceneDialog *resizeDialog = new TResizeSceneDialog(ui->dwStage);

    QSize size;
    size.setWidth(plotWidget->viewWidth());
    size.setHeight(plotWidget->centerViewHeight());

    resizeDialog->setSize(size);

    if (resizeDialog->exec()){
        QSize size = resizeDialog->size();
        plotWidget->setViewWidth(size.width());
        plotWidget->setCenterViewHeight(size.height());
        updateWidthLabel();
        updateHeightLabel();
    }

    delete resizeDialog;
}

void  MainWindow::updateWidthLabel(){
    ////QString widthStr = QString("%0px").arg(plotWidget->viewWidth());
    ////widthSize->setText(widthStr);
}

void  MainWindow::updateHeightLabel(){
    ////QString heightStr = QString("%0px").arg(plotWidget->centerViewHeight());
    ////heightSize->setText(heightStr);
}

void MainWindow::on_actionDecreaseWidth_triggered()
{
    int width = plotWidget->viewWidth();
    if (width >= 500) {
        plotWidget->setViewWidth(width - 100);
    }
    updateWidthLabel();
}

void MainWindow::on_actionIncreaseWidth_triggered()
{
    int width = plotWidget->viewWidth();
    if (width < 2000) {
        plotWidget->setViewWidth(width + 100);
    }
    updateWidthLabel();
}

void MainWindow::on_actionDecreaseHeight_triggered()
{
    int height = plotWidget->centerViewHeight();
    if (height >= 500) {
        plotWidget->setCenterViewHeight(height - 100);
    }
    updateHeightLabel();
}

void MainWindow::on_actionIncreaseHeight_triggered()
{
    int height = plotWidget->centerViewHeight();
    if (height < 2000) {
        plotWidget->setCenterViewHeight(height + 100);
    }
    updateHeightLabel();
}
