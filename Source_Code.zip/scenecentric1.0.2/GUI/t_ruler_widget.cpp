#include "t_ruler_widget.h"
#include "ui_plotwidget.h"

#include <qevent.h>

RulerWidget::RulerWidget(Qt::Orientation orient, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PlotWidget)
{
    ui->setupUi(this);

    _leftSpacer = new QSpacerItem(5, 5, QSizePolicy::Fixed, QSizePolicy::Fixed);
    _rightSpacer = new QSpacerItem(5, 5, QSizePolicy::Fixed, QSizePolicy::Fixed);
    _scrollSpacer = new QSpacerItem(5, 5, QSizePolicy::Fixed, QSizePolicy::Fixed);

    _slider = new QSlider(this);  //TODO: replace by ruler
    _slider->setOrientation(orient);
    _slider->setMinimum(0);
    _slider->setTickPosition(QSlider::TicksRight);
    _slider->setTickInterval(20);
    _slider->setEnabled(false);

    _layout = new QGridLayout;
    if (orient == Qt::Horizontal) {
        _layout->addWidget(_slider,0 ,0);
        _layout->addItem(_scrollSpacer,0 ,1);
    } else if (orient == Qt::Vertical) {
        _layout->addWidget(_slider, 0, 0);
        _layout->addItem(_scrollSpacer,1 ,0);
    }

    _layout->setSpacing(0);
    _layout->setMargin(0);

    setLayout(_layout);
}

RulerWidget::~RulerWidget()
{
    delete ui;
}

void RulerWidget::setScrollSpacerSize(int w, int h)
{
    _scrollSpacer->changeSize(w, h, QSizePolicy::Fixed, QSizePolicy::Fixed);
}

void RulerWidget::rulerUpdate()
{
    _slider->hide();
    _slider->show();
}

QSize RulerWidget::rulerSizeHint()
{
    return _slider->sizeHint();
}

void RulerWidget::setRulerMaximumWidth(int width)
{
    _slider->setMaximumWidth(width);
}

int RulerWidget::rulerMaximumWidth()
{
    return _slider->maximumWidth();
}

void RulerWidget::setRulerMaximum(int max)
{
    _slider->setMaximum(max);
}

int RulerWidget::rulerMaximum()
{
    return _slider->maximum();
}

void RulerWidget::setRulerMinimumWidth(int width)
{
    _slider->setMinimumWidth(width);
}

int RulerWidget::rulerMinimumWidth()
{
    return _slider->minimumWidth();
}

void RulerWidget::setRulerValue(int val)
{
    _slider->setValue(val);
}

void RulerWidget::setRulerMaximumHeight(int height)
{
    _slider->setMaximumHeight(height);
}

void RulerWidget::setRulerMinimumHeight(int height)
{
    _slider->setMinimumHeight(height);
}
