/****************************************************************************
**
** PlotWidget is used to manage stage scene/view and other capabilities
**  like zooming and etc.
**
****************************************************************************/


#if !defined(_PLOTWIDGET_H)
#define _PLOTWIDGET_H

#include <QWidget>
#include <QGridLayout>
#include <QSlider>

#include "../Logic/t_log_manager.h"
#include "t_stage_graphics_view.h"

class MainWindow;

namespace Ui {
class PlotWidget;
}

class PlotWidget : public QWidget
{
    Q_OBJECT

public:
    PlotWidget(QWidget* parent = 0);
    ~PlotWidget();

    LogManager *logManager() const;
    void setLogManager(LogManager *logManager);

    TStageGraphicsView *plotSectionView() const;
    void setPlotSectionView(TStageGraphicsView *plotSectionView);

    void addItem(QGraphicsScene *scene, QGraphicsItem *item);

    void zoom(qreal scale);

    void wheelEvent(QWheelEvent *e);

    QPoint stageViewPos();

    int viewWidth() const;
    void setViewWidth(int viewWidth);

    int centerViewHeight() const;
    void setCenterViewHeight(int centerViewHeight);

    int viewMargin() const;
    void setViewMargin(int viewMargin);

    int defaultViewSpacerHeight() const;
    void setDefaultViewSpacerHeight(int defaultViewSpacerHeight);

    void _setPlotSizes();
    void _setSceneSizes(Log *log);

    void _setDefaultSizes();
    qreal scale() const;

public slots:
    void updateScene(QList<QGraphicsItem*> items);

signals:
   void treeViewItemChanged();
   void itemAdded(QGraphicsItem *item);

private:
    Ui::PlotWidget *ui;

    LogManager* _logManager;
    TStageGraphicsView* _stageView;
    QSpacerItem* _topSpacer;
    QSpacerItem* _bottomSpacer;

    QGridLayout* _layout;
    MainWindow* _mainWindow;

    int _height;
    int _width;
    qreal _scale = 1;

    int _viewWidth;
    int _centerViewHeight;
    int _viewMargin;
    int _defaultViewSpacerHeight;
    void ensureItemsFitInside();

private slots:
	void updateScenes(Log *);

};

#endif  //_PLOTWIDGET_H
