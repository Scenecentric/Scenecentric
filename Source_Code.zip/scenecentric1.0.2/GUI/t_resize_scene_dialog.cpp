#include "t_resize_scene_dialog.h"
#include "ui_t_resize_scene_dialog.h"

class TResizeScenePrivate
{
public:
    TResizeScenePrivate() {
        Width = 500;
        Height = 400;
    }
    int Width;
    int Height;
};

TResizeSceneDialog::TResizeSceneDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TResizeSceneDialog),
    m_p(new TResizeScenePrivate())
{
    ui->setupUi(this);
    updateAspectRatio();
}

TResizeSceneDialog::~TResizeSceneDialog()
{
    delete ui;
}

void TResizeSceneDialog::setSize(const QSize &size)
{
    m_p->Height = size.height();
    m_p->Width = size.width();

    updateUI(size);
}

QSize TResizeSceneDialog::size() const
{
    QSize size;
    size.setWidth(m_p->Width);
    size.setHeight(m_p->Height);

    return size;
}

void TResizeSceneDialog::updateUI(const QSize &size)
{
    ui->spbxHeight->setValue(size.height());
    ui->spbxWidth->setValue(size.width());
}

void TResizeSceneDialog::updateAspectRatio()
{
    double aspect = (double)m_p->Width / m_p->Height;
    ui->leAspectRatio->setText(QString::number(aspect, 'f', 2));
}

void TResizeSceneDialog::on_spbxWidth_valueChanged(int arg1)
{
    m_p->Width = arg1;
    updateAspectRatio();
}

void TResizeSceneDialog::on_spbxHeight_valueChanged(int arg1)
{
    m_p->Height = arg1;
    updateAspectRatio();
}
