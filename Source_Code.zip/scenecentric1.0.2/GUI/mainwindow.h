/****************************************************************************
**
** Scenecentric software is designed for making things animaged!
**
** This is mainwindow of the program which contains 4 main widgets:
** Stage: user is able to add/remove items/objects to the stage and play
**  the animation.
** Score: shows objects timelines. User is able to move the timeline
**  or expand or shrink the framelenghs.
** PropertyWindow: is used to disply properties of each object by selecting
**  corrosponding object in the stage window.
** ObjectBrowser: is used to display current objects in the stage window.
**
****************************************************************************/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QLabel>
#include <QMainWindow>
#include <QMenu>
#include <QTimer>

#include "t_plot_widget.h"
#include "t_ruler_widget.h"
#include "Logic/t_item.h"
#include "GUI/PropertyEditor/QPropertyEditorWidget.h"
#include "GUI/PropertyBrowser/qtvariantproperty.h"
#include "GUI/PropertyBrowser/qteditorfactory.h"
#include "GUI/PropertyBrowser/qttreepropertybrowser.h"
#include "GUI/PropertyBrowser/qtpropertymanager.h"
#include "Logic/Timeline/t_grid_scene.h"
#include "Logic/Timeline/t_timeline_rect_item.h"
#include "GUI/t_score_graphics_view.h"
#include "GUI/t_behaviour_dialog.h"

class QStandardItem;
class QGraphicsItem;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void closeEvent(QCloseEvent*);

    QSlider* zoomSlider;
    QLabel* zoomPercent;
    // resize by actions
    ////QLabel* widthSize;
    ////QLabel* heightSize;

    PlotWidget* plotWidget;
    Item::ItemType currentTool() const;
    void setCurrentTool(const Item::ItemType &currentTool);

//    RulerWidget* hRuler;
//    RulerWidget* vRuler;

    void scene_selectionChanged(QGraphicsItem *selectedItem);
    void setTreeViewItemSelected();
    QGraphicsItem *currentItem() const;
    void setCurrentItem(QGraphicsItem *currentItem);
    static MainWindow *getInstance();

private slots:
    void on_actionOpen_triggered();
    void on_actionAddItem_triggered();
    void on_actionSave_triggered();
    void on_actionNew_triggered();
    void on_actionEllipse_toggled(bool arg1);
    void on_actionLine_toggled(bool arg1);
    void on_actionText_toggled(bool arg1);
    void on_actionRect_toggled(bool arg1);
    void on_actionImage_toggled(bool arg1);
	void on_currentLogChanged(Log*);
	void onLogChanged();
    void on_treeView_doubleClicked(const QModelIndex &index);
    void on_actionBring_Forward_triggered();
    void on_actionBring_to_Front_triggered();
    void on_actionSend_to_Back_triggered();
    void on_actionSend_Backward_triggered();
    void on_actionZoomIn_triggered();
    void on_actionZoomOut_triggered();
    void on_actionReset_Zoom_triggered();
    void resizeEvent(QResizeEvent *event);
    void on_actionSetViews_triggered();
    void on_actionRuler_On_Off_toggled(bool arg1);
    void updateZoom();
    void mainToolbarOrientationChanged(Qt::Orientation orient);
    void on_treeView_clicked(const QModelIndex &index);
    void on_treeView_activated(const QModelIndex &index);
    void playAnimation();
    void on_actionPlay_triggered();
    void on_actionPause_triggered();
    void on_actionStop_triggered();
    void on_actionBackward_triggered();
    void on_actionForward_triggered();
    void on_actionSaveAs_triggered();
    void deleteItem();
    void on_actionRewind_triggered();
    void on_actionScript_triggered();
    void onBehaviorWidgetReqFromScriptLayer(TTimelineBehaviour *behavior);

    void on_actionInsert_Key_Frame_triggered();

    void on_actionResize_triggered();
    void on_actionDecreaseWidth_triggered();
    void on_actionIncreaseWidth_triggered();
    void on_actionDecreaseHeight_triggered();
    void on_actionIncreaseHeight_triggered();

private:
    Ui::MainWindow *ui;
    static MainWindow* instance;
    Item::ItemType _currentTool;
    QGraphicsItem * _currentItem;
    QtVariantEditorFactory *_variantFactory;
    QtTreePropertyBrowser *_variantEditor;
    QModelIndex _treeViewIndex;
    TGridScene *_gridScene;
    QTimer _timer;
//    quint16 _currFrame;
    quint16 _endFrame;
    QString _savedPath;
    bool _hasChanged;

    QAction *_deleteAction;
    QAction *_copyAction;
    QMenu *_itemMenu;


    void attachTreeNodeToGraphicsItem(QStandardItem* treeItem, QGraphicsItem* gItem,
                                      QStandardItem* parentItem);
    void fixRulerWidgetSize ();
    void save(const QString &filePath);
    void load(const QString &filePath);
    void updateWidthLabel();
    void updateHeightLabel();
};

#endif // MAINWINDOW_H
