#include "t_stage_graphics_view.h"
#include "mainwindow.h"
#include "Logic/t_ellipse_item.h"
#include "Logic/t_text_item.h"
#include "Logic/t_line_item.h"
#include "Logic/t_image_item.h"
#include "Logic/t_rect_item.h"

#include <qevent.h>

TStageGraphicsView::TStageGraphicsView()
{
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    setRenderHint(QPainter::Antialiasing);
    init();
	
	_rubberBand = nullptr;
    setMouseTracking(true);
}

void TStageGraphicsView::init()
{
    ec = tc = ic = lc = rc = 0;
}

void TStageGraphicsView::mousePressEvent(QMouseEvent *e)
{
    MainWindow* mainWindow = MainWindow::getInstance();
    Item::ItemType tool = mainWindow->currentTool();
    if(tool != Item::None) {
        _firstPoint = mapToScene(e->pos());
        _rb_firstPoint = e->pos();
        if (!_rubberBand) {
            _rubberBand = new QRubberBand(QRubberBand::Rectangle, this);
        }
        if (tool == Item::Rect || tool == Item::Ellipse || tool == Item::Line) {
            _rubberBand->setGeometry(_rb_firstPoint.x(), _rb_firstPoint.y(), 0, 0);
            _rubberBand->show();
            // NOTE: Handle it for image and text , ... here and in releaseEvent
        }
    } else {
        QGraphicsScene* pss = mainWindow->plotWidget->plotSectionView()->scene();
        if  (pss->selectedItems().length() > 0) {
                pss->clearSelection();
        } else {
            emit mainWindow->scene_selectionChanged(nullptr);
        }
        QGraphicsView::mousePressEvent(e);
        return;
    }
}

void TStageGraphicsView::mouseMoveEvent(QMouseEvent *event)
{
    MainWindow* mainWindow = MainWindow::getInstance(); // NOTE: mainWindow accessing best way
// NOTE: ruler position changed
//    mainWindow->hRuler->setRulerValue(event->pos().x() - 2 * mainWindow->plotWidget->scale());
//    mainWindow->vRuler->setRulerValue(mainWindow->vRuler->rulerMaximum() - event->pos().y() - pos().y() + mainWindow->plotWidget->stageViewPos().y() + 2 * mainWindow->plotWidget->scale() );

    if (event->buttons() == Qt::LeftButton || event->buttons() == Qt::RightButton) {
        Item::ItemType tool = mainWindow->currentTool();

        if(tool != Item::None) {
            _rubberBand->setGeometry(QRect(QPoint(_rb_firstPoint.x(),_rb_firstPoint.y()), event->pos()).normalized());
            return;
        }
    }
    QGraphicsView::mouseMoveEvent(event);
 }

void TStageGraphicsView::mouseReleaseEvent(QMouseEvent *e)
{
    MainWindow* mainWindow = MainWindow::getInstance();
    Item::ItemType tool = mainWindow->currentTool();
    if(tool != Item::None) {
        _rubberBand->hide();
        mainWindow->plotWidget->plotSectionView()->scene()->clearSelection();
        QPointF point = mapToScene(e->pos());
        QPointF pos = _firstPoint;
        QRectF rect (0,0,100,100);
        QRectF normRect;
        qreal height, width;
        QLineF line (QPointF(0,0),QPointF(100,0));

        // if mouse point is beyond view borders, this handle it
        if (point.x() > (scene()->sceneRect().width()))
            point.setX(scene()->sceneRect().width());

        if (point.x() < 0)
            point.setX(0);

        if (point.y() > (scene()->sceneRect().height()))
            point.setY(scene()->sceneRect().height());

        if (point.y() < 0)
            point.setY(0);

        normRect = QRectF(point, _firstPoint).normalized();
        height = normRect.height(); width = normRect.width();

        if (height >= 1 || width >= 1)
        {
            rect = QRectF (0, 0, width, height);
            pos = normRect.topLeft();
            line = QLineF (QPointF(0,0),point-_firstPoint);
        }

        EllipseItem* itemE;
        ImageItem* itemI;
        TextItem* itemT;
        RectItem* itemR;
        LineItem* itemL;

        switch (tool)
        {
        case Item::None:

            break;
        case Item::Ellipse:
        {
            ec++;
            itemE = new EllipseItem(pos, rect, QString("Ellipse%0").arg(ec));
            itemE->setZValue(scene()->items().size()+1);
            mainWindow->plotWidget->addItem(scene(),itemE);
            itemE->itemChange(QGraphicsItem::ItemPositionChange, pos); //  if size makes item go beyound scenerect it fixes position to avoid it
            itemE->setSelected(true);
            break;
        }
        case Item::Text:
        {
            tc++;
            itemT = new TextItem("Text", _firstPoint, QString("Text%0").arg(tc));
            itemT->setZValue(scene()->items().size()+1);
            mainWindow->plotWidget->addItem(scene(),itemT);
            itemT->itemChange(QGraphicsItem::ItemPositionChange, _firstPoint); //  if size makes item go beyound scenerect it fixes position to avoid it
            itemT->setSelected(true);
            break;
        }
        case Item::Line:
        {
            lc++;
            itemL = new LineItem(_firstPoint,line, QString("Line%0").arg(lc));
            itemL->setZValue(scene()->items().size()+1);
            mainWindow->plotWidget->addItem(scene(),itemL);
            itemL->itemChange(QGraphicsItem::ItemPositionChange, _firstPoint); //  if size makes item go beyound scenerect it fixes position to avoid it
            itemL->setSelected(true);
            break;
        }
        case Item::Rect:
        {
            rc++;
            itemR = new RectItem(pos, rect, QString("Rectangle%0").arg(rc));
            itemR->setZValue(scene()->items().size()+1);
            mainWindow->plotWidget->addItem(scene(),itemR);
            itemR->itemChange(QGraphicsItem::ItemPositionChange, pos); //  if size makes item go beyound scenerect it fixes position to avoid it
            itemR->setSelected(true);
            break;
        }
        case Item::Image:
        {
            ic++;
            itemI = new ImageItem(_firstPoint, QString("Image%0").arg(ic));
            itemI->setZValue(scene()->items().size()+1);
            mainWindow->plotWidget->addItem(scene(),itemI);
            itemI->itemChange(QGraphicsItem::ItemPositionChange, _firstPoint); //  if size makes item go beyound scenerect it fixes position to avoid it
            itemI->setSelected(true);
            break;
        }
        }
    }
    else {
        QGraphicsView::mouseReleaseEvent(e);
        return;
    }
}
