#ifndef T_TRACKABLE_GRAPHICS_VIEW_H
#define T_TRACKABLE_GRAPHICS_VIEW_H

#include <QGraphicsView>
#include <QObject>

class TScoreGraphicsView : public QGraphicsView
{
    Q_OBJECT
public:
    TScoreGraphicsView(QWidget *parent = 0);
};

#endif // T_TRACKABLE_GRAPHICS_VIEW_H
