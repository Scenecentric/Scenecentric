/****************************************************************************
**
** Scenecentric software is designed for making things animaged!
**
** This is a cross-platform open source software which is written in Qt/C++.
** The Qt5.10.0 mingw had used to build but is compatible for QtVersions > 5.5
**
** You can use either your compiler to build it.
** Note that the Qt Property lib is also used. The liscene is included
**  in the header comments.
**
****************************************************************************/

#include "GUI/mainwindow.h"
#include <QApplication>
#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;

#if defined(DESKTOP)
    w.showMaximized();
#endif

#if defined(PLAYER)
    w.resize(550,470);
    w.show();
#endif

    return a.exec();
}
