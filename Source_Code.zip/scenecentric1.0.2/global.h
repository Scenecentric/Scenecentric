#ifndef GLOBAL_H
#define GLOBAL_H

#include "GUI/mainwindow.h"


#endif // GLOBAL_H
