#if !defined(_TSTAGESCENE_H)
#define _TSTAGESCENE_H

#include <QGraphicsScene>

class TStageScene : public QGraphicsScene
{
    Q_OBJECT
public:
    TStageScene();
    void drawForeground(QPainter *painter, const QRectF &rect);
    friend QDataStream &operator<<(QDataStream &, const TStageScene &);
    friend QDataStream &operator>>(QDataStream &, TStageScene &);

    QLineF animatingPath() const;
    void setAnimatingPath(const QLineF &animatingPath);

    bool animatingPathEnabled() const;
    void setAnimatingPathEnabled(bool animatingPathEnabled);

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

public slots:
    void deactivateAnimatingPath();

signals:
    void scenePressed();
    void sceneReleased();

private:
    QLineF _animatingPath;
    bool _animatingPathEnabled;

};

QDataStream &operator<<(QDataStream &, const TStageScene &);
QDataStream &operator>>(QDataStream &, TStageScene &);

#endif  //_TSTAGESCENE_H
