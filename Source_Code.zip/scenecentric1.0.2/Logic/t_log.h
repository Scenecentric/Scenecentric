#if !defined(_LOG_H)
#define _LOG_H

#include "t_stage_scene.h"

class Log
{
public:
    Log();
    ~Log();

    static Log *sampleLog();

    TStageScene *plotSectionScene() const;
    void setPlotSectionScene(TStageScene *plotSectionScene);

    friend QDataStream &operator<<(QDataStream &, const Log &);
    friend QDataStream &operator>>(QDataStream &, Log &);

private:
    TStageScene* _plotSectionScene;
};

QDataStream &operator<<(QDataStream &, const Log &);
QDataStream &operator>>(QDataStream &, Log &);

#endif  //_LOG_H
