#include "t_timeline_data.h"
#include <QDebug>
TTimelineData::TTimelineData()
{

}

TTimelineData::TTimelineData(QGraphicsItem *shapeItem, QPointF posf)
{
    Q_UNUSED(posf);
    _behavior = new TTimelineBehaviour();
    _shapeItem = shapeItem;
    _timelineRectItem = new TTimeLineRectItem(this);
    _locked = false;
}

TTimelineData::~TTimelineData()
{
    delete _behavior;
}

TTimeLineRectItem *TTimelineData::timelineRectItem() const
{
    return _timelineRectItem;
}

QGraphicsItem *TTimelineData::shapeItem() const
{
    return _shapeItem;
}

void TTimelineData::updateTimeLineRectItem(TTimeLineRectItem *item)
{
    _timelineRectItem->setRow(item->row());
    _timelineRectItem->setColumn(item->column());
    _timelineRectItem->setBrush(item->brush());
    _timelineRectItem->setPos(item->pos());
    _timelineRectItem->setRect(item->rect());
    _timelineRectItem->setPen(item->pen());
    _timelineRectItem->setSettings(&(*item->getSettings()));
    _timelineRectItem->setKeyFrames(item->keyFrames());
}

TTimelineBehaviour *TTimelineData::behaviour() const
{
    return _behavior;
}

void TTimelineData::setBehaviour(TTimelineBehaviour *behaviour)
{
    delete _behavior;
    _behavior = behaviour;
}

void TTimelineData::setTimelineRectItem(TTimeLineRectItem *timelineRectItem)
{
    _timelineRectItem = timelineRectItem;
}

bool TTimelineData::locked() const
{
    return _locked;
}

void TTimelineData::setLocked(bool locked)
{
    _locked = locked;
}

QDataStream &operator<<(QDataStream &out, const STimelineState &timelineSate)
{
    out << timelineSate.Pos;
    return out;
}

QDataStream &operator>>(QDataStream &in, STimelineState &timelineSate)
{
    QPointF pos;
    in >> pos;
    timelineSate.Pos = pos;
    return in;
}
