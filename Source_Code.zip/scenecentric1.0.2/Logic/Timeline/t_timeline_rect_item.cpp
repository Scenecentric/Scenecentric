#include <QApplication>
#include <QDebug>
#include <QPainter>
#include <qgraphicssceneevent.h>
#include "t_timeline_rect_item.h"
#include "t_grid_scene.h"
#include "t_resizable_rect_item_settings.h"
#include "t_timeline_data.h"
#include "Logic/t_item.h"
#include "Logic/t_ellipse_item.h"
#include "Logic/t_text_item.h"
#include "Logic/t_image_item.h"
#include "Logic/t_rect_item.h"
#include "Logic/t_line_item.h"

TTimeLineRectItem::TTimeLineRectItem()
{
    // just for not getting error in streaming.
}

TTimeLineRectItem::~TTimeLineRectItem()
{
    qDeleteAll(_keyFrames);
    _keyFrames.clear();
}

TTimeLineRectItem::TTimeLineRectItem(TTimelineData *timelineData, QGraphicsItem *parent):
    ResizableRectItem(parent)
{
    setFlags(QGraphicsItem::ItemIsSelectable |
             QGraphicsItem::ItemIsMovable |
             QGraphicsItem::ItemSendsGeometryChanges);
    _timelineData = timelineData;
    _row = 1;
    _column = 1;
}

void TTimeLineRectItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    ResizableRectItem::paint(painter, option, widget);

    QPen p = painter->pen();
    p.setColor(Qt::black);
    p.setWidth(1);
    p.setStyle(Qt::SolidLine);
    painter->setPen(p);

    painter->setRenderHint(QPainter::Antialiasing, true);
    const quint8 &xGridSize = gridScene()->xGridSize();
    const quint8 &yGridSize = gridScene()->yGridSize();
    const qreal &r = xGridSize * 0.80 / 2.0;

    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    quint16 previousX = 1 * xGridSize;
    const quint16 &y = gridScene()->yGridSize() / 2;
    while (i.hasNext()) {
        i.next();

        const quint16 &currKey = (quint16)qRound(i.key());
        const QPointF &center = QPointF(currKey * xGridSize - xGridSize / 2, y);
        if (i.value()->isActive()) {
            painter->setBrush(Qt::red);
        } else {
            painter->setBrush(Qt::white);
        }

        if (qRound(i.key()) == timelineLength()) {
            painter->drawRect((currKey - 0.85) * xGridSize, yGridSize * 0.2,
                              xGridSize * 0.7, yGridSize * 0.65);
        } else {
            painter->drawEllipse(center, r, r);
        }

        if (currKey > 1.0) {
            painter->drawLine(previousX + 0.35 * xGridSize, y, currKey * xGridSize - xGridSize, y);
        }

        previousX = currKey * xGridSize;
    }

}

QVariant TTimeLineRectItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant &value)
{
    emit itemChanged();
    if (change == ItemPositionChange && scene()) {
        QPointF newPos = value.toPointF();
        if(QApplication::mouseButtons() == Qt::LeftButton &&
                qobject_cast<TGridScene*> (scene())) {
            int xGridSize = gridScene()->xGridSize();
            int yGridSize = gridScene()->yGridSize();
            qreal xV = qRound((double)newPos.x() / (double)xGridSize) * (double)xGridSize;
            qreal yV = qRound((double)newPos.y() / (double)yGridSize) * (double)yGridSize;
            if (xV < gridScene()->startColumnPixel())
                xV = gridScene()->startColumnPixel();
            if (yV < gridScene()->startRowPixel())
                yV = gridScene()->startRowPixel();
            newPos = QPointF(xV, yV);
            _column = (quint16)((xV - gridScene()->startColumnPixel()) / xGridSize + 1);
            setRow((yV - gridScene()->startRowPixel()) / yGridSize + 1);
        }

        // deltas to store amount of change
        qreal delX = newPos.x() - pos().x();
        qreal delY = newPos.y() - pos().y();

        // No changes
        if ( delX == 0 && delY == 0 ) {
            return newPos;
        }

        // Check against all the other items for collision
        QRectF translateX = shapeRect();
        QRectF translateY = shapeRect();
        translateX.translate(delX, 0);
        translateY.translate(0, delY);

        bool xOkay = true;
        bool yOkay = true;
        for ( QGraphicsItem* other : scene()->items()) {
            if (other == this)
                continue;
            if ( rectsCollide(translateX, ((TTimeLineRectItem*)other)->shapeRect()) )
                xOkay = false;
            if ( rectsCollide(translateY, ((TTimeLineRectItem*)other)->shapeRect()) )
                yOkay = false;
        }

        if ( xOkay && yOkay ) { // Both valid, so move to the snapped location
            return newPos;
        } else if (xOkay) { // Move only in the X direction
            QPointF r = pos();
            r.setX(newPos.x());
            return r;
        } else if (yOkay) { // Move only in the Y direction
            QPointF r = pos();
            r.setY(newPos.y());
            return r;
        } else { // Don't move at all
            return pos();
        }
    } else if (change == ItemSelectedHasChanged) {
        if (isSelected() == false) {
            frameClicked(-1);
        }
    }

    return ResizableRectItem::itemChange(change, value);
}

void TTimeLineRectItem::setColumn(const quint16 &column)
{
    _column = column;
}

void TTimeLineRectItem::setRow(const quint16 &row)
{
    _row = row;
}

TTimelineData *TTimeLineRectItem::timelineData() const
{
    return _timelineData;
}

void TTimeLineRectItem::frameClicked(int frame) const
{
    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    while (i.hasNext()) {
        i.next();

        if (qRound(i.key()) == frame) {
            i.value()->setIsActive(true);
        } else {
            i.value()->setIsActive(false);
        }

    }
}

void TTimeLineRectItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    ResizableRectItem::mousePressEvent(event);
    const qreal &xPos = event->pos().x();
    quint8 fClicked = xPos / gridScene()->xGridSize() + 1;
    frameClicked(fClicked);

    if ( event->pos().x() > rect().width() - _settings->resizableBorderSize ||
            xPos < _settings->resizableBorderSize ) {
        foreach (QGraphicsItem *item, scene()->items()) {
            if (item != this)
                item->setSelected(false);
        }
        setSelected(true);
    } else {
    }
    update();
}

quint16 TTimeLineRectItem::column() const
{
    return _column;
}

quint16 TTimeLineRectItem::row() const
{
    return _row;
}


bool TTimeLineRectItem::rectsCollide(const QRectF &a, const QRectF &b)
{
    qreal ax1, ax2, ay1, ay2;
    a.getCoords(&ax1, &ay1, &ax2, &ay2);

    qreal bx1, bx2, by1, by2;
    b.getCoords(&bx1, &by1, &bx2, &by2);

    return (ax1 < bx2 &&
            ax2 > bx1 &&
            ay1 < by2 &&
            ay2 > by1);
}

QRectF TTimeLineRectItem::shapeRect() const
{
    QRectF shapeR = rect();
    //    QPointF pMapped = mapToScene(pos().x(), rect().y);
    shapeR.setRect(pos().x(), pos().y(), rect().width(), rect().height());
    return shapeR;
}

void TTimeLineRectItem::setContextMenu(QMenu *contextMenu)
{
    _contextMenu = contextMenu;
}

TKeyFrame *TTimeLineRectItem::insertKeyFrame(quint16 frame)
{
    if (_keyFrames.keys().contains(frame)) {    // check if exists already
        return nullptr;
    }

    TKeyFrame* newKeyFrame = new TKeyFrame();

    _keyFrames.insert(frame, newKeyFrame);
    return newKeyFrame;
}

TKeyFrame *TTimeLineRectItem::keyFrame(quint16 frame)
{
    if (!_keyFrames.keys().contains(frame)) {
        return nullptr;
    }

    return _keyFrames.value(frame);
}

quint16 TTimeLineRectItem::timelineLength() const
{
    return (static_cast<quint16>(rect().width())
            / gridScene()->xGridSize());
}

void TTimeLineRectItem::contextMenuEvent(QGraphicsSceneContextMenuEvent *event)
{
    scene()->clearSelection();
    setSelected(true);
    _contextMenu->exec(event->screenPos());
}

TGridScene *TTimeLineRectItem::gridScene() const
{
    return dynamic_cast<TGridScene*>(this->scene());
}

bool TTimeLineRectItem::activatedKeyFrameExists() const
{
    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    while (i.hasNext()) {
        i.next();
        if (i.value()->isActive()) {
            return true;
        }
    }
    return false;
}

TKeyFrame *TTimeLineRectItem::activatedKeyFrame() const
{
    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    while (i.hasNext()) {
        i.next();
        if (i.value()->isActive()) {
            return i.value();
        }
    }
    return nullptr;
}

TKeyFrame *TTimeLineRectItem::prevActivatedKeyFrame() const
{
    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    i.toBack();
    while (i.hasPrevious()) {
        i.previous();
        if (i.value()->isActive()) {
            return i.value();
        }
    }
    return nullptr;
}

void TTimeLineRectItem::updateState(quint16 localFrame)
{
    TKeyFrame *localKeyFrame = keyFrame(localFrame);

    static quint16 RelFrame = 1;
    static quint16 RelFrameRect = 0;
    if (localKeyFrame != nullptr) {
        RelFrame = 1;
    }

    if (localKeyFrame != nullptr) { // just over a keyFrame
        bool isSelected = _timelineData->shapeItem()->isSelected();
        _timelineData->shapeItem()->setFlag(QGraphicsItem::ItemIsSelectable, false);
        _timelineData->shapeItem()->setPos(localKeyFrame->pos());
        _timelineData->shapeItem()->setFlag(QGraphicsItem::ItemIsSelectable, true);
        _timelineData->shapeItem()->setSelected(isSelected);
        return;
    }

    const TKeyFrame* lKFrame = nullptr;
    const TKeyFrame* rKFrame = nullptr;
    quint16 lKFrameNumber = 1;
    quint16 rKFrameNumber = 1;
    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    float prevKey = 9999.0;
    while (i.hasNext()) {
        i.next();

        if (qRound(i.key()) <= localFrame && qRound(i.peekNext().key()) >= localFrame) {
            lKFrame = i.value();
            lKFrameNumber = static_cast<quint16>(qRound(i.key()));
        }

        if (qRound(i.key()) >= localFrame && prevKey <= localFrame) {
            rKFrame = i.value();
            rKFrameNumber = static_cast<quint16>(qRound(i.key()));
        }
        prevKey = qRound(i.key());
    }

    int xc;
    int yc;

    if ( rKFrame == nullptr || lKFrame == nullptr ) {
        return;

    } else if ( lKFrame->pos() != rKFrame->pos() ) {
        RelFrame = localFrame - lKFrameNumber + 1;
        RelFrameRect = rKFrameNumber - lKFrameNumber + 1;
        int x1 = static_cast<int>(lKFrame->pos().x());
        int y1 = static_cast<int>(lKFrame->pos().y());
        int x2 = static_cast<int>(rKFrame->pos().x());
        int y2 = static_cast<int>(rKFrame->pos().y());
        xc =  static_cast<int>(static_cast<double>(x2 - x1)  * static_cast<double>(RelFrame) / static_cast<double>(RelFrameRect) + x1);
        yc =  static_cast<int>(static_cast<double>(y2 - y1)  * static_cast<double>(RelFrame) / static_cast<double>(RelFrameRect) + y1);

    } else {
        xc = lKFrame->pos().x();
        yc = lKFrame->pos().y();
    }

    bool isSelected = _timelineData->shapeItem()->isSelected();
    _timelineData->shapeItem()->setFlag(QGraphicsItem::ItemIsSelectable, false);
    _timelineData->shapeItem()->setPos(xc, yc);
    _timelineData->shapeItem()->setFlag(QGraphicsItem::ItemIsSelectable, true);
    _timelineData->shapeItem()->setSelected(isSelected);
}

quint16 TTimeLineRectItem::nextKey(quint16 key) const
{
    QMapIterator<float, TKeyFrame*> i(_keyFrames);
    while (i.hasNext()) {
        i.next();

        if (key < qRound(i.key())) {
            return static_cast<quint16>(qRound(i.key()));
        }
    }
    return 0U;
}

void TTimeLineRectItem::deactivateAll()
{
    foreach (TKeyFrame *kframe, _keyFrames.values()) {
        kframe->setIsActive(false);
    }
}

bool TTimeLineRectItem::isMovable()
{
    bool movable;

    QGraphicsItem *item = _timelineData->shapeItem();
    switch (item->type()) {
    case (int)Item::Ellipse:
    {
        EllipseItem *eItem = dynamic_cast<EllipseItem *>(item);
        movable = eItem->isMovable();
    }
        break;
    case (int)Item::Text:
    {
        TextItem *tItem = dynamic_cast<TextItem *>(item);
        movable = tItem->isMovable();
    }
        break;
    case (int)Item::Image:
    {
        ImageItem *iItem = dynamic_cast<ImageItem *>(item);
        movable = iItem->isMovable();
    }
        break;
    case (int)Item::Rect:
    {
        RectItem *rItem = dynamic_cast<RectItem *>(item);
        movable = rItem->isMovable();
    }
        break;
    case (int)Item::Line:
    {
        LineItem *lItem = dynamic_cast<LineItem *>(item);
        movable = lItem->isMovable();
    }
        break;
    default:
        movable = false;
        break;
    }

    return movable;
}

QDataStream &operator<<(QDataStream &out, const TTimeLineRectItem *item)
{
    out << *item->getSettings()
        << item->row()
        << item->column()
        << item->brush()
        << item->pos()
        << item->rect()
        << item->pen()
        << static_cast<quint16>(item->keyFrames().count());

    QMapIterator<float, TKeyFrame*> i(item->keyFrames());
    while (i.hasNext()) {
        i.next();

        out << i.key();
        out << i.value();
    }

    return out;
}

QDataStream &operator>>(QDataStream &in, TTimeLineRectItem *item)
{
    quint16 row;
    quint16 col;
    ResizableRectItemSettings *settings = new ResizableRectItemSettings();
    QBrush brush;
    QPen pen;
    QRectF rect;
    QPointF pos;

    QMap<float, TKeyFrame*> keyFrames;
    quint16 mapCount = 0;


    in >> settings
            >> row
            >> col
            >> brush
            >> pos
            >> rect
            >> pen
            >> mapCount;

    for (int i = 0; i < mapCount; ++i) {
        float key;
        TKeyFrame *keyFrame = new TKeyFrame();
        in >> key;
        in >> keyFrame;

        keyFrames.insert(key, keyFrame);
        keyFrames.insert(key, keyFrame);
    }

    item->setRow(row);
    item->setColumn(col);
    item->setSettings(settings);
    item->setBrush(brush);
    item->setPos(pos);
    item->setRect(rect);
    item->setPen(pen);
    item->setKeyFrames(keyFrames);
    return in;
}
