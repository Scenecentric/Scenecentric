#include <QRegularExpressionMatchIterator>
#include <QDesktopServices>
#include <QUrl>
#include <QDebug>

#include "t_timeline_behaviour.h"


TTimelineBehaviour::TTimelineBehaviour()
{
    _name = QString();
    _script = QString();
}

QString TTimelineBehaviour::script() const
{
    return _script;
}

void TTimelineBehaviour::setScript(const QString &script)
{
    _script = script;
    updateBehaviours();
}

QString TTimelineBehaviour::name() const
{
    return _name;
}

void TTimelineBehaviour::setName(const QString &name)
{
    _name = name;
}

void TTimelineBehaviour::processCommands(const SBehaviour &behaviour, quint16 &frame, TGridScene *gridScene)
{
    QMapIterator<SCondition, QMap<ECommands, QVariant>> j(behaviour.conditions);

    while (j.hasNext()) {
        j.next();

        SCondition cond = j.key();
        if (cond.result(frame, gridScene)) {
            QMap<ECommands, QVariant> commands = j.value();
            QMapIterator<ECommands, QVariant> i(commands);
            while (i.hasNext()) {
                i.next();
                switch (i.key()) {
                case cGoToFrame:
                    frame = i.value().toInt();
                    break;
                case cgoToNetPage:
                    QDesktopServices::openUrl(QUrl(i.value().toString()));
                    break;
                case cGoToTheFrame:
                    break;
                default:
                    break;
                }
            }

        }
    }
}

void TTimelineBehaviour::onPrepareFrame(quint16 &frame, TGridScene *gridScene)
{
    foreach (const SBehaviour &bhv, _behaviours) {
        if (bhv.eventType == etPrepareFrame) {
            processCommands(bhv, frame, gridScene);
        }
    }
}

void TTimelineBehaviour::onExitFrame(quint16 &frame, TGridScene *gridScene)
{
    foreach (const SBehaviour &bhv, _behaviours) {
        if (bhv.eventType == etExitFrame) {
            processCommands(bhv, frame, gridScene);
        }
    }
}

void TTimelineBehaviour::onMouseUp(quint16 &frame, TGridScene *gridScene)
{
    foreach (const SBehaviour &bhv, _behaviours) {
        if (bhv.eventType == etMouseUp) {
            processCommands(bhv, frame, gridScene);
        }
    }
}

void TTimelineBehaviour::onMouseDown(quint16 &frame, TGridScene *gridScene)
{
    foreach (const SBehaviour &bhv, _behaviours) {
        if (bhv.eventType == etMouseDown) {
            processCommands(bhv, frame, gridScene);
        }
    }
}

void TTimelineBehaviour::onMouseEnter(quint16 &frame, TGridScene *gridScene)
{
    foreach (const SBehaviour &bhv, _behaviours) {
        if (bhv.eventType == etMouseEnter) {
            processCommands(bhv, frame, gridScene);
        }
    }
}

void TTimelineBehaviour::extractGoToFrameCmd(SCondition cond, SBehaviour *bhv, QString handler)
{
    QRegularExpression regExp("go to frame \\d+", QRegularExpression::CaseInsensitiveOption);
    QRegularExpressionMatchIterator i = regExp.globalMatch(handler);
    if (i.hasNext()){
        while (i.hasNext()) {
            QRegularExpressionMatch match = i.next();
            QString handler = match.captured(0); // CHECK handler again?
            bhv->add(cond, cGoToFrame, handler.remove("go to frame ").toInt());
        }
    } else {
        QRegularExpression regExp("go to \\d+", QRegularExpression::CaseInsensitiveOption);
        QRegularExpressionMatchIterator i = regExp.globalMatch(handler);
        while (i.hasNext()) {
            QRegularExpressionMatch match = i.next();
            QString handler = match.captured(0); // CHECK handler again?
            bhv->add(cond, cGoToFrame, handler.remove("go to ").toInt());
        }
    }
}

void TTimelineBehaviour::extractGoToNetPageCmd(SCondition cond, SBehaviour *bhv, QString handler)
{
    QRegularExpression regExp("goToNetPage\\s*\"[^\"]+\"", QRegularExpression::CaseInsensitiveOption |
                              QRegularExpression::ExtendedPatternSyntaxOption);
    QRegularExpressionMatchIterator i = regExp.globalMatch(handler);
    while (i.hasNext()) {
        QRegularExpressionMatch match = i.next();
        QString handler = match.captured(0);
        bhv->add(cond, cgoToNetPage, handler.remove("goToNetPage ").remove("\""));
    }
}

void TTimelineBehaviour::extractGoToTheFrame(SCondition cond, SBehaviour *bhv, QString handler)
{
    if (handler.contains("go to the frame", Qt::CaseInsensitive)) {
        bhv->add(cond, cGoToTheFrame, QVariant());
    }
}

void TTimelineBehaviour::updateBehaviours()
{
    _behaviours.clear();
    SBehaviour prepareFrameBhv = SBehaviour(etPrepareFrame);
    SBehaviour exitFrameBhv = SBehaviour(etExitFrame);
    SBehaviour mouseDownBhv = SBehaviour(etMouseDown);
    SBehaviour mouseUpBhv = SBehaviour(etMouseUp);
    SBehaviour mouseEnterBhv = SBehaviour(etMouseEnter);

    const QStringList &handlers = _script.split("on ");
    foreach (QString handler, handlers) {
        handler.replace('\n',' ');

        QString condition = extractIfCondition(handler);
        SCondition cond = extractConditionStruct(condition);
//        QString str2 = extractIfThen(handler);

        if (handler.contains("prepareFrame", Qt::CaseInsensitive)) {
            extractGoToFrameCmd(cond, &prepareFrameBhv, handler);
            extractGoToNetPageCmd(cond, &prepareFrameBhv, handler);
            extractGoToTheFrame(cond, &prepareFrameBhv, handler);

        } else if (handler.contains("exitFrame", Qt::CaseInsensitive)) {
            extractGoToFrameCmd(cond, &exitFrameBhv, handler);
            extractGoToNetPageCmd(cond, &exitFrameBhv, handler);
            extractGoToTheFrame(cond, &exitFrameBhv, handler);

        } else if (handler.contains("mouseDown", Qt::CaseInsensitive)) {
            extractGoToFrameCmd(cond, &mouseDownBhv, handler);
            extractGoToNetPageCmd(cond, &mouseDownBhv, handler);
            extractGoToTheFrame(cond, &mouseDownBhv, handler);

        } else if (handler.contains("mouseUp", Qt::CaseInsensitive)) {
            extractGoToFrameCmd(cond, &mouseUpBhv, handler);
            extractGoToNetPageCmd(cond, &mouseUpBhv, handler);
            extractGoToTheFrame(cond, &mouseUpBhv, handler);

        } else if (handler.contains("mouseEnter", Qt::CaseInsensitive)) {
            extractGoToFrameCmd(cond, &mouseEnterBhv, handler);
            extractGoToNetPageCmd(cond, &mouseEnterBhv, handler);
            extractGoToTheFrame(cond, &mouseEnterBhv, handler);
        }
    }

    if (prepareFrameBhv.conditions.count()) {
        _behaviours << prepareFrameBhv;
    }
    if (exitFrameBhv.conditions.count()) {
        _behaviours << exitFrameBhv;
    }
    if (mouseDownBhv.conditions.count()) {
        _behaviours << mouseDownBhv;
    }
    if (mouseUpBhv.conditions.count()) {
        _behaviours << mouseUpBhv;
    }
    if (mouseEnterBhv.conditions.count()) {
        _behaviours << mouseEnterBhv;
    }
}

QString TTimelineBehaviour::extractIfCondition(QString handler)
{
    QStringList strs;
    QString str;
    QRegularExpression regExp("(?<=If)(.*?)(?=Then)", QRegularExpression::CaseInsensitiveOption |
                              QRegularExpression::ExtendedPatternSyntaxOption);
//    QRegularExpression regExp(".*if(.*)then.*end[ ]if.*", QRegularExpression::CaseInsensitiveOption |
//                              QRegularExpression::ExtendedPatternSyntaxOption);
    QRegularExpressionMatchIterator i = regExp.globalMatch(handler);
    while (i.hasNext()) {
        QRegularExpressionMatch match = i.next();
        str = match.captured(0);
        strs.append(match.capturedTexts());
    }
    return str;
}

QString TTimelineBehaviour::extractIfThen(QString handler)
{
    QStringList strs;
    QString str;
    QRegularExpression regExp(".*then(.*)end[ ]if.*", QRegularExpression::CaseInsensitiveOption |
                              QRegularExpression::ExtendedPatternSyntaxOption);
    QRegularExpressionMatchIterator i = regExp.globalMatch(handler);
    while (i.hasNext()) {
        QRegularExpressionMatch match = i.next();
        str = match.captured(1);
        strs.append(match.capturedTexts());
    }
    return str;
}

SCondition TTimelineBehaviour::extractConditionStruct(QString condition)
{
    SCondition cond;

//    QRegularExpression regExp("(?<=sprite)(.*?)(?=intersects)", QRegularExpression::CaseInsensitiveOption |
//                              QRegularExpression::ExtendedPatternSyntaxOption);

    QStringList strs;
    QRegularExpression regExp("sprite(.*)intersects(.*)", QRegularExpression::CaseInsensitiveOption |
                              QRegularExpression::ExtendedPatternSyntaxOption);

    QRegularExpressionMatchIterator i = regExp.globalMatch(condition);
    while (i.hasNext()) {
        QRegularExpressionMatch match = i.next();
        strs.append(match.captured(1));
        strs.append(match.captured(2));
    }

    if (strs.size() == 2){

        bool ok;
        int from = strs.at(0).toInt(&ok);
        bool ok2;
        int to = strs.at(1).toInt(&ok2);

        if (ok && ok2){
            cond.conditionType = ctIntersect;
            QPair<int, int> pair(from, to);
            cond.conditionParams = QVariant::fromValue(pair);
        }
    }

    return cond;
}

const QList<SBehaviour> &TTimelineBehaviour::behaviours() const
{
    return _behaviours;
}

QDataStream &operator<<(QDataStream &out, const TTimelineBehaviour *tbhv)
{
    out << tbhv->script();
    return out;
}

QDataStream &operator>>(QDataStream &in, TTimelineBehaviour *tbhv)
{
    QString script;
    in >> script;
    tbhv->setScript(script);
    return in;
}

QDataStream &operator<<(QDataStream &out, const TTimelineBehaviour &tbhv)
{
    out << tbhv.script();
    return out;
}

QDataStream &operator>>(QDataStream &in, TTimelineBehaviour &tbhv)
{
    QString script;
    in >> script;
    tbhv.setScript(script);
    return in;
}

bool SCondition::result(const quint16 &frame, TGridScene *gridScene)
{

    bool res = true;

    if (conditionType == ctIntersect) {

        res = false;

        if (gridScene != nullptr) {
            QPair<int, int> itemRows = conditionParams.value<QPair<int, int>>();
            QPair<QGraphicsItem *,QGraphicsItem *> items;
            items.first = nullptr;
            items.second = nullptr;

            QList<QGraphicsItem *> timeLines = gridScene->extTimelines(frame);
            foreach (QGraphicsItem *item, timeLines) {
                TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
                if (timeLineRect->row() == itemRows.first) {
                    items.first = timeLineRect->timelineData()->shapeItem();
                } else if (timeLineRect->row() == itemRows.second) {
                    items.second = timeLineRect->timelineData()->shapeItem();
                }
            }

            if ( items.first != nullptr && items.second != nullptr &&
                 items.first->scene() == items.second->scene() ) {
                res = items.first->collidesWithItem(items.second);
            }
        }
    }

    return res;
}
