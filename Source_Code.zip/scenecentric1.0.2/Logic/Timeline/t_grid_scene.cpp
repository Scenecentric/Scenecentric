#include "t_grid_scene.h"
#include <QPainter>
#include <QDebug>
#include <QGraphicsSceneMouseEvent>
#include <QMessageBox>

#include "Logic/t_ellipse_item.h"
#include "Logic/t_text_item.h"
#include "Logic/t_line_item.h"
#include "Logic/t_image_item.h"
#include "Logic/t_rect_item.h"
#include "Logic/Timeline/t_timeline_rect_item.h"
#include "t_resizable_rect_item_settings.h"

TGridScene::TGridScene(QMenu *itemMenu, QObject *parent) : QGraphicsScene(parent),
    _itemMenu(itemMenu), _isPlaying(false), _beforeSetFrame(false)
{
    _xGridSize = 8;
    _yGridSize = 16;
    _mousePos = QPoint(7 * _xGridSize, 0);
    _currFrame = 1;//QPoint(7 * _xGridSize, 0);
    connect(this, SIGNAL(selectionChanged()), this, SLOT(updateShapeSelections()));

    connect(this, &TGridScene::prepareFrame, this, [=]() {
        QList<QGraphicsItem *> timeLines = extTimelines(_currFrame + 1);
        foreach (QGraphicsItem *item, timeLines) {
            TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
            timeLineRect->timelineData()->behaviour()->onPrepareFrame(_currFrame, this);
        }
    });
    connect(this, &TGridScene::exitFrame, this, [=]() {
        QList<QGraphicsItem *> timeLines = extTimelines(_currFrame);
        foreach (QGraphicsItem *item, timeLines) {
            TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
            timeLineRect->timelineData()->behaviour()->onExitFrame(_currFrame, this);
        }
    });
    connect(this, &TGridScene::mouseUp, this, [=]() {
        QList<QGraphicsItem *> timeLines = extTimelines(_currFrame);
        foreach (QGraphicsItem *item, timeLines) {
            TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
            timeLineRect->timelineData()->behaviour()->onMouseUp(_currFrame, this);
        }
    });
    connect(this, &TGridScene::mouseDown, this, [=]() {
        QList<QGraphicsItem *> timeLines = extTimelines(_currFrame);
        foreach (QGraphicsItem *item, timeLines) {
            TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
            timeLineRect->timelineData()->behaviour()->onMouseDown(_currFrame, this);
        }
    });
    connect(this, &TGridScene::mouseEnter, this, [=]() {
        QList<QGraphicsItem *> timeLines = extTimelines(_currFrame);
        foreach (QGraphicsItem *item, timeLines) {
            TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
            timeLineRect->timelineData()->behaviour()->onMouseEnter(_currFrame, this);
        }
    });
}

void TGridScene::drawBackground(QPainter *painter, const QRectF &rect)
{
    qreal left = int(rect.left()) - (int(rect.left()) % _xGridSize);
    qreal top = int(rect.top()) - (int(rect.top()) % _yGridSize);
    QVarLengthArray<QLineF, 100> lines;
    QPen pen = painter->pen();
    pen.setColor(QColor(240,240,240));
    pen.setWidth(1);
    QRect fillRect;
    QFont font = painter->font();
    font.setPixelSize(10);
    painter->setFont(font);

    for (qreal y = top; y < rect.bottom(); y += _yGridSize) {
        lines.append(QLineF(rect.left(), y, rect.right(), y));
    }

    for (qreal x = left; x < rect.right(); x += _xGridSize) {
        lines.append(QLineF(x, rect.top(), x, rect.bottom()));
        if ((int)x % 5 == 0 || x == 6 * _xGridSize) {
            fillRect.setRect(x, rect.top(), _xGridSize, rect.height());
            painter->fillRect(fillRect, QColor(240,240,240));
        }
    }
    painter->setPen(pen);
    painter->drawLines(lines.data(), lines.size());
}

void TGridScene::drawForeground(QPainter *painter, const QRectF &rect)
{
    qreal left = int(rect.left()) - (int(rect.left()) % _xGridSize);
    qreal top = int(rect.top()) - (int(rect.top()) % _yGridSize);
    QRect fillRect;

    QPen pen = painter->pen();
    pen.setColor(QColor(120,120,120));
    painter->setPen(pen);

    quint8 counter = 0;
    for (qreal y = top; y < rect.bottom(); y += _yGridSize) {
        if (counter <= 2) {
            if (y / _yGridSize == 1) {
                fillRect.setRect(rect.left(), y, rect.right(), _yGridSize);
            } else if (y / _yGridSize == 2) {
                fillRect.setRect(rect.left(), y - _yGridSize, rect.right(), _yGridSize);
            }
            painter->fillRect(fillRect, QColor(180,180,180));
        }
        counter++;
    }

    painter->drawText(QRect(5 * _xGridSize, _yGridSize, 3 * _xGridSize, _yGridSize),
                      Qt::AlignCenter, "1");
    for (qreal x = left; x < rect.right(); x += _xGridSize) {
        if ((int)(x) % 5 == 0 && x != left && x/_xGridSize - 5 != 0) {
            painter->drawText(QRect(x - _xGridSize, _yGridSize, 3 * _xGridSize, _yGridSize),
                              Qt::AlignCenter, QString::number(x/_xGridSize - 5, 'f', 0));
        }
    }


    for (qreal x = left; x <= 5.0 * _xGridSize;  x += _xGridSize) {
        fillRect.setRect(x, rect.top(), _xGridSize, rect.height());
        painter->fillRect(fillRect, QColor(200,200,200));
    }



    counter = 0;
    for (qreal y = top + 2 * _yGridSize; y < rect.bottom(); y += _yGridSize) {
        painter->drawText(3 * _xGridSize, y, 2 * _xGridSize, _yGridSize,
                          Qt::AlignCenter, QString::number(y / _yGridSize - 1));
        counter++;
    }

    if (_mousePos.x() >= 6 * _xGridSize) {
        int xMoved = qRound(_mousePos.x() / (double)_xGridSize) * _xGridSize - _xGridSize / 2.0;
        painter->setPen(QColor(255,0,0, 50));
        painter->drawLine(xMoved, top, xMoved, rect.bottom());
    }

    // fill selected rect
    if ((_pressedPos.x() >= 6 * _xGridSize) && ((_pressedPos.y() < _yGridSize)
            || (_pressedPos.y() > 2.0 * _yGridSize))) {
        painter->fillRect(_pressedPos.x() - ((int)_pressedPos.x() % _xGridSize),
                          _pressedPos.y() - ((int)_pressedPos.y() % _yGridSize),
                          _xGridSize, _yGridSize, QColor(60,60,60, 60));
    }

    // fill behaviors rects
    QMapIterator<quint16, TTimelineBehaviour*> i(_behaviors);
    while (i.hasNext()) {
        i.next();
        const quint16 &frame = i.key();
        const QRectF &rect = QRectF((frame-1) * _xGridSize + startColumnPixel(), 0,
                                    _xGridSize, _yGridSize);
        painter->fillRect(rect, QColor("#b8b8f9"));
        painter->setPen(Qt::black);
        painter->drawText(rect, Qt::AlignCenter, "s");
    }

    pen.setColor(QColor(255,0,0));
    pen.setWidth(1);
    painter->setPen(pen);
    int xPressed = (_currFrame - 1) * _xGridSize + startColumnPixel() + _xGridSize / 2.0;
    _currFrameRect = QRect(xPressed - _xGridSize/3.0, top, 2.0 * _xGridSize / 3.0, rect.bottom()-top);
    painter->drawLine(xPressed, top, xPressed, rect.bottom());

}

quint8 TGridScene::xGridSize() const
{
    return _xGridSize;
}

quint8 TGridScene::yGridSize() const
{
    return _yGridSize;
}

quint8 TGridScene::startColumnPixel() const
{
    return (6 * _xGridSize);
}

quint8 TGridScene::startRowPixel() const
{
    return (2 * _yGridSize);
}

void TGridScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    if (selectedItems().count() != 0) {
        TTimeLineRectItem *selectedItem = dynamic_cast<TTimeLineRectItem*>(selectedItems().first());
        if (selectedItem != nullptr) {
            _timelineItemsByRow.remove(_timelineItemsByRow.key(selectedItem), selectedItem);
            _timelineItemsByCol.remove(_timelineItemsByCol.key(selectedItem), selectedItem);
            _timelineItemsByRow.insert(selectedItem->row(), selectedItem);
            _timelineItemsByCol.insert(selectedItem->column(), selectedItem);
        }
    }
    QGraphicsScene::mouseReleaseEvent(event);
}

// this item is not rectItem. It's stage items
TTimeLineRectItem *TGridScene::castToRectItem(QGraphicsItem *item)
{
    TTimeLineRectItem *timeLineRectItem = nullptr;
    switch (item->type()) {
    case Item::Ellipse:
    {
        EllipseItem *ellipseItem = dynamic_cast<EllipseItem*>(item);
        timeLineRectItem = ellipseItem->timelineRectItem();
    } break;
    case Item::Text:
    {
        TextItem *textItem = dynamic_cast<TextItem*>(item);
        timeLineRectItem = textItem->timelineRectItem();
    } break;
    case Item::Line:
    {
        LineItem *lineItem = dynamic_cast<LineItem*>(item);
        timeLineRectItem = lineItem->timelineRectItem();
    } break;
    case Item::Rect:
    {
        RectItem *rectItem = dynamic_cast<RectItem*>(item);
        timeLineRectItem = rectItem->timelineRectItem();
    } break;
    case Item::Image:
    {
        ImageItem *imageItem = dynamic_cast<ImageItem*>(item);
        timeLineRectItem = imageItem->timelineRectItem();
    } break;
    default:
        timeLineRectItem = nullptr;
        break;
    }
    return timeLineRectItem;
}

QPair<quint16, quint16> TGridScene::frameBounds() const
{
    if (_timelineItemsByCol.count() == 0) {
        return qMakePair(1,2);
    }

    quint16 mostRight = 0;
    quint16 mostLeft = 1000;
    foreach (QGraphicsItem *item, items()) {
        TTimeLineRectItem *rectItem = dynamic_cast<TTimeLineRectItem*>(item);
        quint16 topRight = rectItem->mapToScene(rectItem->rect().topRight()).x();
        quint16 topLeft = rectItem->mapToScene(rectItem->rect().topLeft()).x();
        if (topRight > mostRight) {
            mostRight = topRight;
        }
        if  (topLeft < mostLeft) {
            mostLeft = topLeft;
        }
    }

    quint16 startFrame = (mostLeft - startColumnPixel()) / _xGridSize + 1;
    quint16 endFrame = (mostRight - startColumnPixel()) / _xGridSize;

    return qMakePair(startFrame, endFrame);
}

void TGridScene::deselectAll() const
{
    foreach (QGraphicsItem *item, items()) {
        item->setSelected(false);
    }
}

void TGridScene::mousePosChanged(const QPoint &pos)
{
    _mousePos = pos;
    invalidate();
}

QList<QGraphicsItem *> TGridScene::extTimelines(const quint16 &frame)
{
    const int &xPos = (frame - 1) * _xGridSize + startColumnPixel() + _xGridSize / 2.0;
    QRect rect = QRect(xPos - _xGridSize/3.0, sceneRect().top(),
                       2.0 * _xGridSize / 3.0, sceneRect().bottom()-sceneRect().top());
    return items(rect);
}

void TGridScene::setFrame(const quint16 &frame)
{
    _beforeSetFrame = true;

    _currFrame = frame;

    const int &xPressed = (_currFrame - 1) * _xGridSize + startColumnPixel() + _xGridSize / 2.0;
    _currFrameRect = QRect(xPressed - _xGridSize/3.0, sceneRect().top(),
                           2.0 * _xGridSize / 3.0, sceneRect().bottom()-sceneRect().top());

    const QList<QGraphicsItem*> &timeLines = items(_currFrameRect);
    QList<QGraphicsItem*> shapeItems;
    foreach (QGraphicsItem *item, timeLines) {
        TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
        timeLineRect->timelineData()->setLocked(true);
        QGraphicsItem *shapeItem = timeLineRect->timelineData()->shapeItem();
        shapeItem->setSelected(item->isSelected());

        const quint16 &localFrame = frame - (timeLineRect->scenePos().x() - startColumnPixel()) / _xGridSize;
        timeLineRect->updateState(localFrame);
        shapeItem->setFlag(QGraphicsItem::ItemIsMovable, !_isPlaying || timeLineRect->isMovable());
        timeLineRect->timelineData()->setLocked(false);
        shapeItems << shapeItem;
    }
    emit frameItems(shapeItems);
    invalidate();
    _beforeSetFrame = false;
    if  (shapeItems.size() > 0)
        emit shapeItems.first()->scene()->selectionChanged();

}

void TGridScene::itemAdded(QGraphicsItem *item, bool addedByUser)   // item is shapeItem e.g. ellipse item.
{
    if (item == nullptr)
        return;

    TTimeLineRectItem *timeLineRectItem = castToRectItem(item);
    timeLineRectItem->setContextMenu(_itemMenu);
    connect(timeLineRectItem, SIGNAL(itemChanged()), this, SIGNAL(itemsChanged()));
    if (timeLineRectItem == nullptr)
        return;

    quint16 rowTobeInserted = 0;
    if (_timelineItemsByRow.count()) {
        rowTobeInserted = _timelineItemsByRow.lastKey();
    }

    if (addedByUser == true) {
        const quint8 timelineLength = 30;
        QPen pen = timeLineRectItem->pen();

        int r = qrand() * 255.0 / (double)RAND_MAX;
        int g = qrand() * 255.0 / (double)RAND_MAX;
        int b = qrand() * 255.0 / (double)RAND_MAX;
        QColor bColor = QColor(r, g, b, 70);
        QColor pColor = QColor(bColor.red(), bColor.green(), bColor.blue(), 230);
        timeLineRectItem->setRect(0, 0, _xGridSize * timelineLength, _yGridSize);
        timeLineRectItem->setPos(startColumnPixel(), startRowPixel() + rowTobeInserted * _yGridSize);
        ResizableRectItemSettings *settings = new ResizableRectItemSettings(
                    _xGridSize, QSizeF(_xGridSize, _yGridSize), QSizeF(120 * _xGridSize, _yGridSize),
                    Qt::NoPen, bColor);
        timeLineRectItem->setSettings(settings);
        pen.setColor(pColor);
        timeLineRectItem->setBrush(QBrush(bColor));
        timeLineRectItem->setPen(pen);

        TKeyFrame *firstKF = timeLineRectItem->insertKeyFrame(1);
        TKeyFrame *lastKF =  timeLineRectItem->insertKeyFrame(timelineLength);
        firstKF->setPos(item->pos());
        lastKF->setPos(item->pos());
    }

    this->addItem(timeLineRectItem);
    timeLineRectItem->setRow(rowTobeInserted + 1); // CHECK
    _timelineItemsByRow.insert(rowTobeInserted + 1, timeLineRectItem);// storing rows from 1 not 0 (so added one more)
    _timelineItemsByCol.insert(timeLineRectItem->column(), timeLineRectItem);
}

void TGridScene::onItemsSelectionChanged(QGraphicsItem *selectedItem)
{
    if (selectedItem == nullptr) {
        return;
    }
    TTimeLineRectItem *timeLineRectItem = castToRectItem(selectedItem);
    if (timeLineRectItem == nullptr) {
        return;
    }

    foreach (QGraphicsItem *item, items()) {
        if (item != timeLineRectItem)
            item->setSelected(false);
    }

    timeLineRectItem->setSelected(true);
}

void TGridScene::updateShapeSelections()
{return;
    foreach (QGraphicsItem *item, selectedItems()) {
        QGraphicsItem *shapeItem = dynamic_cast<TTimeLineRectItem*>(item)->timelineData()->shapeItem();
        shapeItem->setSelected(true);
    }
}

bool TGridScene::beforeSetFrame() const
{
    return _beforeSetFrame;
}

bool TGridScene::isPlaying() const
{
    return _isPlaying;
}

void TGridScene::setIsPlaying(bool isPlaying)
{
    _isPlaying = isPlaying;
}

void TGridScene::clearGrid()
{
    QList<QGraphicsItem*> gridItems = items();
    qDeleteAll(gridItems.begin(), gridItems.end());
    gridItems.clear();
    _timelineItemsByRow.clear();
    _timelineItemsByCol.clear();
//    _behaviors.clear();?
    clear();
}

void TGridScene::deleteFromGrid()
{
    foreach (QGraphicsItem *item, selectedItems()) {
        TTimeLineRectItem *rectItem = qgraphicsitem_cast<TTimeLineRectItem*>(item);
        _timelineItemsByRow.remove(rectItem->row(), rectItem);
        _timelineItemsByCol.remove(rectItem->column(), rectItem);
        QGraphicsItem *shapeItem = rectItem->timelineData()->shapeItem();
        removeItem(item);
        delete shapeItem;
     }
}

quint16 TGridScene::currFrame() const
{
    return _currFrame;
}

quint16 TGridScene::endFrame() const
{
    return frameBounds().second;
}

quint16 TGridScene::startFrame() const
{
    return frameBounds().first;
}

void TGridScene::rewind()
{
    _currFrame = startFrame();
    setFrame(_currFrame);
}

void TGridScene::forwardFrame()
{
    TTimelineBehaviour *bhv = _behaviors.value(_currFrame, nullptr);
    bool isLoopingFrame = false;
    if (bhv != nullptr) {
        const QList<SBehaviour> &bhvs = bhv->behaviours();
        foreach (const SBehaviour &sBhv, bhvs) {
            if (sBhv.eventType == etExitFrame) {
                SCondition trueCond;
                QMap<ECommands, QVariant> commands = sBhv.conditions.value(trueCond);
                if (commands.contains(cGoToTheFrame)) {
                    isLoopingFrame = true;
                }
            }
        }
    }

    if (isLoopingFrame == false)
        ++_currFrame;

    emit prepareFrame();

    if (_currFrame >= endFrame() + 1)
        _currFrame = startFrame();
    setFrame(_currFrame);

    emit exitFrame();
}

void TGridScene::backwardFrame()
{
    --_currFrame;
    if (_currFrame <= startFrame() - 1)
        _currFrame = endFrame();
    setFrame(_currFrame);
}

bool TGridScene::isLastFrame()
{
    return (_currFrame == endFrame());
}

bool TGridScene::isFirstFrame()
{
    return (_currFrame == startFrame());
}

QMap<quint16, TTimeLineRectItem *> TGridScene::timelineItemsByCol() const
{
    return _timelineItemsByCol;
}

void TGridScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsScene::mousePressEvent(event);
    if (event->scenePos().x() < startColumnPixel()) {
        return;
    }

    _currFrame = static_cast<quint16>((event->scenePos().x() - startColumnPixel()) / _xGridSize) + 1;
    setFrame(_currFrame);

    _pressedPos.setX(event->scenePos().x());
    _pressedPos.setY(event->scenePos().y());

    const QList<QGraphicsItem*> &timeLines = this->items();
    bool activeFrameExists = false;
    foreach (QGraphicsItem *item, timeLines) {
        TTimeLineRectItem *timeLineRect = dynamic_cast<TTimeLineRectItem*>(item);
        if (timeLineRect->activatedKeyFrameExists() ==  true)
            activeFrameExists = true;
    }
    if (activeFrameExists == false)
        emit allFramesAreDeactivated();
}

void TGridScene::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    _mousePos = event->scenePos();
    invalidate();
    QGraphicsScene::mouseMoveEvent(event);
}

void TGridScene::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->scenePos().x() > startColumnPixel() &&
            event->scenePos().y() < _yGridSize) {
        TTimelineBehaviour *timelineBehavior;
        timelineBehavior = _behaviors.value(_currFrame, new TTimelineBehaviour());
        _behaviors.insert(_currFrame, timelineBehavior);
        emit behaviorWidgetReq(timelineBehavior);
    }
}

void TGridScene::updateBehavior(TTimelineBehaviour *behavior, const QString &script)
{
    if (_behaviors.values().contains(behavior) == false) {
        return;
    }

    if (script.isEmpty()) {
        quint16 frame = _behaviors.key(behavior);
        _behaviors.remove(frame);
        delete behavior;
    } else {
        behavior->setScript(script);
    }
}

QDataStream &operator<<(QDataStream &out, const TGridScene &scene)
{
    QList<QGraphicsItem*> items = scene.items();
    out << (uint16_t)items.count();
    foreach (QGraphicsItem *item, items) {
        QGraphicsItem *shapeItem = dynamic_cast<TTimeLineRectItem*>(item)->
                timelineData()->shapeItem();
        switch (shapeItem->type()) {
        case Item::Ellipse:
        {
            EllipseItem *ellipseItem = dynamic_cast<EllipseItem*>(shapeItem);
            out << ellipseItem->type();
            out << *ellipseItem;
        } break;
        case Item::Text:
        {
            TextItem *textItem = dynamic_cast<TextItem*>(shapeItem);
            out << textItem->type();
            out << *textItem;
        } break;
        case Item::Line:
        {
            LineItem *lineItem = dynamic_cast<LineItem*>(shapeItem);
            out << lineItem->type();
            out << *lineItem;
        } break;
        case Item::Rect:
        {
            RectItem *rectItem = dynamic_cast<RectItem*>(shapeItem);
            out << rectItem->type();
            out << *rectItem;
        } break;
        case Item::Image:
        {
            ImageItem *imageItem = dynamic_cast<ImageItem*>(shapeItem);
            out << imageItem->type();
            out << *imageItem;
        } break;
        default:
            break;
        }
    }
    out << scene._behaviors.count();
    QMapIterator<quint16, TTimelineBehaviour*> i(scene._behaviors);
    while (i.hasNext()) {
        i.next();
        out << (quint16)i.key();
        out << (TTimelineBehaviour*)i.value();
    }

    return out;
}

QDataStream &operator>>(QDataStream &in, TGridScene &scene)
{
    uint16_t itemsCount;
    in >> itemsCount;
    int type;
    for (int i = 0; i < itemsCount; ++i) {
        in >> type;
        switch (type) {
        case Item::Ellipse:
        {
            EllipseItem *ellipseItem = new EllipseItem();
            in >> *ellipseItem;
            scene.itemAdded(ellipseItem, false);
        } break;
        case Item::Text:
        {
            TextItem *textItem = new TextItem();
            in >> *textItem;
            scene.itemAdded(textItem, false);
        } break;
        case Item::Line:
        {
            LineItem *lineItem = new LineItem();
            in >> *lineItem;
            scene.itemAdded(lineItem, false);
        } break;
        case Item::Rect:
        {
            RectItem *rectItem = new RectItem();
            in >> *rectItem;
            scene.itemAdded(rectItem, false);
        } break;
        case Item::Image:
        {
            ImageItem *imageItem = new ImageItem();
            in >> *imageItem;
            scene.itemAdded(imageItem, false);
        } break;
        default:
            break;
        }
    }

    QList<TTimelineBehaviour*> bhvs = scene._behaviors.values();
    scene._behaviors.clear();
    qDeleteAll(bhvs);
    int bhvCount;
    in >> bhvCount;
    for (int i = 0; i < bhvCount; ++i) {
        quint16 key;
        TTimelineBehaviour *value = new TTimelineBehaviour();
        in >> key;
        in >> value;
        scene._behaviors.insert(key, value);
    }
    return in;
}
