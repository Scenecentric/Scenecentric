#include "t_key_frame.h"

#include <QDataStream>

TKeyFrame::TKeyFrame()
{
    _isActive = false;
}

TKeyFrame::TKeyFrame(const TKeyFrame &other)
{
    _isActive = other.isActive();
    _pos = other.pos();
}

QPointF TKeyFrame::pos() const
{
    return _pos;
}

void TKeyFrame::setPos(const QPointF &pos)
{
    _pos = pos;
}

bool TKeyFrame::isActive() const
{
    return _isActive;
}

void TKeyFrame::setIsActive(bool isActive)
{
    _isActive = isActive;
}

//QDataStream &operator<<(QDataStream &out, const TKeyFrame &kf)
//{
//    out << kf.pos()
//        << static_cast<quint8>(kf.isActive() ? 1 : 0);

//    return out;
//}

//QDataStream &operator>>(QDataStream &in, TKeyFrame &kf)
//{
//    QPointF pos;
//    quint8 isActive;
//    in >> pos >> isActive;
//    kf.setPos(pos);
//    kf.setIsActive(isActive);

//    return in;
//}

QDataStream &operator<<(QDataStream &out, const TKeyFrame *kf)
{
    out << kf->pos()
        << static_cast<quint8>(kf->isActive() ? 1 : 0);

    return out;
}

QDataStream &operator>>(QDataStream &in, TKeyFrame *kf)
{
    QPointF pos;
    quint8 isActive;
    in >> pos >> isActive;
    kf->setPos(pos);
    kf->setIsActive(isActive);

    return in;
}
