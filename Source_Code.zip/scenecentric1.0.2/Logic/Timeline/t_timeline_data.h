/****************************************************************************
**
** This is class is another parent for stage shape items and is designed
**  to hold state data. For animating objects we need to hold first and final
**  state of each object. So, here is where we store those data.
** There is a function (updateState) in this class which update objects
**  state in each frame and used in playAnimation algorithm to make objects
**  animating.
**
****************************************************************************/
#ifndef T_TIMELINE_ITEM_H
#define T_TIMELINE_ITEM_H

#include "t_timeline_rect_item.h"
#include "t_timeline_behaviour.h"

class TTimelineBehaviour;

struct STimelineState
{
    STimelineState() {
        Pos = QPointF(0,0);
    }

    QPointF Pos;

    friend QDataStream &operator<<(QDataStream &out, const STimelineState &);
    friend QDataStream &operator>>(QDataStream &in, STimelineState &);
};
QDataStream &operator<<(QDataStream &out, const STimelineState &);
QDataStream &operator>>(QDataStream &in, STimelineState &);

class TTimelineData
{
public:
    explicit TTimelineData();
    explicit TTimelineData(QGraphicsItem *shapeItem, QPointF posf);
    virtual ~TTimelineData();

    virtual TTimeLineRectItem *timelineRectItem() const;
    QGraphicsItem *shapeItem() const;
    virtual void updateTimeLineRectItem(TTimeLineRectItem *item);

    TTimelineBehaviour *behaviour() const;
    void setBehaviour(TTimelineBehaviour *behaviour);

    void setTimelineRectItem(TTimeLineRectItem *timelineRectItem);

    bool locked() const;
    void setLocked(bool locked);

protected:
    TTimeLineRectItem *_timelineRectItem;
    QGraphicsItem *_shapeItem;
    TTimelineBehaviour *_behavior;
    bool _locked;
};

#endif // T_TIMELINE_ITEM_H
