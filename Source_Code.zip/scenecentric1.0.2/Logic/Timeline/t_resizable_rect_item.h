/****************************************************************************
**
** This is the base class for timeline objects and is designed for adding
**  capability for resizing timelines.
**
****************************************************************************/

#ifndef RESIZABLERECTITEM_H
#define RESIZABLERECTITEM_H

#include <QGraphicsRectItem>
#include <QPen>
#include <QBrush>
#include "t_key_frame.h"

class ResizableRectItemSettings;

class ResizableRectItem : public QGraphicsRectItem
{
public:
    ResizableRectItem(QGraphicsItem *parent = nullptr);
    void setSettings(ResizableRectItemSettings *settings);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    ResizableRectItemSettings *getSettings() const;

    QMap<float, TKeyFrame *> keyFrames() const;

    void setKeyFrames(const QMap<float, TKeyFrame *> &keyFrames);

protected:
    virtual QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    ResizableRectItemSettings *_settings;
    QMap<float, TKeyFrame*> _keyFrames;

private:
    QRectF getInnerRect() const;
    void resizeRect(QGraphicsSceneMouseEvent *event);
};

#endif // RESIZABLERECTITEM_H
