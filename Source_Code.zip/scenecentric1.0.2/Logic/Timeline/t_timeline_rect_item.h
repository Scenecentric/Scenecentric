/****************************************************************************
**
** This is the timeline class and is used as items of gridScene. All stuff
**  about collide prevention, painting timelines, snapping items to the grid
**  and etc are handled in this class.
**
****************************************************************************/

#ifndef CUSTOMRECTITEM_H
#define CUSTOMRECTITEM_H

#include <QFocusEvent>
#include <QGraphicsItem>
#include <QMenu>
#include <QObject>

#include "t_resizable_rect_item.h"
#include "t_key_frame.h"

class TGridScene;
class ResizableRectItemSettings;
class TTimelineData;
class TTimeLineRectItem : public QObject, public ResizableRectItem
{
    Q_OBJECT
public:
    TTimeLineRectItem();
    ~TTimeLineRectItem() override;
    TTimeLineRectItem(TTimelineData *timelineData, QGraphicsItem *parent = nullptr);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    quint16 row() const;
    quint16 column() const;
    TTimelineData *timelineData() const;
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    TGridScene *gridScene() const;

    friend QDataStream &operator<<(QDataStream &out, const TTimeLineRectItem *);
    friend QDataStream &operator>>(QDataStream &in, TTimeLineRectItem *);

    void setRow(const quint16 &row);
    void setColumn(const quint16 &column);
    void setContextMenu(QMenu *contextMenu);
    TKeyFrame* insertKeyFrame(quint16 frame);
    TKeyFrame* keyFrame(quint16 frame);

    quint16 timelineLength() const;

    bool activatedKeyFrameExists() const;
    TKeyFrame* activatedKeyFrame() const;
    TKeyFrame* prevActivatedKeyFrame() const;

    void updateState(quint16 localFrame);
    quint16 nextKey(quint16 key) const;

    void deactivateAll();

    bool isMovable();

signals:
    void itemChanged();

protected:
    void contextMenuEvent(QGraphicsSceneContextMenuEvent *event) override;
    QVariant itemChange(GraphicsItemChange change, const QVariant &value) override;
    TTimelineData *_timelineData;
    quint16 _row;
    quint16 _column;

private:
    bool rectsCollide(const QRectF &a, const QRectF &b);
    QRectF shapeRect() const;
//    bool _spriteAnimating;
    QMenu *_contextMenu;
    void frameClicked(int frame) const;
};

QDataStream &operator<<(QDataStream &out, const TTimeLineRectItem *);
QDataStream &operator>>(QDataStream &in, TTimeLineRectItem *);

#endif // CUSTOMRECTITEM_H
