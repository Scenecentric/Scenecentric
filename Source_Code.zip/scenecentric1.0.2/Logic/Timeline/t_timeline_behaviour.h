#ifndef T_TIMELINE_BEHAVIOUR_H
#define T_TIMELINE_BEHAVIOUR_H

#include <QString>
#include <QVariant>

#include "t_grid_scene.h"
#include "t_timeline_rect_item.h"
#include "t_timeline_data.h"

class TGridScene;

enum EEventType {
    etPrepareFrame,
    etExitFrame,
    etMouseDown,
    etMouseUp,
    etMouseEnter
};

enum ECoditionType {
    ctNone = 0,
    ctIntersect
};

enum ECommands {
    cGoToFrame,
    cgoToNetPage,
    cGoToTheFrame
};

struct SCondition
{
    SCondition() {
        conditionType = ctNone;
    }

    bool result(const quint16 &frame, TGridScene *gridScene = nullptr);

    ECoditionType conditionType;
    QVariant conditionParams;

    bool operator==(const SCondition& other) const {return other.conditionType == conditionType;}
    bool operator<(const SCondition& other) const {return other.conditionType > conditionType;}
};

struct SBehaviour {
    SBehaviour(EEventType e) {
        eventType = e;
    }

    void add(SCondition cond, ECommands cmd, QVariant cmdInput) {

        QMap<ECommands, QVariant> condCommands = conditions.value(cond);
        condCommands.insert(cmd, cmdInput);
        conditions.insert(cond, condCommands);
    }

    EEventType eventType;
    QMap<SCondition , QMap<ECommands, QVariant>> conditions;
};

class TTimelineBehaviour
{
public:
    TTimelineBehaviour();

    QString script() const;
    void setScript(const QString &script);

    QString name() const;
    void setName(const QString &name);

    void onPrepareFrame(quint16 &frame, TGridScene *gridScene);
    void onExitFrame(quint16 &frame, TGridScene *gridScene);
    void onMouseUp(quint16 &frame, TGridScene *gridScene);
    void onMouseDown(quint16 &frame, TGridScene *gridScene);
    void onMouseEnter(quint16 &frame, TGridScene *gridScene);

    const QList<SBehaviour> &behaviours() const;

    friend QDataStream &operator<<(QDataStream &out, const TTimelineBehaviour *tbhv);
    friend QDataStream &operator>>(QDataStream &in, TTimelineBehaviour *tbhv);
    friend QDataStream &operator<<(QDataStream &out, const TTimelineBehaviour &tbhv);
    friend QDataStream &operator>>(QDataStream &in, TTimelineBehaviour &tbhv);


private:
    void updateBehaviours();
    QString _name;
    QString _script;
    QList<SBehaviour> _behaviours;

private:

    QString extractIfCondition(QString handler);
    QString extractIfThen(QString handler);
    SCondition extractConditionStruct(QString condition);

    void extractGoToFrameCmd(SCondition cond, SBehaviour *bhv, QString handler);
    void extractGoToNetPageCmd(SCondition cond, SBehaviour *bhv, QString handler);
    void extractGoToTheFrame(SCondition cond, SBehaviour *bhv, QString handler);
    void processCommands(const SBehaviour &behaviour, quint16 &frame, TGridScene *gridScene);
};
QDataStream &operator<<(QDataStream &out, const TTimelineBehaviour *tbhv);
QDataStream &operator>>(QDataStream &in, TTimelineBehaviour *tbhv);
QDataStream &operator<<(QDataStream &out, const TTimelineBehaviour &tbhv);
QDataStream &operator>>(QDataStream &in, TTimelineBehaviour &tbhv);

#endif // T_TIMELINE_BEHAVIOUR_H
