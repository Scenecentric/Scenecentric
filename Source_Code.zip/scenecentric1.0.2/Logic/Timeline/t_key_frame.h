#ifndef T_KEY_FRAME_H
#define T_KEY_FRAME_H

#include <QPoint>

class TKeyFrame
{
public:
    TKeyFrame();
    TKeyFrame(const TKeyFrame &other);


    QPointF pos() const;
    void setPos(const QPointF &pos);

    bool isActive() const;
    void setIsActive(bool isActive);

//    friend QDataStream &operator<<(QDataStream &out, const TKeyFrame &);
//    friend QDataStream &operator>>(QDataStream &in, TKeyFrame &);
    friend QDataStream &operator<<(QDataStream &out, const TKeyFrame *);
    friend QDataStream &operator>>(QDataStream &in, TKeyFrame *);

private:
    QPointF _pos;
    bool _isActive;
};

//QDataStream &operator<<(QDataStream &out, const TKeyFrame &);
//QDataStream &operator>>(QDataStream &in, TKeyFrame &);
QDataStream &operator<<(QDataStream &out, const TKeyFrame *);
QDataStream &operator>>(QDataStream &in, TKeyFrame *);


#endif // T_KEY_FRAME_H
