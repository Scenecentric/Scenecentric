/****************************************************************************
**
** This is the scene for score view. In score view user should be able
**  to add timelines/move and resize them. The gridding paintigs,
**  displaying current frame vertical line, finding each frame corrosponding
**  objects and etc are related to this class.
**
****************************************************************************/

#ifndef GRIDSCENE_H
#define GRIDSCENE_H

#include <QObject>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QMouseEvent>
#include "t_timeline_behaviour.h"

class TTimeLineRectItem;
class TTimelineBehaviour;
class TGridScene: public QGraphicsScene
{
    Q_OBJECT
public:
    explicit TGridScene(QMenu *itemMenu, QObject *parent = nullptr);
    void drawBackground(QPainter *painter, const QRectF &rect);
    void drawForeground(QPainter *painter, const QRectF &rect);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);

    quint8 xGridSize() const;
    quint8 yGridSize() const;
    quint8 startColumnPixel() const;
    quint8 startRowPixel() const;
    TTimeLineRectItem* castToRectItem(QGraphicsItem *item);
    QPair<quint16, quint16> frameBounds() const;
    void deselectAll() const;
    QMap<quint16, TTimeLineRectItem *> timelineItemsByCol() const;
    void updateBehavior(TTimelineBehaviour *behavior, const QString &script);

    friend QDataStream &operator<<(QDataStream &, const TGridScene &);
    friend QDataStream &operator>>(QDataStream &, TGridScene &);

    quint16 currFrame() const;
    quint16 endFrame() const;
    quint16 startFrame() const;
    void rewind();
    void forwardFrame();
    void backwardFrame();
    bool isLastFrame();
    bool isFirstFrame();

    QList<QGraphicsItem *> extTimelines(const quint16 &frame);

    bool isPlaying() const;
    void setIsPlaying(bool isPlaying);

    void clearGrid();
    void deleteFromGrid();

    bool beforeSetFrame() const;

signals:
    void frameItems(QList<QGraphicsItem*> items);
    void behaviorWidgetReq(TTimelineBehaviour *behaviour);
    void itemsChanged();
    void prepareFrame();
    void exitFrame();
    void mouseUp();
    void mouseDown();
    void mouseEnter();
    void allFramesAreDeactivated();

public slots:
    void mousePosChanged(const QPoint &pos);
    void setFrame(const quint16 &frame);
    void itemAdded(QGraphicsItem *item, bool addedByUser = true);
    void onItemsSelectionChanged(QGraphicsItem *selectedItem);
    void updateShapeSelections();

private:
    quint8 _xGridSize;
    quint8 _yGridSize;
    QPointF _mousePos;
    QPointF _pressedPos;
    quint16 _currFrame;
    QMultiMap<quint16, TTimeLineRectItem*> _timelineItemsByRow;
    QMultiMap<quint16, TTimeLineRectItem*> _timelineItemsByCol;
    QRect _currFrameRect;
    QMenu *_itemMenu;
    QMap<quint16, TTimelineBehaviour*> _behaviors;
    bool _isPlaying;
    bool _beforeSetFrame;
};


QDataStream &operator<<(QDataStream &, const TGridScene &);
QDataStream &operator>>(QDataStream &, TGridScene &);

#endif // GRIDSCENE_H
