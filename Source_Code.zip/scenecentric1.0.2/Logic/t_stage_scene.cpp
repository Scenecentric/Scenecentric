#include "t_stage_scene.h"
#include <QGraphicsItem>
#include <QPainter>
#include <QDebug>
#include <QGraphicsSceneMouseEvent>
#include "t_text_item.h"
#include "t_image_item.h"
#include "t_ellipse_item.h"
#include "t_rect_item.h"
#include "t_line_item.h"

TStageScene::TStageScene()
{
    _animatingPathEnabled = false;
}

void TStageScene::drawForeground(QPainter *painter, const QRectF &rect)
{
    if (true/*_animatingPathEnabled*/) {

        QList<QLineF> lines;
        QList<QPointF> points;
        bool multiPoint = false;
        if (selectedItems().size() == 1){
            foreach (QGraphicsItem *item, selectedItems()) {
                TTimelineData *data = dynamic_cast<TTimelineData *>(item);
                QList<TKeyFrame *> frames = data->timelineRectItem()->keyFrames().values();

                QPointF centerPadding = data->shapeItem()->boundingRect().bottomRight() / 2;

                if (data->shapeItem()->type() == Item::Line){
                    LineItem *lineI = dynamic_cast<LineItem *>(data->shapeItem());
                    centerPadding = lineI->line().p2() / 2;
                }

                if (frames.size() >= 2){
                    points.append(frames.at(0)->pos() + centerPadding);
                    for (int i = 1; i < frames.size(); ++i) {
                        QLineF line;
                        line.setP1(frames.at(i - 1)->pos() + centerPadding);
                        line.setP2(frames.at(i)->pos() + centerPadding);
                        lines.append(line);
                        points.append(frames.at(i)->pos() + centerPadding);
                        if (frames.at(i)->pos() != frames.at( i - 1)->pos())
                            multiPoint = true;
                    }
                }
            }
        }

        QPen pen = painter->pen();
        pen.setColor(Qt::blue);
        pen.setStyle(Qt::DashLine);
        painter->setPen(pen);

        if (multiPoint) {

            foreach (QLineF line, lines) {
                painter->drawLine(line);
            }

            foreach (QPointF point, points) {
                painter->drawText(point, QString::number(points.indexOf(point) + 1));
            }
        }

//        painter->drawLine(_animatingPath);
    }

    QGraphicsScene::drawForeground(painter, rect);
}

QLineF TStageScene::animatingPath() const
{
    return _animatingPath;
}

void TStageScene::setAnimatingPath(const QLineF &animatingPath)
{
    _animatingPath = animatingPath;
    update();
}

bool TStageScene::animatingPathEnabled() const
{
    return _animatingPathEnabled;
}

void TStageScene::setAnimatingPathEnabled(bool animatingPathEnabled)
{
    _animatingPathEnabled = animatingPathEnabled;
    update();
}

void TStageScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    emit scenePressed();
    QGraphicsScene::mousePressEvent(event);
}

void TStageScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsScene::mouseReleaseEvent(event);
    emit sceneReleased();
}

void TStageScene::deactivateAnimatingPath()
{
    setAnimatingPathEnabled(false);
}

QDataStream &operator <<(QDataStream & out, const TStageScene & psc)
{
    int count = psc.items().count();
    out << static_cast<qint32>(count);
    for (int i = count; i > 0; i--)
    {
        QGraphicsItem* item = psc.items()[i-1];

		qint32 tp = static_cast<qint32>(item->type());
		out << tp;

		switch (tp)
		{
        case Item::Text:
			out << *static_cast<TextItem*>(item);
			break;
        case Item::Image:
			out << *static_cast<ImageItem*>(item);
			break;
        case Item::Ellipse:
            out << *static_cast<EllipseItem*>(item);
            break;
        case Item::Rect:
            out << *static_cast<RectItem*>(item);
            break;
        case Item::Line:
            out << *static_cast<LineItem*>(item);
            break;
		}
	}

	return out;
}

QDataStream &operator >>(QDataStream & in, TStageScene &psc)
{
	qint32 count;
	in >> count;

	for (int i = 0; i < count; i++)
	{
		qint32 tp;
		in >> tp;

		switch (tp)
		{
            case Item::Text:
            {
                 TextItem* ti = new TextItem();
                 in >> *ti;
                 ti->setZValue(psc.items().size()+1);
                 psc.addItem(ti);
                 break;
            }
            case Item::Image:
            {
                  ImageItem* ii = new ImageItem();
                  in >> *ii;
                  ii->setZValue(psc.items().size()+1);
                  psc.addItem(ii);
                  break;
            }
            case Item::Ellipse:
            {
                EllipseItem* ei = new EllipseItem();
                in >> *ei;
                ei->setZValue(psc.items().size()+1);
                psc.addItem(ei);
                break;
            }
            case Item::Rect:
            {
                 RectItem* ri = new RectItem();
                 in >> *ri;
                 ri->setZValue(psc.items().size()+1);
                 psc.addItem(ri);
                 break;
            }
            case Item::Line:
            {
                 LineItem* li = new LineItem();
                 in >> *li;
                 li->setZValue(psc.items().size()+1);
                 psc.addItem(li);
                 break;
            }
		}
	}
	return in;
}

