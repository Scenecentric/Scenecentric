#if !defined(_ITEM_H)
#define _ITEM_H
#include <QPoint>
#include <QPaintDevice>
#include <QGraphicsItem>

class Item
{
public:

    enum ItemType {
        Ellipse     = QGraphicsItem::UserType + 10,
        Text        = QGraphicsItem::UserType + 20,
        Image       = QGraphicsItem::UserType + 30,
        Rect        = QGraphicsItem::UserType + 40,
        Line        = QGraphicsItem::UserType + 50,
        None        = QGraphicsItem::UserType + 60
    };

};

#endif  //_ITEM_H

