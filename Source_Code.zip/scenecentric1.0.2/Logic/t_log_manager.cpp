#include "t_log_manager.h"
#include <QGraphicsObject>
#include <QFile>
#include <QPrinter>
#include <QPrintDialog>
#include <QPainter>
#include "GUI/mainwindow.h"

LogManager::LogManager(QObject *parent)
    : QObject(parent),_currentLog(nullptr)
{

}

Log* LogManager::currentLog() const
{
    return _currentLog;
}

void LogManager::setCurrentLog(Log* currentLog)
{
    if (_currentLog != nullptr)
        delete _currentLog;

    _currentLog = currentLog;

	emit currentLogChanged(_currentLog);
}

void LogManager::load(const QString& path)
{
    QFile file(path);
    file.open(QIODevice::ReadOnly);

    QDataStream in(&file);

    MainWindow* mainW = MainWindow::getInstance();
    qreal tempInt = 0;

    in >> tempInt;
    mainW->plotWidget->setViewWidth(tempInt);
    in >> tempInt;
    mainW->plotWidget->setCenterViewHeight(tempInt);

    Log* lg = new Log();
    in >> *lg;

    setCurrentLog(lg);

    file.close();
}

void LogManager::newLog()
{
    currentLog()->plotSectionScene()->clear();
    emit currentLogChanged(_currentLog);
}

void LogManager::save(const QString &filePath)
{
    QFile file(filePath);
    file.open(QIODevice::WriteOnly);
    QDataStream out(&file);
    out << currentLog()->plotSectionScene()->sceneRect().height();
    out << *currentLog();
    file.close();
}

void LogManager::print()
{
	QPrinter printer;
	if (QPrintDialog(&printer).exec() == QDialog::Accepted) {
		QPainter painter(&printer);
        painter.setRenderHint(QPainter::Antialiasing);
	}
}
