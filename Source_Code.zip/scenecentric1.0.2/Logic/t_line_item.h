#if !defined(_LINEITEM_H)
#define _LINEITEM_H

#include <QGraphicsLineItem>
#include "t_item.h"
#include "GUI/PropertyBrowser/qtvariantproperty.h"
#include <QObject>
#include "Timeline/t_timeline_data.h"

class LineItem : public QObject, public TTimelineData, public QGraphicsLineItem
{
    Q_OBJECT
public:
    LineItem(QGraphicsItem *parent = 0);
    LineItem(const QPointF &posf, const QLineF& line, const QString& object_name = "Line", QGraphicsItem *parent = 0);
    ~LineItem();

    int type() const { return Item::Line; }

    QtProperty *properties() const { return _properties; }
    QtVariantPropertyManager *propertyManager() const { return _variantManager; }

    QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    bool isMovable() const;
    void setItemMovable(bool itemMovable);

    friend QDataStream &operator<<(QDataStream &out, const LineItem &);
    friend QDataStream &operator>>(QDataStream &out, LineItem &);

private slots:
    void updateItemProperties();
    void releaseSpriteAnimating();

private:
    void init();

    bool _itemMovable;

    QtVariantProperty *_itemStartPosition;
    QtVariantProperty *_itemEndPosition;
    QtVariantProperty *_itemName;
    QtVariantProperty *_itemPenColor;
    QtVariantProperty *_itemPenThickness;
    QtVariantProperty *_itemPenStyle;
    QtVariantProperty *_itemOpacity;
    QtVariantProperty *_itemVisiblity;
    QtVariantProperty *_itemIsMovableDuringPlay;

    QtProperty *_properties;
    QtVariantPropertyManager *_variantManager;
};

QDataStream &operator<<(QDataStream &out, const LineItem &);
QDataStream &operator>>(QDataStream &out, LineItem &);

#endif  //_LineITEM_H
