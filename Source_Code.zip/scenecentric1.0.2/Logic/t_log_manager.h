#if !defined(_LOGMANAGER_H)
#define _LOGMANAGER_H
#include "t_log.h"

class LogManager : public QObject
{
	Q_OBJECT
public:
	LogManager(QObject *parent = 0);
    Log *currentLog() const;
    void setCurrentLog(Log *currentLog);

    void load(const QString &filePath);
    void save(const QString &filePath);
	void print();
    void newLog();

signals:
	void currentLogChanged(Log *log);

private:
    Log* _currentLog;

};

#endif  //_LOGMANAGER_H
