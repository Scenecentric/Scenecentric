#include "t_text_item.h"
#include "t_item.h"
#include <QGraphicsScene>
#include <QPainter>
#include <QDebug>
#include <QtMath>
#include <QGraphicsSceneMouseEvent>
#include "GUI/mainwindow.h"

TextItem::TextItem(QGraphicsItem *parent)
    : QGraphicsTextItem(parent), TTimelineData(this, QPointF())
{
    _itemMovable = true;
    setPlainText("Text");
    init();
}

TextItem::TextItem(const QString &text, const QPointF &posf, const QString& object_name, QGraphicsItem *parent)
    : QGraphicsTextItem(parent), TTimelineData(this, posf)
{
    setPlainText(text);
    setPos(posf);
    setObjectName(object_name);
    _itemMovable = true;

    init();

    connect(_timelineRectItem, &TTimeLineRectItem::itemChanged, this, [=](){
        int rowIndex = _timelineRectItem->row();
        setZValue(rowIndex);
    });
}

TextItem::~TextItem()
{
    delete _variantManager;
}

void TextItem::init()
{
    setAcceptHoverEvents(true);
    setFlag(QGraphicsItem::ItemIsMovable);
    setFlag(QGraphicsItem::ItemSendsGeometryChanges);
    setFlag(QGraphicsItem::ItemIsSelectable);

    _variantManager = new QtVariantPropertyManager();
    _properties = _variantManager->addProperty(QtVariantPropertyManager::groupTypeId(),
                                               QLatin1String("Text Item"));

    _itemName = _variantManager->addProperty(QVariant::String, "Name");
    _itemName->setValue(objectName());
    _properties->addSubProperty(_itemName);

    _itemText = _variantManager->addProperty(QVariant::String, "Text");
    _itemText->setValue(toPlainText());
    _properties->addSubProperty(_itemText);

    _itemPosition = _variantManager->addProperty(QVariant::PointF, "Position");
    _itemPosition->setValue(pos());
    _properties->addSubProperty(_itemPosition);

    _itemRotation = _variantManager->addProperty(QVariant::Double, "Rotation");
    _itemRotation->setValue(rotation());
    _itemRotation->setAttribute(QLatin1String("minimum"), -180);
    _itemRotation->setAttribute(QLatin1String("maximum"), 180);
    _itemRotation->setAttribute(QLatin1String("singleStep"), 5);
    _properties->addSubProperty(_itemRotation);

    _itemVisiblity = _variantManager->addProperty(QVariant::Bool, "Visible");
    _itemVisiblity->setValue(isVisible());
    _properties->addSubProperty(_itemVisiblity);

    _itemIsMovableDuringPlay = _variantManager->addProperty(QVariant::Bool, "Movable");
    _itemIsMovableDuringPlay->setValue(_itemMovable);
    _properties->addSubProperty(_itemIsMovableDuringPlay);

    _itemFont = _variantManager->addProperty(QVariant::Font, "Font");
    _itemFont->setValue(font());
    _properties->addSubProperty(_itemFont);

    _itemTextColor = _variantManager->addProperty(QVariant::Color, "Text Color");
    _itemTextColor->setValue(defaultTextColor());
    _properties->addSubProperty(_itemTextColor);

    _itemPenColor = _variantManager->addProperty(QVariant::Color, "Pen Color");
    _itemPenColor->setValue(QColor(Qt::black));
    _properties->addSubProperty(_itemPenColor);

    _itemBorderThickness = _variantManager->addProperty(QVariant::Int, "Border Thickness");
    _itemBorderThickness->setValue(1);
    _itemBorderThickness->setAttribute(QLatin1String("minimum"), 1);
    _itemBorderThickness->setAttribute(QLatin1String("maximum"), 6);
    _properties->addSubProperty(_itemBorderThickness);

    QStringList enumNames;
    enumNames << "NoPen" << "SolidLine" << "DashLine" << "DotLine" << "DashDotLine" << "DashDotDotLine";
    _itemPenStyle = _variantManager->addProperty(QtVariantPropertyManager::enumTypeId(),
                    QLatin1String("Pen Style"));
    _itemPenStyle->setAttribute(QLatin1String("enumNames"), enumNames);
    _itemPenStyle->setValue(0);
    _properties->addSubProperty(_itemPenStyle);

    _itemBrush = _variantManager->addProperty(QVariant::Bool, "Brush");
    _itemBrush->setValue(false);
    _properties->addSubProperty(_itemBrush);

    _itemBrushColor = _variantManager->addProperty(QVariant::Color, "Background Color");
    _itemBrushColor->setValue(QColor(Qt::white));
    _itemBrushColor->setEnabled(_itemBrush->value().toBool());
    _properties->addSubProperty(_itemBrushColor);

    connect(_variantManager, SIGNAL(valueChanged(QtProperty*,QVariant)), this, SLOT(updateItemProperties()));
}

void TextItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option,
                     QWidget *widget)
{
    painter->setRenderHint(QPainter::Antialiasing);
    QBrush brush(_itemBrushColor->value().value<QColor>());
    painter->setBrush(brush);
    if (!_itemBrush->value().toBool())
        painter->setBrush(Qt::NoBrush);

    QPen pen;
    pen.setWidth(_itemBorderThickness->value().toInt());
    pen.setStyle(static_cast<Qt::PenStyle>(_itemPenStyle->value().toInt()));
    pen.setColor(_itemPenColor->value().value<QColor>());
    painter->setPen(pen);

    painter->drawRect(boundingRect());

    QGraphicsTextItem::paint(painter,option,widget);
    painter->setRenderHint(QPainter::Antialiasing,false);
}

QVariant TextItem::itemChange(QGraphicsItem::GraphicsItemChange change,
                              const QVariant &value)
{
    if (change == ItemPositionChange && scene()) {
        // value is the new position.
        QPointF newPos = value.toPointF();
        QRectF rect = scene()->sceneRect();
        QRectF itemRect = this->boundingRect();
        // boundingrect is 1 pixel larger than object
        itemRect.adjust( 0 , 0 , -1 , -1 );

        // rounds position when view in zoom
        newPos.setX( qFloor(newPos.x()));
        newPos.setY( qFloor(newPos.y()));

        rect = rect.adjusted(-qMin(itemRect.width()*qCos(rotation()*M_PI/180),
                                   qMin(itemRect.height()*qSin(-rotation()*M_PI/180),
                                         qMin(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.width(),itemRect.height())-(rotation()*M_PI/180)),
                                              qreal(0)))),
                             -qMin(itemRect.width()*qSin(rotation()*M_PI/180),
                                   qMin(itemRect.height()*qCos(rotation()*M_PI/180),
                                         qMin(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.height(),itemRect.width())+(rotation()*M_PI/180)),
                                              qreal(0)))),
                             -qMax(itemRect.width()*qCos(rotation()*M_PI/180),
                                   qMax(itemRect.height()*qSin(-rotation()*M_PI/180),
                                         qMax(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.width(),itemRect.height())-(rotation()*M_PI/180)),
                                              qreal(0)))),
                             -qMax(itemRect.width()*qSin(rotation()*M_PI/180),
                                   qMax(itemRect.height()*qCos(rotation()*M_PI/180),
                                         qMax(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.height(),itemRect.width())+(rotation()*M_PI/180)),
                                              qreal(0)))));


        if (!rect.contains(newPos)) {
            // Keep the item inside the scene rect.
            newPos.setX(qMin(rect.right(), qMax(newPos.x(), rect.left())));
            newPos.setY(qMin(rect.bottom(), qMax(newPos.y(), rect.top())));
        }

        return newPos;

    } else if (change == ItemPositionHasChanged && scene()) {

        if (_timelineRectItem->activatedKeyFrameExists()) {

            if ( !locked() ){
                QPointF delta = value.toPointF() - _itemPosition->value().toPointF();
                TKeyFrame *frame = _timelineRectItem->activatedKeyFrame();
                frame->setPos(frame->pos() + delta);

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }

        } else {
            if ( !locked() ){

                QPointF delta = value.toPointF() - _itemPosition->value().toPointF();

                foreach (TKeyFrame *frame, _timelineRectItem->keyFrames().values()) {
                    frame->setPos(frame->pos() + delta);
                }

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }
        }

        _itemPosition->setValue(value.toPointF());

    } else if ( change == ItemSelectedHasChanged && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        stageScene->update();

    }/* else if ((change == ItemSceneHasChanged || change == ItemSelectedChange) && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        connect(stageScene, SIGNAL(sceneReleased()), this, SLOT(releaseSpriteAnimating()));
    }*/
    return QGraphicsItem::itemChange(change, value);
}

void TextItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsTextItem::mousePressEvent(event);
    emit _timelineRectItem->gridScene()->mouseDown();
}

void TextItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsTextItem::mouseReleaseEvent(event);
    emit _timelineRectItem->gridScene()->mouseUp();
}

void TextItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QGraphicsTextItem::hoverEnterEvent(event);
    emit _timelineRectItem->gridScene()->mouseEnter();
}

bool TextItem::isMovable() const
{
    QVariant var = _itemIsMovableDuringPlay->value();
    return var.toBool();
}

void TextItem::setItemMovable(bool itemMovable)
{
     _itemMovable = itemMovable;
}

void TextItem::updateItemProperties()
{
    MainWindow* mainWindow = MainWindow::getInstance();

    if (_itemName->value().toString() != objectName())
    {
        setObjectName(_itemName->value().toString());
        emit mainWindow->plotWidget->treeViewItemChanged();
    }

    setPos(_itemPosition->value().toPointF());
    setPlainText(_itemText->value().toString());
    // If inputed size is greater than scenerect , ignores and sets original size to the property
    if (scene()){
        qreal D, height, width, rot, wTeta, hTeta;
        height = boundingRect().height();
        width = boundingRect().width();
        rot = qAbs(_itemRotation->value().toReal() * M_PI / 180);
        if (rot > M_PI/2)
        {
            wTeta = rot - M_PI/2 + qAtan2(height,width);
            hTeta = rot - qAtan2(height,width);
        }
        else
        {
            wTeta = - rot + M_PI/2 + qAtan2(height,width);
            hTeta = rot + qAtan2(height,width);
        }

        D = sqrt(pow(width,2)+pow(height,2));

        if (qAbs(D * qSin(wTeta)) >= scene()->sceneRect().width() ||
                qAbs(D * qSin(hTeta)) >= scene()->sceneRect().height() )
        {
            _itemRotation->setValue(rotation());
        }
    }

    QFont font = _itemFont->value().value<QFont>();

    if (font.pointSize() >= 72)
    {
        font.setPointSize(72);
        _itemFont->setValue(font);
    }
    if (font.pointSize() <= 5)
    {
        font.setPointSize(5);
        _itemFont->setValue(font);
    }

    setFont(font);
    setDefaultTextColor(_itemTextColor->value().value<QColor>());
    setRotation(_itemRotation->value().toDouble());

    itemChange(ItemPositionChange, _itemPosition->value().toPointF()); //  if size makes item go beyound scenerect it fixes poition to avoid it

    _itemBrushColor->setEnabled(_itemBrush->value().toBool());

    if (! _itemVisiblity->value().toBool() && isVisible())
    {
        setVisible(_itemVisiblity->value().toBool());
        mainWindow->scene_selectionChanged(this);
    }
    else if (_itemVisiblity->value().toBool() && !isVisible()) // other items like this
    {
    setVisible(_itemVisiblity->value().toBool());
    setSelected(_itemVisiblity->value().toBool());
    }
}

void TextItem::releaseSpriteAnimating()
{
    if (_timelineRectItem->activatedKeyFrameExists()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        if (stageScene->animatingPathEnabled() == true) {
            if (_timelineRectItem->activatedKeyFrameExists()) {
                _timelineRectItem->activatedKeyFrame()->setPos(scenePos());
            }
            _timelineRectItem->deactivateAll();
            stageScene->setAnimatingPathEnabled(false);
        }
    }
}

QDataStream &operator<<(QDataStream &out, const TextItem & ti)
{
    out << ti.objectName()
        << ti.toPlainText()
        << ti.pos()
        << ti.rotation()
        << ti.isVisible()
        << ti.font()
        << ti.defaultTextColor()
        << ti._itemPenColor->value().value<QColor>()
        << ti._itemBorderThickness->value().toInt()
        << ti._itemPenStyle->value().toInt()
        << ti._itemBrush->value().toBool()
        << ti._itemBrushColor->value().value<QColor>()
        << ti.timelineRectItem()
        << ti.behaviour()
        << ti.isMovable();

	return out;
}

QDataStream &operator>>(QDataStream &in, TextItem & ti)
{
    QString name, text;
    QPointF pos;
    qreal rotation;
    QFont font;
    bool brush, visiblity;
    QColor textColor, borderColor, brushColor;
    int borderThickness, penStyle;
    TTimeLineRectItem rectItem;
    bool movable;
    TTimelineBehaviour *behaviour =  ti.behaviour();
		 
    in >> name
            >> text
            >> pos
            >> rotation
            >> visiblity
            >> font
            >> textColor
            >> borderColor
            >> borderThickness
            >> penStyle
            >> brush
            >> brushColor
            >> &rectItem
            >> behaviour
            >> movable;

    ti.setObjectName(name);
    ti.setPlainText(text);
    ti.setPos(pos);
    ti.setRotation(rotation);
    ti.setVisible(visiblity);
    ti.setFont(font);
    ti.setDefaultTextColor(textColor);
    ti.updateTimeLineRectItem(&rectItem);
    ti.setItemMovable(movable);

    delete ti._variantManager;
    ti.init();

    ti._itemBorderThickness->setValue(borderThickness);
    ti._itemPenColor->setValue(borderColor);
    ti._itemPenStyle->setValue(penStyle);
    ti._itemBrush->setValue(brush);
    ti._itemBrushColor->setValue(brushColor);

	return in;
}

