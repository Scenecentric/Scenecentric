#if !defined(_IMAGEITEM_H)
#define _IMAGEITEM_H

#include <QGraphicsPixmapItem>
#include "t_item.h"
#include "GUI/PropertyBrowser/qtvariantproperty.h"
#include "Timeline/t_timeline_data.h"

class ImageItem : public QObject, public TTimelineData, public QGraphicsPixmapItem/*QGraphicsRectItem*///, Item
{
    Q_OBJECT
public:
    ImageItem();
    ImageItem(const QPointF &posf, const QString& object_name = "Image");
    ~ImageItem();

    int type() const { return Item::Image; }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    QtProperty *properties() const { return _properties; }
    QtVariantPropertyManager *propertyManager() const { return _variantManager; }

    void contextMenuEvent(QGraphicsSceneContextMenuEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

    QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    bool isMovable() const;
    void setItemMovable(bool itemMovable);

    friend QDataStream &operator<<(QDataStream &out, const ImageItem &);
    friend QDataStream &operator>>(QDataStream &out, ImageItem &);


private slots:
    void updateItemProperties();
    void releaseSpriteAnimating();

private:
    void init();

    bool _itemMovable;


    QtVariantProperty *_itemName;
    QtVariantProperty *_itemURL;
    QtVariantProperty *_itemScale;
    QtVariantProperty *_itemPosition;
    QtVariantProperty *_itemRotation;
    QtVariantProperty *_itemOpacity;
    QtVariantProperty *_itemVisiblity;
    QtVariantProperty *_itemIsMovableDuringPlay;
    QtVariantProperty *_itemFile;
    QtVariantProperty *_itemBorderThickness;
    QtVariantProperty *_itemPenStyle;
    QtVariantProperty *_itemPenColor;

    QtProperty *_properties;
    QtVariantPropertyManager *_variantManager;
};

QDataStream &operator<<(QDataStream &out, const ImageItem &);
QDataStream &operator>>(QDataStream &out, ImageItem &);

#endif  //_IMAGEITEM_H
