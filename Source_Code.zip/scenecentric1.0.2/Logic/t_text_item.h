#if !defined(_TEXTITEM_H)
#define _TEXTITEM_H

#include <QGraphicsTextItem>
#include "t_item.h"
#include <QObject>
#include "GUI/PropertyBrowser/qtvariantproperty.h"
#include "Timeline/t_timeline_data.h"

class TextItem : public QGraphicsTextItem, public TTimelineData
{
    Q_OBJECT
public:
    TextItem(QGraphicsItem *parent = 0);
    TextItem(const QString& text, const QPointF& posf, const QString& object_name = "Text", QGraphicsItem *parent = 0);
    ~TextItem();

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    int type() const { return Item::Text; }

    QtProperty *properties() const { return _properties; }
    QtVariantPropertyManager *propertyManager() const { return _variantManager; }

    QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    bool isMovable() const;
    void setItemMovable(bool itemMovable);

    friend QDataStream &operator<<(QDataStream &out, const TextItem &);
    friend QDataStream &operator>>(QDataStream &out, TextItem &);

private slots:
    void updateItemProperties();
    void releaseSpriteAnimating();

/*public:*/private:
    void init();

    bool _itemMovable;

    QtVariantProperty *_itemText;
    QtVariantProperty *_itemPosition;
    QtVariantProperty *_itemName;
    QtVariantProperty *_itemVisiblity;
    QtVariantProperty *_itemIsMovableDuringPlay;
    QtVariantProperty *_itemPenColor;
    QtVariantProperty *_itemBrushColor;
    QtVariantProperty *_itemFont;
    QtVariantProperty *_itemBorderThickness;
    QtVariantProperty *_itemPenStyle;
    QtVariantProperty *_itemTextColor;
    QtVariantProperty *_itemRotation;
    QtVariantProperty *_itemBrush;

    QtProperty *_properties;
    QtVariantPropertyManager *_variantManager;
};

QDataStream &operator<<(QDataStream &out, const TextItem &);
QDataStream &operator>>(QDataStream &out, TextItem &);


#endif  //_TEXTITEM_H
