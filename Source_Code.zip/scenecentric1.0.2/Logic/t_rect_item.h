#if !defined(_RECTITEM_H)
#define _RECTITEM_H

#include <QGraphicsRectItem>
#include "t_item.h"
#include "GUI/PropertyBrowser/qtvariantproperty.h"
#include <QObject>
#include "Timeline/t_timeline_data.h"

class RectItem : public QObject, public TTimelineData, public QGraphicsRectItem //, Item
{
    Q_OBJECT
public:
    RectItem();
    RectItem(const QPointF &posf, const QRectF &rectf,  const QString& object_name = "Rectangle");
    ~RectItem();

    int type() const { return Item::Rect; }

    QtProperty *properties() const { return _properties; }
    QtVariantPropertyManager *propertyManager() const { return _variantManager; }

    QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    bool isMovable() const;
    void setItemMovable(bool itemMovable);

    friend QDataStream &operator<<(QDataStream &out, const RectItem &);
    friend QDataStream &operator>>(QDataStream &out, RectItem &);
//    virtual void updateState(quint16 localFrame, quint16 rectFrame);

private slots:
    void updateItemProperties();
    void releaseSpriteAnimating();

private:
    void init();

    bool _itemMovable;

    QtVariantProperty *_itemName;
    QtVariantProperty *_itemPenColor;
    QtVariantProperty *_itemBrushColor;
    QtVariantProperty *_itemBrush;
    QtVariantProperty *_itemBorderThickness;
    QtVariantProperty *_itemPenStyle;
    QtVariantProperty *_itemPosition;
    QtVariantProperty *_itemRotation;
    QtVariantProperty *_itemOpacity;
    QtVariantProperty *_itemVisiblity;
    QtVariantProperty *_itemIsMovableDuringPlay;
    QtVariantProperty *_itemSize;

    QtProperty *_properties;
    QtVariantPropertyManager *_variantManager;
};

QDataStream &operator<<(QDataStream &out, const RectItem &);
QDataStream &operator>>(QDataStream &out, RectItem &);

#endif  //_RECTITEM_H
