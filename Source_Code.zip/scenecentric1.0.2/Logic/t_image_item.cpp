#include "t_image_item.h"
#include <QGraphicsScene>
#include <QPainter>
#include <QFileDialog>
#include "GUI/mainwindow.h"
#include <QGraphicsSceneMouseEvent>
#include <QtMath>
#include <qdebug.h>

#define imageTypes "Jpeg (*.jpg);;PNG (*.png);;BitMap (*.bmp);;gif (*.gif);;All Image types (*.jpg *.png *.bmp *.gif)"
#define allImageTypes "All Image types (*.jpg *.png *.bmp *.gif)"

ImageItem::ImageItem():
    TTimelineData(this, QPointF())
{
    _itemMovable = true;

    init();
}

ImageItem::ImageItem(const QPointF &posf, const QString& object_name):
    TTimelineData(this, posf)
{
    QPixmap pic(":/Res/sample1.jpg");
    setPos(posf);
    setPixmap(pic);
    setObjectName(object_name);
    _itemMovable = true;

    init();

    connect(_timelineRectItem, &TTimeLineRectItem::itemChanged, this, [=](){
        int rowIndex = _timelineRectItem->row();
        setZValue(rowIndex);
    });
}

ImageItem::~ImageItem()
{
    delete _variantManager;
}

void ImageItem::init()
{
    setAcceptHoverEvents(true);
    setFlags(QGraphicsItem::ItemIsSelectable|
             QGraphicsItem::ItemIsMovable|
             QGraphicsItem::ItemIsFocusable |
             QGraphicsItem::ItemSendsGeometryChanges);

    _variantManager = new QtVariantPropertyManager();
    _properties = _variantManager->addProperty(QtVariantPropertyManager::groupTypeId(),
                                               QLatin1String("Image Item"));

    _itemName = _variantManager->addProperty(QVariant::String, "Name");
    _itemName->setValue(objectName());
    _properties->addSubProperty(_itemName);

    _itemPosition = _variantManager->addProperty(QVariant::PointF, "Position");
    _itemPosition->setValue(pos());
    _properties->addSubProperty(_itemPosition);

    _itemScale = _variantManager->addProperty(QVariant::Double, "Scale");
    _itemScale->setValue(scale());
    _itemScale->setAttribute(QLatin1String("minimum"), 0.01/*.25*/);
    _itemScale->setAttribute(QLatin1String("singleStep"), 0.1);
    _properties->addSubProperty(_itemScale);

    _itemRotation = _variantManager->addProperty(QVariant::Int, "Rotation");
    _itemRotation->setValue(rotation());
    _itemRotation->setAttribute(QLatin1String("minimum"), -180);
    _itemRotation->setAttribute(QLatin1String("maximum"), 180);
    _itemRotation->setAttribute(QLatin1String("singleStep"), 10);
    _properties->addSubProperty(_itemRotation);

    _itemOpacity = _variantManager->addProperty(QVariant::Int, "Opacity");
    _itemOpacity->setValue(100 * opacity());
    _itemOpacity->setAttribute(QLatin1String("minimum"), 20);
    _itemOpacity->setAttribute(QLatin1String("maximum"), 100);
    _itemOpacity->setAttribute(QLatin1String("singleStep"), 10);
    _properties->addSubProperty(_itemOpacity);

    _itemVisiblity = _variantManager->addProperty(QVariant::Bool, "Visible");
    _itemVisiblity->setValue(isVisible());
    _properties->addSubProperty(_itemVisiblity);

    _itemIsMovableDuringPlay = _variantManager->addProperty(QVariant::Bool, "Movable");
    _itemIsMovableDuringPlay->setValue(_itemMovable);
    _properties->addSubProperty(_itemIsMovableDuringPlay);

    _itemPenColor = _variantManager->addProperty(QVariant::Color, "Pen Color");
    _itemPenColor->setValue(QColor(Qt::black));
    _properties->addSubProperty(_itemPenColor);

    _itemBorderThickness = _variantManager->addProperty(QVariant::Int, "Border Thickness");
    _itemBorderThickness->setValue(1);
    _itemBorderThickness->setAttribute(QLatin1String("minimum"), 1);
    _itemBorderThickness->setAttribute(QLatin1String("maximum"), 6);
    _properties->addSubProperty(_itemBorderThickness);

    QStringList enumNames;
    enumNames << "NoPen" << "SolidLine" << "DashLine" << "DotLine" << "DashDotLine" << "DashDotDotLine";
    _itemPenStyle = _variantManager->addProperty(QtVariantPropertyManager::enumTypeId(),
                    QLatin1String("Pen Style"));
    _itemPenStyle->setAttribute(QLatin1String("enumNames"), enumNames);
    _itemPenStyle->setValue(0);
    _properties->addSubProperty(_itemPenStyle);

    connect(_variantManager, SIGNAL(valueChanged(QtProperty*,QVariant)), this, SLOT(updateItemProperties()));
}

void ImageItem::setItemMovable(bool itemMovable)
{
    _itemMovable = itemMovable;
}

void ImageItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option,
                     QWidget *widget)
{
    painter->setRenderHint(QPainter::Antialiasing);

    QPen pen;
    pen.setWidth(_itemBorderThickness->value().toInt());
    pen.setStyle(static_cast<Qt::PenStyle>(_itemPenStyle->value().toInt()));
    pen.setColor(_itemPenColor->value().value<QColor>());
    painter->setPen(pen);

    painter->drawRect(boundingRect());

     QGraphicsPixmapItem::paint(painter,option,widget);
    painter->setRenderHint(QPainter::Antialiasing,false);
}

QVariant ImageItem::itemChange(QGraphicsItem::GraphicsItemChange change,
                              const QVariant &value)
{
    if (change == ItemPositionChange && scene()) {
        // value is the new position.
        QPointF newPos = value.toPointF();
        QRectF rect = scene()->sceneRect();
        QRectF itemRect = this->boundingRect();
        itemRect.setWidth(itemRect.width() * scale() );
        itemRect.setHeight( itemRect.height() * scale() );
//        qDebug() << itemRect << scale();
        // boundingrect is 1 pixel larger than object
        itemRect.adjust(0, 0, -1, -1);

        // rounds position when view in zoom
        newPos.setX( qFloor(newPos.x()));
        newPos.setY( qFloor(newPos.y()));

        rect = rect.adjusted(-qMin(itemRect.width()*qCos(rotation()*M_PI/180),
                                   qMin(itemRect.height()*qSin(-rotation()*M_PI/180),
                                         qMin(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.width(),itemRect.height())-(rotation()*M_PI/180)),
                                              qreal(0)))),
                             -qMin(itemRect.width()*qSin(rotation()*M_PI/180),
                                   qMin(itemRect.height()*qCos(rotation()*M_PI/180),
                                         qMin(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.height(),itemRect.width())+(rotation()*M_PI/180)),
                                              qreal(0)))),
                             -qMax(itemRect.width()*qCos(rotation()*M_PI/180),
                                   qMax(itemRect.height()*qSin(-rotation()*M_PI/180),
                                         qMax(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.width(),itemRect.height())-(rotation()*M_PI/180)),
                                              qreal(0)))),
                             -qMax(itemRect.width()*qSin(rotation()*M_PI/180),
                                   qMax(itemRect.height()*qCos(rotation()*M_PI/180),
                                         qMax(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                              *qSin(qAtan2(itemRect.height(),itemRect.width())+(rotation()*M_PI/180)),
                                              qreal(0)))));

        if (!rect.contains(newPos)) {
            // Keep the item inside the scene rect.
            newPos.setX(qMin(rect.right(), qMax(newPos.x(), rect.left())));
            newPos.setY(qMin(rect.bottom(), qMax(newPos.y(), rect.top())));
        }

        return newPos;

    } else if (change == ItemPositionHasChanged && scene()) {

        if (_timelineRectItem->activatedKeyFrameExists()) {

            if ( !locked() ){
                QPointF delta = value.toPointF() - _itemPosition->value().toPointF();
                TKeyFrame *frame = _timelineRectItem->activatedKeyFrame();
                frame->setPos(frame->pos() + delta);

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }

        } else {
            if ( !locked() ){

                QPointF delta = value.toPointF() - _itemPosition->value().toPointF();

                foreach (TKeyFrame *frame, _timelineRectItem->keyFrames().values()) {
                    frame->setPos(frame->pos() + delta);
                }

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }
        }

        _itemPosition->setValue(value.toPointF());

    } else if ( change == ItemSelectedHasChanged && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        stageScene->update();

    }/* else if ((change == ItemSceneHasChanged || change == ItemSelectedChange) && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        connect(stageScene, SIGNAL(sceneReleased()), this, SLOT(releaseSpriteAnimating()));
    }*/
    return QGraphicsItem::itemChange(change, value);
}

void ImageItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsPixmapItem::mousePressEvent(event);
    emit _timelineRectItem->gridScene()->mouseDown();
}

void ImageItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QGraphicsPixmapItem::hoverEnterEvent(event);
    emit _timelineRectItem->gridScene()->mouseEnter();
}

bool ImageItem::isMovable() const
{
    QVariant var = _itemIsMovableDuringPlay->value();
    return var.toBool();
}

void ImageItem::updateItemProperties()
{
    MainWindow* mainWindow = MainWindow::getInstance();

    if (_itemName->value().toString() != objectName())
    {
        setObjectName(_itemName->value().toString());
        emit mainWindow->plotWidget->treeViewItemChanged();
    }
    if (scene()){
        qreal D, height, width, rot, wTeta, hTeta;
        height = _itemScale->value().toReal() * boundingRect().height();
        width = _itemScale->value().toReal() * boundingRect().width();
        rot = qAbs(_itemRotation->value().toReal() * M_PI / 180.0);
        if (rot > M_PI/2.0)
        {
            wTeta = rot - M_PI/2.0 + qAtan2(height,width);
            hTeta = rot - qAtan2(height,width);
        }
        else
        {
            wTeta = - rot + M_PI/2.0 + qAtan2(height,width);
            hTeta = rot + qAtan2(height,width);
        }

        D = sqrt(pow(width,2)+pow(height,2));
        if (qAbs(D * qSin(wTeta)) >= scene()->sceneRect().width() ||
                qAbs(D * qSin(hTeta)) >= scene()->sceneRect().height() )
        {
            _itemScale->setValue(scale());
            _itemRotation->setValue(rotation());
        }
    }

    setPos(_itemPosition->value().toPointF());
    setRotation(_itemRotation->value().toInt());
    setScale(_itemScale->value().toDouble());

    itemChange(ItemPositionChange, _itemPosition->value().toPointF()); //  if size makes item go beyound scenerect it fixes poition to avoid it

    if (! _itemVisiblity->value().toBool() && isVisible())
    {
        setVisible(_itemVisiblity->value().toBool()); // this must be corrected
        mainWindow->scene_selectionChanged(this);
    }
    else
    {
    setVisible(_itemVisiblity->value().toBool()); // this must be corrected
    setSelected(_itemVisiblity->value().toBool());
    }

    setOpacity(_itemOpacity->value().toReal()/100);
}

void ImageItem::releaseSpriteAnimating()
{
    if (_timelineRectItem->activatedKeyFrameExists()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        if (stageScene->animatingPathEnabled() == true) {
            if (_timelineRectItem->activatedKeyFrameExists()) {
                _timelineRectItem->activatedKeyFrame()->setPos(scenePos());
            }
            _timelineRectItem->deactivateAll();
            stageScene->setAnimatingPathEnabled(false);
        }
    }
}

QDataStream &operator<<(QDataStream &out, const ImageItem &ii)
{
    out << ii.objectName()
        << ii.pos()
        << ii.scale()
        << ii.rotation()
        << ii.opacity()
        << ii.isVisible()
        << ii._itemPenColor->value().value<QColor>()
        << ii._itemBorderThickness->value().toInt()
        << ii._itemPenStyle->value().toInt()
        << ii.pixmap()
        << ii.timelineRectItem()
        << ii.behaviour()
        << ii.isMovable();

    return out;
}

QDataStream &operator>>(QDataStream &in, ImageItem &ii)
{
    QString name;
    QPointF pos;
    qreal scale, rotation, opacity;
    bool Visiblity;
    QColor borderColor;
    int borderThickness, penStyle;
    QPixmap picLoad;
    bool movable;

    TTimeLineRectItem rectItem;
    TTimelineBehaviour *behaviour =  ii.behaviour();

    in >> name
            >> pos
            >> scale
            >> rotation
            >> opacity
            >> Visiblity
            >> borderColor
            >> borderThickness
            >> penStyle
            >> picLoad
            >> &rectItem
            >> behaviour
            >> movable;

    ii.setObjectName(name);
    ii.setPos(pos);
    ii.setScale(scale);
    ii.setRotation(rotation);
    ii.setOpacity(opacity);
    ii.setVisible(Visiblity);
    ii.setPixmap(picLoad);
    ii.updateTimeLineRectItem(&rectItem);
    ii.setItemMovable(movable);

    delete ii._variantManager;
    ii.init();

    ii._itemBorderThickness->setValue(borderThickness);
    ii._itemPenColor->setValue(borderColor);
    ii._itemPenStyle->setValue(penStyle);

    return in;
}

void ImageItem::contextMenuEvent(QGraphicsSceneContextMenuEvent* e)
{
    Q_UNUSED(e);
    QString selectedFilter = tr(allImageTypes);
    QString fileName = QFileDialog::getOpenFileName(0,"Select an Image",".",tr(imageTypes),&selectedFilter);
    if (!fileName.isEmpty())
    {
        QPixmap pic(fileName);
        _itemScale->setValue(qMin(qMax(boundingRect().height()
                                       ,boundingRect().width())*scale(),
                                  double(qMax(pic.size().height()
                                              ,pic.size().width())))
                             /qMax(pic.size().height(),pic.size().width()));
        setPixmap(pic);
    }
}

void ImageItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsPixmapItem::mouseReleaseEvent(event);
    emit _timelineRectItem->gridScene()->mouseUp();
}
