#include "t_rect_item.h"
#include <QGraphicsScene>
#include <QtMath>
#include <QDebug>
#include <QGraphicsSceneMouseEvent>
#include "GUI/mainwindow.h"

RectItem::RectItem():
    TTimelineData(this, QPointF())
{
    _itemMovable = true;

    init();
}

RectItem::RectItem(const QPointF &posf, const QRectF &rectf, const QString& object_name):
    TTimelineData(this, posf)
{
    setRect(rectf);
    setPos(posf);
    setObjectName(object_name);
    _itemMovable = true;

    init();

    connect(_timelineRectItem, &TTimeLineRectItem::itemChanged, this, [=](){
        int rowIndex = _timelineRectItem->row();
        setZValue(rowIndex);
    });
}

RectItem::~RectItem()
{
    delete _variantManager;
}

void RectItem::init()
{
    setAcceptHoverEvents(true);
    setFlags(QGraphicsItem::ItemIsSelectable|
             QGraphicsItem::ItemIsMovable|
             QGraphicsItem::ItemIsFocusable |
             QGraphicsItem::ItemSendsGeometryChanges);

    _variantManager = new QtVariantPropertyManager();
    _properties = _variantManager->addProperty(QtVariantPropertyManager::groupTypeId(),
                                               QLatin1String("Rect Item"));

    _itemName = _variantManager->addProperty(QVariant::String, "Name");
    _itemName->setValue(objectName()/*"Rectangle"*/);
    _properties->addSubProperty(_itemName);

    _itemPosition = _variantManager->addProperty(QVariant::PointF, "Position");
    _itemPosition->setValue(pos());
    _itemPosition->setAttribute(QLatin1String("decimals"), 3);
    _properties->addSubProperty(_itemPosition);

    _itemSize = _variantManager->addProperty(QVariant::SizeF, "Size");
    _itemSize->setValue(QSizeF(rect().size()));
    _itemSize->setAttribute(QLatin1String("decimals"), 3);
    _itemSize->setAttribute(QLatin1String("minimum"), QSizeF(1, 1));
    _properties->addSubProperty(_itemSize);

    _itemRotation = _variantManager->addProperty(QVariant::Int, "Rotation");
    _itemRotation->setValue(rotation());
    _itemRotation->setAttribute(QLatin1String("minimum"), -180);
    _itemRotation->setAttribute(QLatin1String("maximum"), 180);
    _itemRotation->setAttribute(QLatin1String("singleStep"), 5);
    _properties->addSubProperty(_itemRotation);

    _itemOpacity = _variantManager->addProperty(QVariant::Int, "Opacity");
    _itemOpacity->setValue(100*opacity());
    _itemOpacity->setAttribute(QLatin1String("minimum"), 20);
    _itemOpacity->setAttribute(QLatin1String("maximum"), 100);
    _itemOpacity->setAttribute(QLatin1String("singleStep"), 10);
    _properties->addSubProperty(_itemOpacity);

    _itemVisiblity = _variantManager->addProperty(QVariant::Bool, "Visible");
    _itemVisiblity->setValue(isVisible());
    _properties->addSubProperty(_itemVisiblity);

    _itemIsMovableDuringPlay = _variantManager->addProperty(QVariant::Bool, "Movable");
    _itemIsMovableDuringPlay->setValue(_itemMovable);
    _properties->addSubProperty(_itemIsMovableDuringPlay);

    _itemPenColor = _variantManager->addProperty(QVariant::Color, "Pen Color");
    _itemPenColor->setValue(pen().color());
    _properties->addSubProperty(_itemPenColor);

    _itemBorderThickness = _variantManager->addProperty(QVariant::Int, "Border Thickness");
    _itemBorderThickness->setValue(pen().width());
    _itemBorderThickness->setAttribute(QLatin1String("minimum"), 1);
    _itemBorderThickness->setAttribute(QLatin1String("maximum"), 6);
    _properties->addSubProperty(_itemBorderThickness);

    QStringList enumNames;
    enumNames << "NoPen" << "SolidLine" << "DashLine" << "DotLine" << "DashDotLine" << "DashDotDotLine";
    _itemPenStyle = _variantManager->addProperty(QtVariantPropertyManager::enumTypeId(),
                                                 QLatin1String("Pen Style"));
    _itemPenStyle->setAttribute(QLatin1String("enumNames"), enumNames);
    _itemPenStyle->setValue(1);
    _properties->addSubProperty(_itemPenStyle);

    _itemBrush = _variantManager->addProperty(QVariant::Bool, "Brush");
    _itemBrush->setValue(brush().isOpaque());
    _properties->addSubProperty(_itemBrush);

    _itemBrushColor = _variantManager->addProperty(QVariant::Color, "Brush Color");
    _itemBrushColor->setValue(brush().color());
    _itemBrushColor->setEnabled(brush().isOpaque());
    _properties->addSubProperty(_itemBrushColor);

    connect(_variantManager, SIGNAL(valueChanged(QtProperty*,QVariant)),
            this, SLOT(updateItemProperties()));
}

QVariant RectItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant &value)
{
    if (change == ItemPositionChange && scene()) {
        // value is the new position.
        QPointF newPos = value.toPointF();
        QRectF rect = scene()->sceneRect();
        QRectF itemRect = this->rect();

        // rounds position when view in zoom
        newPos.setX( qFloor(newPos.x()));
        newPos.setY( qFloor(newPos.y()));


        // rounds size when view in zoom
        itemRect.setWidth(qFloor(itemRect.width()));
        itemRect.setHeight(qFloor(itemRect.height()));
        this->setRect(itemRect);
        _itemSize->setValue(QSizeF(itemRect.size()));

        rect = rect.adjusted(-qMin(itemRect.width()*qCos(rotation()*M_PI/180),
                                   qMin(itemRect.height()*qSin(-rotation()*M_PI/180),
                                        qMin(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                             *qSin(qAtan2(itemRect.width(),itemRect.height())-(rotation()*M_PI/180)),
                                             qreal(0)))),
                             -qMin(itemRect.width()*qSin(rotation()*M_PI/180),
                                   qMin(itemRect.height()*qCos(rotation()*M_PI/180),
                                        qMin(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                             *qSin(qAtan2(itemRect.height(),itemRect.width())+(rotation()*M_PI/180)),
                                             qreal(0)))),
                             -qMax(itemRect.width()*qCos(rotation()*M_PI/180),
                                   qMax(itemRect.height()*qSin(-rotation()*M_PI/180),
                                        qMax(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                             *qSin(qAtan2(itemRect.width(),itemRect.height())-(rotation()*M_PI/180)),
                                             qreal(0)))),
                             -qMax(itemRect.width()*qSin(rotation()*M_PI/180),
                                   qMax(itemRect.height()*qCos(rotation()*M_PI/180),
                                        qMax(sqrt(itemRect.width()*itemRect.width()+itemRect.height()*itemRect.height())
                                             *qSin(qAtan2(itemRect.height(),itemRect.width())+(rotation()*M_PI/180)),
                                             qreal(0)))));

        if (!rect.contains(newPos)) {
            // Keep the item inside the scene rect.
            newPos.setX(qMin(rect.right(), qMax(newPos.x(), rect.left())));
            newPos.setY(qMin(rect.bottom(), qMax(newPos.y(), rect.top())));
        }

        return newPos;

    } else if (change == ItemPositionHasChanged && scene()) {

        if (_timelineRectItem->activatedKeyFrameExists()) {

            if ( !locked() ){
                QPointF delta = value.toPointF() - _itemPosition->value().toPointF();
                TKeyFrame *frame = _timelineRectItem->activatedKeyFrame();
                frame->setPos(frame->pos() + delta);

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }

        } else {
            if ( !locked() ){

                QPointF delta = value.toPointF() - _itemPosition->value().toPointF();

                foreach (TKeyFrame *frame, _timelineRectItem->keyFrames().values()) {
                    frame->setPos(frame->pos() + delta);
                }

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }
        }

        _itemPosition->setValue(value.toPointF());

    } else if ( change == ItemSelectedHasChanged && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        stageScene->update();

    }/* else if ((change == ItemSceneHasChanged || change == ItemSelectedChange) && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        connect(stageScene, SIGNAL(sceneReleased()), this, SLOT(releaseSpriteAnimating()));
    }*/
    return QGraphicsItem::itemChange(change, value);
}

void RectItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsRectItem::mousePressEvent(event);
    emit _timelineRectItem->gridScene()->mouseDown();
}

void RectItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsRectItem::mouseReleaseEvent(event);
    emit _timelineRectItem->gridScene()->mouseUp();
}

void RectItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QGraphicsRectItem::hoverEnterEvent(event);
    emit _timelineRectItem->gridScene()->mouseEnter();
}

bool RectItem::isMovable() const
{
    QVariant var = _itemIsMovableDuringPlay->value();
    return var.toBool();
}

void RectItem::setItemMovable(bool itemMovable)
{
    _itemMovable = itemMovable;
}

void RectItem::updateItemProperties()
{
    MainWindow* mainWindow = MainWindow::getInstance();
    if (_itemName->value().toString() != objectName()) {
        setObjectName(_itemName->value().toString());
        emit mainWindow->plotWidget->treeViewItemChanged();
    }

    // If inputed size is greater than scenerect , ignores and sets original size to the property
    if (scene()){
        qreal D, height, width, rot, wTeta, hTeta;
        height = _itemSize->value().toSizeF().height();
        width = _itemSize->value().toSizeF().width();
        rot = qAbs(_itemRotation->value().toReal() * M_PI / 180.0);
        if (rot > M_PI / 2.0) {
            wTeta = rot - M_PI / 2.0 + qAtan2(height,width);
            hTeta = rot - qAtan2(height,width);
        }
        else
        {
            wTeta = - rot + M_PI / 2.0 + qAtan2(height,width);
            hTeta = rot + qAtan2(height,width);
        }

        D = sqrt(pow(width, 2) + pow(height, 2));

        if (qAbs(D * qSin(wTeta)) >= scene()->sceneRect().width() ||
                qAbs(D * qSin(hTeta)) >= scene()->sceneRect().height() )
        {
            _itemSize->setValue(QSizeF(rect().size()));
            _itemRotation->setValue(rotation());
        }
    }

    setPos(_itemPosition->value().toPointF());
    setRect(QRectF(QPointF(0,0),_itemSize->value().toSizeF()));
    setRotation(_itemRotation->value().toReal());

    itemChange(ItemPositionChange, _itemPosition->value().toPointF()); //  if size makes item go beyound scenerect it fixes poition to avoid it

    _itemBrushColor->setEnabled(_itemBrush->value().toBool());
    QBrush brush(_itemBrushColor->value().value<QColor>());
    setBrush(brush);
    if (!_itemBrush->value().toBool())
        setBrush(Qt::NoBrush);

    QPen pen;
    pen.setWidth(_itemBorderThickness->value().toInt());
    pen.setStyle(static_cast<Qt::PenStyle>(_itemPenStyle->value().toInt()));
    pen.setColor(_itemPenColor->value().value<QColor>());
    setPen(pen);

    if (! _itemVisiblity->value().toBool() && isVisible()) {
        setVisible(_itemVisiblity->value().toBool()); // this must be corrected
        mainWindow->scene_selectionChanged(this);
    } else {
        setVisible(_itemVisiblity->value().toBool()); // this must be corrected
        setSelected(_itemVisiblity->value().toBool());
    }

    setOpacity(_itemOpacity->value().toReal()/100);
}

void RectItem::releaseSpriteAnimating()
{
    if (_timelineRectItem->activatedKeyFrameExists()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        if (stageScene->animatingPathEnabled() == true) {
            if (_timelineRectItem->activatedKeyFrameExists()) {
                _timelineRectItem->activatedKeyFrame()->setPos(scenePos());
            }
            _timelineRectItem->deactivateAll();
            stageScene->setAnimatingPathEnabled(false);
        }
    }
}

QDataStream &operator<<(QDataStream &out, const RectItem & ri)
{
    out << ri.objectName()
        << ri.pos()
        << ri.rect().size()
        << ri.rotation()
        << ri.opacity()
        << ri.isVisible()
        << ri.pen()
        << ri._itemPenStyle->value().toInt()
        << ri.brush()
        << ri.timelineRectItem()
        << ri.behaviour()
        << ri.isMovable();


    return out;
}

QDataStream &operator>>(QDataStream &in, RectItem & ri)
{
    QString name;
    QPointF pos;
    QSizeF size;
    qreal rotation ;
    qreal opacity;
    bool Visiblity;
    QPen pen;
    int penStyle;
    QBrush brush;
    TTimeLineRectItem rectItem;
    bool movable;
    TTimelineBehaviour *behaviour =  ri.behaviour();


    in >> name
            >> pos
            >> size
            >> rotation
            >> opacity
            >> Visiblity
            >> pen
            >> penStyle
            >> brush
            >> &rectItem
            >> behaviour
            >> movable;

    ri.setRect(QRectF(QPointF(0,0),size));
    ri.setPos(pos);
    ri.setObjectName(name);
    ri.setRotation(rotation);
    ri.setOpacity(opacity);
    ri.setVisible(Visiblity);
    ri.setPen(pen);
    ri.setBrush(brush);
    ri.updateTimeLineRectItem(&rectItem);
    ri.setItemMovable(movable);

    delete ri._variantManager;
    ri.init();

    ri._itemPenStyle->setValue(penStyle);

    return in;
}
