#include "t_line_item.h"
#include <QGraphicsScene>
#include <QDebug>
#include <QtMath>
#include <QGraphicsSceneMouseEvent>
#include "GUI/mainwindow.h"

LineItem::LineItem(QGraphicsItem *parent)
    : TTimelineData(this, QPointF()), QGraphicsLineItem(parent)
{
    _itemMovable = true;

    init();
}

LineItem::LineItem(const QPointF &posf, const QLineF &line, const QString& object_name, QGraphicsItem *parent) :
    TTimelineData(this, posf), QGraphicsLineItem(parent)
{
    setLine(line);
    setPos(posf);
    setObjectName(object_name);
    _itemMovable = true;

    init();

    connect(_timelineRectItem, &TTimeLineRectItem::itemChanged, this, [=](){
        int rowIndex = _timelineRectItem->row();
        setZValue(rowIndex);
    });
}

LineItem::~LineItem()
{
    delete _variantManager;
}

void LineItem::init()
{
    setAcceptHoverEvents(true);
    setFlags(QGraphicsItem::ItemIsSelectable|
             QGraphicsItem::ItemIsMovable|
             QGraphicsItem::ItemIsFocusable |
             QGraphicsItem::ItemSendsGeometryChanges);

    _variantManager = new QtVariantPropertyManager();
    _properties = _variantManager->addProperty(QtVariantPropertyManager::groupTypeId(),
                                               QLatin1String("Line Item"));

    _itemName = _variantManager->addProperty(QVariant::String, "Name");
    _itemName->setValue(objectName());
    _properties->addSubProperty(_itemName);

    _itemStartPosition = _variantManager->addProperty(QVariant::PointF, "Start Point");
    _itemStartPosition->setValue(pos());
    _itemStartPosition->setAttribute(QLatin1String("decimals"), 3);
    _properties->addSubProperty(_itemStartPosition);

    _itemEndPosition = _variantManager->addProperty(QVariant::PointF, "End Point");
    _itemEndPosition->setValue(pos()+line().p2());
    _itemEndPosition->setAttribute(QLatin1String("decimals"), 3);
    _itemEndPosition->setAttribute(QLatin1String("minimum"), QPointF(0 , 0));
    _itemEndPosition->setAttribute(QLatin1String("maximum"), QPointF(600, 200));
    _properties->addSubProperty(_itemEndPosition);

    _itemOpacity = _variantManager->addProperty(QVariant::Int, "Opacity");
    _itemOpacity->setValue(100*opacity());
    _itemOpacity->setAttribute(QLatin1String("minimum"), 20);
    _itemOpacity->setAttribute(QLatin1String("maximum"), 100);
    _itemOpacity->setAttribute(QLatin1String("singleStep"), 10);
    _properties->addSubProperty(_itemOpacity);

    _itemVisiblity = _variantManager->addProperty(QVariant::Bool, "Visible");
    _itemVisiblity->setValue(isVisible());
    _properties->addSubProperty(_itemVisiblity);

    _itemIsMovableDuringPlay = _variantManager->addProperty(QVariant::Bool, "Movable");
    _itemIsMovableDuringPlay->setValue(_itemMovable);
    _properties->addSubProperty(_itemIsMovableDuringPlay);

    _itemPenColor = _variantManager->addProperty(QVariant::Color, "Pen Color");
    _itemPenColor->setValue(pen().color());
    _properties->addSubProperty(_itemPenColor);

    _itemPenThickness = _variantManager->addProperty(QVariant::Int, "Pen Thickness");
    _itemPenThickness->setValue(pen().width());
    _itemPenThickness->setAttribute(QLatin1String("minimum"), 1);
    _itemPenThickness->setAttribute(QLatin1String("maximum"), 6);
    _properties->addSubProperty(_itemPenThickness);

    QStringList enumNames;
    enumNames << "NoPen" << "SolidLine" << "DashLine" << "DotLine" << "DashDotLine" << "DashDotDotLine";
    _itemPenStyle = _variantManager->addProperty(QtVariantPropertyManager::enumTypeId(),
                                                 QLatin1String("Pen Style"));
    _itemPenStyle->setAttribute(QLatin1String("enumNames"), enumNames);
    _itemPenStyle->setValue(1);
    _properties->addSubProperty(_itemPenStyle);

    connect(_variantManager, SIGNAL(valueChanged(QtProperty*,QVariant)), this, SLOT(updateItemProperties()));
}


QVariant LineItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant &value)
{
    if (change == ItemPositionChange && scene()) {
        // value is the new position.
        QPointF newPos = value.toPointF();
        QRectF rect = scene()->sceneRect();

        // rounds position when view in zoom
        newPos.setX( qFloor(newPos.x()));
        newPos.setY( qFloor(newPos.y()));

        // rounds end of line position when view in zoom
        setLine(QLineF(0, 0, qFloor(line().p2().x()), qFloor(line().p2().y()) ));

        rect = rect.adjusted((line().p2().x()<0) ? - line().p2().x() : 0,
                             (line().p2().y()<0) ? - line().p2().y() : 0,
                             (line().p2().x()>0) ? - line().p2().x() : 0,
                             (line().p2().y()>0) ? - line().p2().y() : 0);

        if (!rect.contains(newPos)) {
            // Keep the item inside the scene rect.
            newPos.setX(qMin(rect.right(), qMax(newPos.x(), rect.left())));
            newPos.setY(qMin(rect.bottom(), qMax(newPos.y(), rect.top())));
        }

        return newPos;

    } else if (change == ItemPositionHasChanged && scene()) {

        if (_timelineRectItem->activatedKeyFrameExists()) {

            if ( !locked() ){
                QPointF delta = value.toPointF() - _itemStartPosition->value().toPointF();
                TKeyFrame *frame = _timelineRectItem->activatedKeyFrame();
                frame->setPos(frame->pos() + delta);

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }

        } else {
            if ( !locked() ){

                QPointF delta = value.toPointF() - _itemStartPosition->value().toPointF();

                foreach (TKeyFrame *frame, _timelineRectItem->keyFrames().values()) {
                    frame->setPos(frame->pos() + delta);
                }

                TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
                stageScene->update();
            }
        }

        _itemEndPosition->setValue(value.toPointF() + line().p2());
        _itemStartPosition->setValue(value.toPointF());

    } else if ( change == ItemSelectedHasChanged && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        stageScene->update();

    }/* else if ((change == ItemSceneHasChanged || change == ItemSelectedChange) && scene()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        connect(stageScene, SIGNAL(sceneReleased()), this, SLOT(releaseSpriteAnimating()));
    }*/
    return QGraphicsLineItem::itemChange(change, value);
}

void LineItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsLineItem::mousePressEvent(event);
    emit _timelineRectItem->gridScene()->mouseDown();
}

void LineItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsLineItem::mouseReleaseEvent(event);
    emit _timelineRectItem->gridScene()->mouseUp();
}

void LineItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QGraphicsLineItem::hoverEnterEvent(event);
    emit _timelineRectItem->gridScene()->mouseEnter();
}

bool LineItem::isMovable() const
{
    QVariant var = _itemIsMovableDuringPlay->value();
    return var.toBool();
}

void LineItem::setItemMovable(bool itemMovable)
{
    _itemMovable = itemMovable;
}

void LineItem::updateItemProperties()
{    
    qreal width = scene()->sceneRect().right();
    qreal height = scene()->sceneRect().bottom();

    if (!(_itemStartPosition->value().toPointF().x() >= 0
          && _itemStartPosition->value().toPointF().x() <= width
          && _itemStartPosition->value().toPointF().y() >= 0
          && _itemStartPosition->value().toPointF().y() <= height
          && _itemEndPosition->value().toPointF().x() >= 0
          && _itemEndPosition->value().toPointF().x() <= width
          && _itemEndPosition->value().toPointF().y() >= 0
          && _itemEndPosition->value().toPointF().y() <= height ))
    {
        _itemEndPosition->setValue(QVariant(QPointF(this->pos() + line().p2())));
        _itemStartPosition->setValue(QVariant(QPointF(this->pos())));
    }

    QPointF pos=_itemStartPosition->value().toPointF();
    QPointF endPos = _itemEndPosition->value().toPointF()-_itemStartPosition->value().toPointF();
    setLine(QLineF(QPointF(0,0),endPos));
    setPos(pos);

    MainWindow* mainWindow = MainWindow::getInstance();
    if (_itemName->value().toString() != objectName()) {
        setObjectName(_itemName->value().toString());
        emit mainWindow->plotWidget->treeViewItemChanged();
    }

    QPen pen;
    pen.setWidth(_itemPenThickness->value().toInt());
    pen.setStyle(static_cast<Qt::PenStyle>(_itemPenStyle->value().toInt()));
    pen.setColor(_itemPenColor->value().value<QColor>());
    setPen(pen);

    if (! _itemVisiblity->value().toBool() && isVisible()) {
        setVisible(_itemVisiblity->value().toBool());
        mainWindow->scene_selectionChanged(this);
    } else {
        setVisible(_itemVisiblity->value().toBool());
        setSelected(_itemVisiblity->value().toBool());
    }
    setOpacity(_itemOpacity->value().toReal()/100);
}

void LineItem::releaseSpriteAnimating()
{
    if (_timelineRectItem->activatedKeyFrameExists()) {
        TStageScene *stageScene = dynamic_cast<TStageScene*>(scene());
        if (stageScene->animatingPathEnabled() == true) {
            if (_timelineRectItem->activatedKeyFrameExists()) {
                _timelineRectItem->activatedKeyFrame()->setPos(scenePos());
            }
            _timelineRectItem->deactivateAll();
            stageScene->setAnimatingPathEnabled(false);
        }
    }
}


QDataStream &operator<<(QDataStream &out, const LineItem & li)
{
    out << li.objectName()
        << li.pos()
        << li.line()
        << li.opacity()
        << li.isVisible()
        << li.pen()
        << li._itemPenStyle->value().toInt()
        << li.timelineRectItem()
        << li.behaviour()
        << li.isMovable();

    return out;
}

QDataStream &operator>>(QDataStream &in, LineItem & li)
{
    QString name;
    QPointF pos;
    QLineF line;
    qreal opacity;
    bool Visiblity;
    QPen pen;
    int penStyle;
    TTimeLineRectItem rectItem;
    STimelineState firstState;
    STimelineState lastState;
    bool movable;
    TTimelineBehaviour *behaviour =  li.behaviour();

    in >> name
            >> pos
            >> line
            >> opacity
            >> Visiblity
            >> pen
            >> penStyle
            >> &rectItem
            >> behaviour
            >> movable;

    li.setObjectName(name);
    li.setPos(pos);
    li.setLine(line);
    li.setOpacity(opacity);
    li.setVisible(Visiblity);
    li.setPen(pen);
    li.updateTimeLineRectItem(&rectItem);
    li.setItemMovable(movable);

    delete li._variantManager;
    li.init();

    li._itemPenStyle->setValue(penStyle);

    return in;
}

