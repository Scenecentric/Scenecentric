#if !defined(_ELLIPSEITEM_H)
#define _ELLIPSEITEM_H

#include <QGraphicsEllipseItem>
#include <QObject>

#include "t_item.h"
#include "GUI/PropertyBrowser/qtvariantproperty.h"
#include "Timeline/t_timeline_data.h"

class EllipseItem : public QObject, public TTimelineData, public QGraphicsEllipseItem//, Item
{
    Q_OBJECT
public:
    EllipseItem();
    EllipseItem(const QPointF &posf, const QRectF& rectf, const QString& object_name = "Ellipse");
    ~EllipseItem();

    int type() const { return Item::Ellipse; }

    QtProperty *properties() const { return _properties; }
    QtVariantPropertyManager *propertyManager() const { return _variantManager; }

    QVariant itemChange(GraphicsItemChange change, const QVariant &value);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    bool isMovable() const;
    void setItemMovable(bool itemMovable);

    friend QDataStream &operator<<(QDataStream &out, const EllipseItem &);
    friend QDataStream &operator>>(QDataStream &out, EllipseItem &);


private slots:
    void updateItemProperties();
    void releaseSpriteAnimating();

private:
    void init();

    bool _itemMovable;

    QtVariantProperty *_itemName;
    QtVariantProperty *_itemPenColor;
    QtVariantProperty *_itemBrushColor;
    QtVariantProperty *_itemBrush;
    QtVariantProperty *_itemBorderThickness;
    QtVariantProperty *_itemPenStyle;
    QtVariantProperty *_itemPosition;
    QtVariantProperty *_itemRotation;
    QtVariantProperty *_itemOpacity;
    QtVariantProperty *_itemVisiblity;
    QtVariantProperty *_itemIsMovableDuringPlay;
    QtVariantProperty *_itemSize;

    QtProperty *_properties;
    QtVariantPropertyManager *_variantManager;
};

QDataStream &operator<<(QDataStream &out, const EllipseItem &);
QDataStream &operator>>(QDataStream &out, EllipseItem &);


#endif  //_ELLIPSEITEM_H
