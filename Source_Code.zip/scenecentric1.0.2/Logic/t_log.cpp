#include "t_log.h"
#include "t_image_item.h"

Log::Log()
{
    _plotSectionScene = new TStageScene();
}

Log::~Log()
{
    delete _plotSectionScene;
}

Log *Log::sampleLog()
{
    Log* lg = new Log();

    return lg;
}

TStageScene *Log::plotSectionScene() const
{
    return _plotSectionScene;
}

void Log::setPlotSectionScene(TStageScene *plotSectionScene)
{
    _plotSectionScene = plotSectionScene;
}

QDataStream &operator<<(QDataStream &out, const Log & lg)
{
    out << *lg._plotSectionScene;

    return out;
}

QDataStream &operator>>(QDataStream &in, Log &lg)
{
    in >> *lg._plotSectionScene;

    return in;
}




